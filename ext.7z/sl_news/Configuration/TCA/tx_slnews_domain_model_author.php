<?php

use HDNET\Autoloader\Utility\ArrayUtility;
use HDNET\Autoloader\Utility\ModelUtility;

// return (function () {

    $base = ModelUtility::getTcaInformation(\Standardlife\SlNews\Domain\Model\Author::class);

    // custom manipulation calls here
    $custom = [
        'ctrl' => [
            'label' => 'name',
            'label_alt' => 'name',
            'label_alt_force' => true,
        ],

        'columns' => [
        ],
    ];

    return ArrayUtility::mergeRecursiveDistinct($base, $custom);

// })();
