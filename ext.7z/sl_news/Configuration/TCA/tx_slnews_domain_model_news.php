<?php

use HDNET\Autoloader\Utility\ArrayUtility;
use HDNET\Autoloader\Utility\ModelUtility;

// return (function () {

    $base = ModelUtility::getTcaInformation(\Standardlife\SlNews\Domain\Model\News::class);

    // custom manipulation calls here
    $custom = [
        'columns' => [
            'title' => [
                'config' => [
                    'type' => 'text',
                ],
            ],

            'teaser_text' => [
                'config' => [
                    'type' => 'text',
                ],
            ],

            'scope' => [
                'config' => [
                    'type' => 'select',
                    'items' => \Standardlife\Website\Enumeration\ScopeEnum::getTcaItems(),
                ],
            ],

            'author' =>  [
                'config' => [
                    'type' => 'group',
                    'internal_type' => 'db',
                    'allowed' => 'tx_slnews_domain_model_author',
                    'foreign_table' => 'tx_slnews_domain_model_author',
                    'foreign_where' => ' AND tx_slnews_domain_model_author.deleted = 0 
                                         AND tx_slnews_domain_model_author.hidden = 0
                                         AND tx_slnews_domain_model_author.t3ver_oid = 0
                                         ORDER BY tx_slnews_domain_model_author.name',
                    'size' => 1,
                    'minitems' => 0,
                    'maxitems' => 1,

                    'show_thumbs' => 1,
                    'wizards' => [
                        'suggest' => [
                            'type' => 'suggest',
                        ],
                    ],
                ],
            ],

            'news_type' => [
                'config' => [
                    'type' => 'select',
                    'items' => [
                        ['News', 'news'],
                        ['The Way Forward', 'theWayForward'],
                        ['Pressemitteilung', 'pressemitteilung'],
                        ['Pressespiegel', 'pressespiegel'],
                    ],
                ],
            ],

            'category' => [
                'config' => [
                    'type' => 'select',
                    'renderType' => 'selectTree',
                    'size' => 10,
                    //'minItems' => 1,
                    //'maxItems' => 1,
                    'foreign_table' => 'sys_category',
                    'foreign_table_where' => ' ORDER BY sys_category.title ASC',
                    'treeConfig' => array(
                        'parentField' => 'parent',
                        'appearance' => array(
                            'expandAll' => true,
                            'showHeader' => true,
                        ),
                    ),
                ],
            ],

            'tags' => [
                'config' => [
                    'type' => 'select',
                    'renderType' => 'selectTree',
                    'size' => 10,
                    //'minItems' => 1,
                    //'maxItems' => 1,
                    'foreign_table' => 'sys_category',
                    'foreign_table_where' => ' ORDER BY sys_category.title ASC',
                    'treeConfig' => array(
                        'parentField' => 'parent',
                        'appearance' => array(
                            'expandAll' => true,
                            'showHeader' => true,
                        ),
                    ),
                ],
            ],
        ],
    ];

    $tca = ArrayUtility::mergeRecursiveDistinct($base, $custom);

    if (\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::isLoaded('sl_crd')) {
        $tca = \Standardlife\SlCrd\Utilities\CrdUtil::addTca($tca);
    }


    $tca['types']['1']['showitem'] = str_replace('import_id,', '', $tca['types']['1']['showitem']);
    $tca['types']['1']['showitem'] = str_replace('import_source_type,', '', $tca['types']['1']['showitem']);
    $tca['types']['1']['showitem'] = str_replace('import_data,', '', $tca['types']['1']['showitem']);

    return $tca;
// })();
