<?php

use Standardlife\SlNews\Domain\Model\News;
use Standardlife\SlNews\Domain\Repository\NewsRepository;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Object\ObjectManager;
use TYPO3\CMS\Frontend\ContentObject\ContentObjectRenderer;
use TYPO3\CMS\Frontend\Controller\TypoScriptFrontendController;
use TYPO3\CMS\Frontend\Utility\EidUtility;

// init environment
$GLOBALS['TSFE'] = GeneralUtility::makeInstance(
    TypoScriptFrontendController::class,
    $GLOBALS['TYPO3_CONF_VARS'],
    null,
    0
);

EidUtility::initLanguage();
$GLOBALS['TSFE']->connectToDB();
$GLOBALS['TSFE']->initFEuser();
$GLOBALS['TSFE']->initUserGroups();
EidUtility::initTCA();
$GLOBALS['TSFE']->checkAlternativeIdMethods();
$GLOBALS['TSFE']->clear_preview();
$GLOBALS['TSFE']->determineId();
\TYPO3\CMS\Core\Core\Bootstrap::getInstance()->loadBaseTca();
$GLOBALS['TSFE']->initTemplate();
$GLOBALS['TSFE']->getConfigArray();
$GLOBALS['TSFE']->cObj = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance(ContentObjectRenderer::class);
$GLOBALS['TSFE']->settingLanguage();
$GLOBALS['TSFE']->settingLocale();


// handling

/** @var \TYPO3\CMS\Extbase\Object\ObjectManager $objectManager */
$objectManager = GeneralUtility::makeInstance(ObjectManager::class);
/** @var NewsRepository $newsRepository*/
$newsRepository = $objectManager->get(NewsRepository::class);

/** @var News[] $items */
$items = $newsRepository->findAllOrdered([], \TYPO3\CMS\Extbase\Persistence\QueryInterface::ORDER_DESCENDING, true);

$fluidTemplateRenderer = new \OH\Ohmex\Renderer\FluidTemplateRenderer(
    __DIR__ . '/../../Views/'
);

$html = $fluidTemplateRenderer->render('rss-feed', ['items' => $items]);

header('Content-Type: application/rss+xml; charset=utf-8');
echo trim($html);

exit(0);