<?php
/** @var $_EXTKEY string */
$EM_CONF[$_EXTKEY] = [
    'title'       => 'Standard Life News',
    'description' => '',
    'constraints' => [
        'depends' => [
            'typo3' => '8.0.0-8.99.99',
            'autoloader' => '1.11.1-9.9.9',
            'fluid_styled_content' => ''
        ],
    ],
    'clearCacheOnLoad' => true
];