<?php

namespace Standardlife\SlNews\Userfunc;

/**
 * Class Tca
 * @package Standardlife\SlNews\Userfunc
 */
class Tca
{

    /**
     * @param $parameters
     * @param $parentObject
     */
    public function newsLabel(&$parameters, $parentObject)
    {
        $record = \TYPO3\CMS\Backend\Utility\BackendUtility::getRecord($parameters['table'], $parameters['row']['uid']);
        $newTitle = $record['title'];
        //$newTitle .= ' (' . substr(strip_tags($record['impressions']), 0, 10) . '...)';
        $parameters['title'] = $newTitle;
    }

    /**
     * @param $table
     * @param $uid
     * @param $name
     * @param $value
     * @return string
     */
    public function newsTitle($table, $uid, $name, $value)
    {
        $record = \TYPO3\CMS\Backend\Utility\BackendUtility::getRecord($table, $uid);
        $newTitle = $record['title'];

        return $newTitle;
    }

    /**
     * @param $table
     * @param $uid
     * @param $name
     * @param $value
     * @return string
     */
    public function renderScope($table, $uid, $name, $value)
    {
        $record = \TYPO3\CMS\Backend\Utility\BackendUtility::getRecord($table, $uid);
        $newTitle = (empty($record['scope']) ? 'DE & AT' : $record['scope']);

        return $newTitle;
    }
}