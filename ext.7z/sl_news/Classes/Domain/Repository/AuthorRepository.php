<?php

namespace Standardlife\SlNews\Domain\Repository;


use Standardlife\SlNews\Domain\Model\Author;
use TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings;
use TYPO3\CMS\Extbase\Persistence\QueryInterface;
use TYPO3\CMS\Extbase\Persistence\Repository;


/**
 * Class AuthorRepository
 * @package Standardlife\SlNews\Domain\Repository
 */
class AuthorRepository extends Repository
{

    public function initializeObject()
    {
        /* @var $querySettings Typo3QuerySettings */
        $querySettings = $this->objectManager->get(Typo3QuerySettings::class);

        // don't add the pid constraint
        $querySettings->setRespectStoragePage(false);
        $querySettings->setRespectSysLanguage(true);

        $this->setDefaultQuerySettings($querySettings);
    }


    /**
     * @param $name
     * @return Author|bool
     */
    public function findByName($name)
    {
        $name = (string)$name;

        $q = $this->createQuery();
        $q->matching($q->equals('name', $name));

        $q->setLimit(1);
        $result = $q->execute();

        return reset($result);
    }

}