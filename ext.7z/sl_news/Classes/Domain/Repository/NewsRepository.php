<?php

namespace Standardlife\SlNews\Domain\Repository;


use Standardlife\Website\Domain\Repository\SysCategoryRepository;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Persistence\Generic\Query;
use TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings;
use TYPO3\CMS\Extbase\Persistence\QueryInterface;
use TYPO3\CMS\Extbase\Persistence\Repository;
use TYPO3\CMS\Extbase\Utility\DebuggerUtility;


/**
 * Class NewsRepository
 * @package Standardlife\SlNews\Domain\Repository
 */
class NewsRepository extends Repository
{

    public function initializeObject()
    {
        /* @var $querySettings Typo3QuerySettings */
        $querySettings = $this->objectManager->get(Typo3QuerySettings::class);

        // don't add the pid constraint
        $querySettings->setRespectStoragePage(false);
        $querySettings->setRespectSysLanguage(true);

        $this->setDefaultQuerySettings($querySettings);
    }

    /**
     * Find news by category ids, set order
     * @param array $categoryIds
     * @param string $order
     * @param bool $rawQueryResult
     * @return array
     */
    public function findAllOrdered($categoryIds = [], $order = QueryInterface::ORDER_DESCENDING, $rawQueryResult = false)
    {
        /** @var Query $q */
        $q = $this->createQuery();

        $constraint = $q->equals('hidden', false);
        if (!empty($categoryIds)) {

            $categoriesConstraint = $this->addCategoriesOrConstraint($q, null, $categoryIds);

            $constraint = $q->logicalAnd(
                $constraint,
                $categoriesConstraint
            );
        }

        // check SL scope
        $constraint = $q->logicalAnd(
            $constraint,
            $q->logicalOr(
                $q->equals('scope', ''),
                $q->equals('scope', strtoupper((string)GeneralUtility::_GET('slScope')))
            )
        );

        $q->matching($constraint);
        $q->setOrderings([
            'date' => $order,
            'crdate' => $order,
        ]);

        if ($rawQueryResult) {
            return $q->execute(true);
        }
        $result = $q->execute();

        return $result->toArray();
    }

    /**
     * Find all available tags. If newsUids are provided only find tags used in those news.
     * @param array|null $newsUids
     * @return array
     */
    public function findAllAvailableTags($newsUids = null)
    {
        $slScope = strtoupper((string)GeneralUtility::_GET('slScope'));

        /** @var Query $q */
        $q = $this->createQuery();
        if ($newsUids === null || empty($newsUids)) {
            $q->statement('SELECT tags FROM tx_slnews_domain_model_news WHERE deleted = 0 AND hidden = 0 AND tags != \'\' AND (scope = \'\' OR scope = \'' . $slScope . '\')');
        } else {
            $q->statement('SELECT tags FROM tx_slnews_domain_model_news WHERE deleted = 0 AND hidden = 0 AND tags != \'\' AND uid IN (' . join(',', $newsUids). ') AND (scope = \'\' OR scope = \'' . $slScope . '\')');
        }
        $result = $q->execute(true);

        $tagUidCountMapping = [];
        foreach ($result as $item) {
            $ids = explode(',', $item['tags']);
            foreach ($ids as $id) {
                if (!array_key_exists($id, $tagUidCountMapping)) {
                    $tagUidCountMapping[$id] = 1;
                } else {
                    $tagUidCountMapping[$id]++;
                }
            }
        }

        // sort tagUidCountMapping desc by value count
        arsort($tagUidCountMapping);

        /** @var SysCategoryRepository $sysCategoryRepository */
        $sysCategoryRepository = $this->objectManager->get(SysCategoryRepository::class);

        $tagUids = array_keys($tagUidCountMapping);
        $tags = $sysCategoryRepository->findByUids($tagUids);

        foreach ($tags as $tag) {
            $tagUidCountMapping[$tag->getUid()] = $tag;
        }

        return $tagUidCountMapping;
    }

    /**
     * Find news by category and tags (both optional)
     * @param null $category
     * @param array $tags
     * @param string $order
     * @return array
     */
    public function findByCategoryAndTags($category = null, $tags = [], $order = QueryInterface::ORDER_DESCENDING)
    {

        if ($category === null && empty($tags)) {
            return $this->findAllOrdered([], $order);
        }

        /** @var Query $q */
        $q = $this->createQuery();

        $constraint = $q->equals('hidden', false);

        // check SL scope
        $slScope = strtoupper(GeneralUtility::_GET('slScope'));
        $constraint = $q->logicalAnd(
            $constraint,
            $q->logicalOr(
                $q->equals('scope', ''),
                $q->equals('scope', strtoupper((string)GeneralUtility::_GET('slScope')))
            )
        );

        if ($category !== null && empty($tags)) {
            $constraint = $q->logicalAnd(
                $constraint,
                $q->equals('category', $category)
            );

            $q->matching($constraint);
        } else if ($category !== null && !empty($tags)) {
            $constraint = $this->addTagsConstraint($q, $constraint, $tags);

            $constraint = $q->logicalAnd(
                $q->equals('category', $category),
                $constraint
            );

            $q->matching($constraint);
        } else {
            $constraint = $this->addTagsConstraint($q, $constraint, $tags);

            $q->matching($constraint);
        }

        $q->setOrderings([
            'date' => $order,
            'crdate' => $order,
        ]);

        $result = $q->execute();

        return $result->toArray();
    }

    /**
     * Add tags query constraints to constraint
     * @param Query $query
     * @param $constraint
     * @param $tags
     * @return mixed
     */
    protected function addTagsConstraint($query, $constraint, $tags)
    {
        foreach ($tags as $tag) {
            $constraint = $query->logicalAnd(
                $constraint,
                $query->logicalOr(
                    $query->like('tags', $tag . ',%'),
                    $query->like('tags', '%,' . $tag),
                    $query->like('tags', '%,' . $tag . ',%'),
                    $query->equals('tags', $tag)
                )
            );
        }

        return $constraint;
    }

    /**
     * Add category constraints to constraints
     * @param Query $query
     * @param $constraint
     * @param $categories
     * @return mixed
     */
    protected function addCategoriesConstraint($query, $constraint, $categories)
    {
        foreach ($categories as $category) {
            $constraint = $query->logicalAnd(
                $constraint,
                $query->logicalOr(
                    $query->like('category', $category . ',%'),
                    $query->like('category', '%,' . $category),
                    $query->like('category', '%,' . $category . ',%'),
                    $query->equals('category', $category)
                )
            );
        }

        return $constraint;
    }

    /**
     * Add category or constraints to constraints
     * @param Query $query
     * @param $constraint
     * @param $categories
     * @return mixed
     */
    protected function addCategoriesOrConstraint($query, $constraint, $categories)
    {
        foreach ($categories as $category) {
            if ($constraint === null) {
                $constraint = $query->logicalOr(
                    $query->like('category', $category . ',%'),
                    $query->like('category', '%,' . $category),
                    $query->like('category', '%,' . $category . ',%'),
                    $query->equals('category', $category)
                );
            } else {
                $constraint = $query->logicalOr(
                    $constraint,
                    $query->logicalOr(
                        $query->like('category', $category . ',%'),
                        $query->like('category', '%,' . $category),
                        $query->like('category', '%,' . $category . ',%'),
                        $query->equals('category', $category)
                    )
                );
            }
        }

        return $constraint;
    }

}