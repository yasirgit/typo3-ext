<?php

namespace Standardlife\SlNews\Domain\Model;


use TYPO3\CMS\Extbase\DomainObject\AbstractEntity;

/**
 * Class News
 * @package Standardlife\SlNews\Domain\Model
 * @db
 */
class News extends AbstractEntity
{

    /**
     * @var string
     * @db
     */
    protected $title;

    /**
     * @var string
     * @db
     */
    protected $newsType;

    /**
     * @var string
     * @db
     */
    protected $scope;

    /**
     * @var \DateTime
     * @db
     */
    protected $date;

    /**
     * @var \TYPO3\CMS\Extbase\Domain\Model\FileReference
     * @db
     */
    protected $image;

    /**
     * @var \TYPO3\CMS\Extbase\Domain\Model\FileReference
     * @db
     */
    protected $tileImage;

    /**
     * @var string
     * @db
     */
    protected $teaserText;

    /**
     * @var string
     * @enableRichText
     * @db
     */
    protected $bodytext;

    /**
     * @var \Standardlife\Website\Domain\Model\SysCategory
     * @db
     */
    protected $category;

    /**
     * @var \Standardlife\SlNews\Domain\Model\Author
     * @db
     */
    protected $author;

    /**
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Standardlife\Website\Domain\Model\SysCategory>
     * @db
     */
    protected $tags;

    /**
     * @var \Standardlife\SlCrd\Domain\Model\Crd
     * @db
     */
    protected $crd;

    /**
     * @var bool
     */
    protected $hidden;

    /**
     * @var int
     * @db
     */
    protected $importId;

    /**
     * @var string
     * @db
     */
    protected $importSourceType;

    /**
     * @var string
     * @db
     */
    protected $importData;

    /**
     * @return string
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * @param string $title
     */
    public function setTitle($title)
    {
        $this->title = $title;
    }

    /**
     * @return string
     */
    public function getNewsType()
    {
        return $this->newsType;
    }

    /**
     * @param string $newsType
     */
    public function setNewsType($newsType)
    {
        $this->newsType = $newsType;
    }

    /**
     * @return \DateTime
     */
    public function getDate()
    {
        return $this->date;
    }

    /**
     * @param \DateTime $date
     */
    public function setDate($date)
    {
        $this->date = $date;
    }

    /**
     * @return \TYPO3\CMS\Extbase\Domain\Model\FileReference
     */
    public function getImage()
    {
        return $this->image;
    }

    /**
     * @param \TYPO3\CMS\Extbase\Domain\Model\FileReference $image
     */
    public function setImage($image)
    {
        $this->image = $image;
    }

    /**
     * @return \TYPO3\CMS\Extbase\Domain\Model\FileReference
     */
    public function getTileImage()
    {
        return $this->tileImage;
    }

    /**
     * @param \TYPO3\CMS\Extbase\Domain\Model\FileReference $tileImage
     */
    public function setTileImage(\TYPO3\CMS\Extbase\Domain\Model\FileReference $tileImage)
    {
        $this->tileImage = $tileImage;
    }

    /**
     * @return string
     */
    public function getTeaserText()
    {
        return $this->teaserText;
    }

    /**
     * @param string $teaserText
     */
    public function setTeaserText($teaserText)
    {
        $this->teaserText = $teaserText;
    }

    /**
     * @return string
     */
    public function getBodytext()
    {
        return $this->bodytext;
    }

    /**
     * @param string $bodytext
     */
    public function setBodytext($bodytext)
    {
        $this->bodytext = $bodytext;
    }

    /**
     * @return \Standardlife\Website\Domain\Model\SysCategory
     */
    public function getCategory()
    {
        return $this->category;
    }

    /**
     * @param \Standardlife\Website\Domain\Model\SysCategory $category
     */
    public function setCategory($category)
    {
        $this->category = $category;
    }

    /**
     * @return Author
     */
    public function getAuthor()
    {
        return $this->author;
    }

    /**
     * @param Author $author
     */
    public function setAuthor($author)
    {
        $this->author = $author;
    }

    /**
     * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage
     */
    public function getTags()
    {
        return $this->tags;
    }

    /**
     * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage $tags
     */
    public function setTags($tags)
    {
        $this->tags = $tags;
    }

    /**
     * @return \Standardlife\SlCrd\Domain\Model\Crd
     */
    public function getCrd()
    {
        return $this->crd;
    }

    /**
     * @param \Standardlife\SlCrd\Domain\Model\Crd $crd
     */
    public function setCrd($crd)
    {
        $this->crd = $crd;
    }

    /**
     * @return bool
     */
    public function isHidden()
    {
        return $this->hidden;
    }

    /**
     * @param bool $hidden
     */
    public function setHidden(bool $hidden)
    {
        $this->hidden = $hidden;
    }

    /**
     * @return string
     */
    public function getScope()
    {
        return $this->scope;
    }

    /**
     * @param string $scope
     */
    public function setScope(string $scope)
    {
        $this->scope = $scope;
    }

    /**
     * @return int
     */
    public function getImportId()
    {
        return $this->importId;
    }

    /**
     * @param int $importId
     */
    public function setImportId(int $importId)
    {
        $this->importId = $importId;
    }

    /**
     * @return string
     */
    public function getImportSourceType()
    {
        return $this->importSourceType;
    }

    /**
     * @param string $importSourceType
     */
    public function setImportSourceType(string $importSourceType)
    {
        $this->importSourceType = $importSourceType;
    }

    /**
     * @return string
     */
    public function getImportData()
    {
        return $this->importData;
    }

    /**
     * @param string $importData
     */
    public function setImportData(string $importData)
    {
        $this->importData = $importData;
    }

}