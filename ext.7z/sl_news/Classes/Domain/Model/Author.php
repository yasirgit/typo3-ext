<?php

namespace Standardlife\SlNews\Domain\Model;


use TYPO3\CMS\Extbase\DomainObject\AbstractEntity;

/**
 * Class Author
 * @package Standardlife\SlNews\Domain\Model
 * @db
 */
class Author extends AbstractEntity
{

    /**
     * @var string
     * @db
     */
    protected $name;

    /**
     * @var string
     * @db
     */
    protected $function;

    /**
     * @var \TYPO3\CMS\Extbase\Domain\Model\FileReference
     * @db
     */
    protected $image;

    /**
     * @var string
     * @enableRichText
     * @db
     */
    protected $text;

    /**
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * @param string $name
     */
    public function setName($name)
    {
        $this->name = $name;
    }

    /**
     * @return string
     */
    public function getFunction()
    {
        return $this->function;
    }

    /**
     * @param string $function
     */
    public function setFunction($function)
    {
        $this->function = $function;
    }

    /**
     * @return \TYPO3\CMS\Extbase\Domain\Model\FileReference
     */
    public function getImage()
    {
        return $this->image;
    }

    /**
     * @param \TYPO3\CMS\Extbase\Domain\Model\FileReference $image
     */
    public function setImage($image)
    {
        $this->image = $image;
    }

    /**
     * @return mixed
     */
    public function getText()
    {
        return $this->text;
    }

    /**
     * @param mixed $text
     */
    public function setText($text)
    {
        $this->text = $text;
    }

}