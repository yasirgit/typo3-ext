<?php

namespace Standardlife\SlNews\Service\Json;

use OH\Ohmex\Renderer\FluidTemplateRenderer;
use Standardlife\SlNews\Domain\Model\News;
use Standardlife\SlNews\Domain\Repository\NewsRepository;
use Standardlife\Website\Domain\Repository\SysCategoryRepository;
use TYPO3\CMS\Core\SingletonInterface;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Object\ObjectManager;

/**
 * Class NewsService
 * @package Standardlife\SlNews\Service\Json
 */
class NewsService implements SingletonInterface
{

    /** @var FluidTemplateRenderer */
    protected $fluidTemplateRenderer;

    /**
     * List rendered news based on given category and/or tags
     * @param int $contentUid
     * @param int $category
     * @param array $tags
     * @return array
     */
    public function list($contentUid, $category = null, $tags = [])
    {
        /** @var News[] $news */
        $news = $this->getNewsRepository()->findByCategoryAndTags($category, $tags);

        $newsUids = [];
        $hydratedNews = [];
        foreach ($news as $singleNews) {
            switch ($singleNews->getNewsType()) {
                case 'theWayForward':
                    $html = $this->getFluidTemplateRenderer()->render('TheWayForward', [
                        'news' => $singleNews,
                    ]);
                    break;
                case 'pressespiegel':
                    $html = $this->getFluidTemplateRenderer()->render('Pressespiegel', [
                        'news' => $singleNews,
                    ]);
                    break;
                default:
                    $html = $this->getFluidTemplateRenderer()->render('News', [
                        'news' => $singleNews,
                    ]);
            }

            $hydratedNews[] = $html;

            $newsUids[] = $singleNews->getUid();
        }



        $availableTags = $this->getNewsRepository()->findAllAvailableTags($newsUids);
        $availableTags = array_keys($availableTags);

        return [
            'success' => true,
            'news' => $hydratedNews,
            'availableTags' => $availableTags,
        ];
    }

    /**
     * @return NewsRepository
     */
    protected function getNewsRepository()
    {
        /** @var ObjectManager $objectManager */
        $objectManager = GeneralUtility::makeInstance(ObjectManager::class);
        /** @var NewsRepository $newsRepository */
        $newsRepository = $objectManager->get(NewsRepository::class);

        return $newsRepository;
    }

    /**
     * @return SysCategoryRepository
     */
    protected function getSysCategoryRepository()
    {
        /** @var ObjectManager $objectManager */
        $objectManager = GeneralUtility::makeInstance(ObjectManager::class);
        /** @var SysCategoryRepository $sysCategoryRepository */
        $sysCategoryRepository = $objectManager->get(SysCategoryRepository::class);

        return $sysCategoryRepository;
    }

    /**
     * @return FluidTemplateRenderer
     */
    protected function getFluidTemplateRenderer()
    {
        if ($this->fluidTemplateRenderer === null) {
            $this->fluidTemplateRenderer = new FluidTemplateRenderer(
                __DIR__ . '/../../../Resources/Private/Partials/News/'
            );
        }

        return $this->fluidTemplateRenderer;
    }


}