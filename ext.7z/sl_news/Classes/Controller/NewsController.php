<?php

namespace Standardlife\SlNews\Controller;



use Standardlife\Website\Domain\Model\SysCategory;
use TYPO3\CMS\Extbase\Mvc\Controller\ActionController;

use TYPO3\CMS\Frontend\ContentObject\ContentObjectRenderer;

/**
 * Class NewsController
 * @package Standardlife\SlNews\Controller
 */
class NewsController extends ActionController
{
    /** @var ContentObjectRenderer */
    protected $contentObj;
    /** @var array */
    protected $data;

    /**
     * @var \Standardlife\SlNews\Domain\Repository\NewsRepository
     * @inject
     */
    protected $newsRepository;

    /**
     * @var \Standardlife\Website\Domain\Repository\SysCategoryRepository
     * @inject
     */
    protected $sysCategory;

    public function initializeAction()
    {
        $this->contentObj = $this->configurationManager->getContentObject();
        $this->data = $this->contentObj->data;
    }

    /**
     * Display news overview with available categories and tags
     * @plugin News!
     * @noCache
     */
    public function indexAction()
    {
        $sortedCategories = [];
        $categoryIds = [];
        $contentObj = $this->contentObj->data;
        if ($contentObj['pi_flexform'] !== null) {
            $dom = new \DOMDocument();
            $dom->loadXML($contentObj['pi_flexform']);
            $xpath = new \DOMXPath($dom);
            $categoryIds = $xpath->evaluate("string(//T3FlexForms/data/sheet/language/field[@index='settings.categories']/value)");

            $categoryIds = explode(',', $categoryIds);

            $sortedCategories = [];
            foreach ($categoryIds as $categoryId) {
                $sortedCategories[$categoryId] = 1;
            }

            /** @var SysCategory[] $categories */
            $categories = $this->sysCategory->findByUids($categoryIds);
            foreach ($categories as $category) {
                $category->setSubCategories($this->sysCategory->findChildCategories($category));
                $sortedCategories[$category->getUid()] = $category;
            }
        }

        $news = $this->newsRepository->findAllOrdered($categoryIds);
        $tags = $this->newsRepository->findAllAvailableTags();

        $this->view->assignMultiple([
            'data' => $this->data,
            'news' => $news,
            'tags' => $tags,
            'categories' => $sortedCategories,
        ]);
    }

    /**
     * Display news detail content
     * @plugin NewsDetail!
     * @noCache
     */
    public function detailAction()
    {
        $arguments = $this->request->getArguments();
        $uid = $arguments['news'];

        //getArgument('news');

        //$uid = $this->arguments->offsetGet('uid');
        $news = $this->newsRepository->findByUid($uid);

        $this->view->assignMultiple([
            'news' => $news,
        ]);
    }


}