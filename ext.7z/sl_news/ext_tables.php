<?php

if (!defined('TYPO3_MODE')) {
    die('Access denied.');
}


$extPath = \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extPath($_EXTKEY);

// Allow usage of a table on standard page
\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::allowTableOnStandardPages('tx_slnews_domain_model_news');

\HDNET\Autoloader\Loader::extTables('Standardlife', $_EXTKEY);



$GLOBALS['TYPO3_CONF_VARS']['EXT']['fbit_berecordlist']['modules']['sl_news'] = [
    'icon' => 'EXT:sl_news/ext_icon.svg',
    'labels' => 'LLL:EXT:sl_news/Resources/Private/Language/locallang.xlf',
    'navigationComponentId' => '',
    'storagePid' => 114,
    'tables' => [
        'tx_slnews_domain_model_news' => [
            'storagePid' => 114,
            'displayFields' => [
                'news_type' => true,
                'date' => true,
                'scope' => [
                    'displayProcFunc' => \Standardlife\SlNews\Userfunc\Tca::class . '->renderScope',
                ],
            ],
        ],
        'tx_slnews_domain_model_author' => [
            'storagePid' => 115,
            'displayFields' => [
                'function' => true,
                'image' => true,
            ],
        ],
    ],
    // leave empty to use the default "fbit" main module
    'mainModule' => '',
    'moduleLayout' => [
        'header' => [
            'enabled' => true,
            'menu' => [
                'showOneOptionPerTable' => true,
                'showOneOptionPerRecordType' => true,
            ],
            'pagepath' => false,
            'buttons' => [
                'enabled' => true,
                'left' => [
                    'actions-document-new' => false,
                    'actions-page-open' => false,
                    'actions-document-export-csv' => false,
                    'actions-document-export-t3d' => false,
                    // override icon using another registered icon identifier
                    'actions-search' => [
                        'icon' => 'actions-filter'
                    ],
                ],
                'right' => [
                    'actions-system-cache-clear' => false,
                    'actions-refresh' => false,
                    // the following two can not have their icon changed
                    'shortcut' => false,
                    'csh' => false,
                ],
                // You MUST provide every button that will be in the buttons bar after all operations,
                // including the generation of new buttons based on table or record type and the removal
                // of buttons based on the settings above.
                //
                // If the deep count of button identifiers in the sorting array is not exactly equal to the
                // deep count of available buttons, no sorting will be done.
                //
                // Be aware that the sorting also has to include dynamically generated buttons.
                // The core provides the button "actions-document-paste-into" if a record is copied or cut,
                // so make sure to ínclude this identifier wherever you like to have the button.
                'sorting' => [
                    'left' => [
                        [
                            'actions-filter'
                        ],
                        [
                            'icon identifier or icon identifier of table or table type',
                        ],
                    ],
                ]
            ],
            // If true, creates an identifier composed of "tcarecords-[tablename]-default", e.g. tcarecords-tx_ext_domain_model_singletyperecord-default.
            'showOneNewRecordButtonPerTable' => true,
            // If true, creates buttons with the identifier taken from the type item definition in the table's TCA:
            // $GLOBALS['TCA'][tableName]['columns'][$GLOBALS['TCA'][tableName]['typeicon_column']]['config']['items'][itemIndex][2]
            // or if no types are available ($GLOBALS['TCA'][tableName]['typeicon_column'] is empty or not set),
            // creates an identifier composed of "tcarecords-[tablename]-default", e.g. tcarecords-tx_ext_domain_model_singletyperecord-default.
            'showOneNewRecordButtonPerRecordType' => true,
        ],
        'footer' => [
            // false => fully removed, true => fully visible (depending on further configuration),
            // 'accordion' => create footer "show/hide" button
            'enabled' => true,
            // show the list of possible columns to display in the table?
            'fieldselection' => false,
            // show the checkboxes at the bottom?
            'listoptions' => [
                // Use either boolean values to only affect visibility but not the current status determined by
                // the BE-user session values
                //
                // true => visible, status as is; false => invisible, status as is;
                //
                // Or use string values to set visibility and initial checkbox (and thus feature) status
                //
                // 'set-visible' => visible, status is set; 'set-invisible' => invisible, status is set;
                // 'unset-visible' => visible, status is unset; 'unset-invisible' => invisible, status is unset;
                'extendedview' => true,
                'clipboard' => true,
                'localization' => false,
            ],
        ],
    ],
];