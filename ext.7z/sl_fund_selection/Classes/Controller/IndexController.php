<?php

namespace Standardlife\SlFundSelection\Controller;

use SL\Fundselection\Domain\Model\Fund;
use SL\Fundselection\Domain\Repository\FundRepository;
use TYPO3\CMS\Extbase\Mvc\Controller\ActionController;
use TYPO3\CMS\Extbase\Utility\DebuggerUtility;

/**
 * Class IndexController
 * @package Standardlife\SlFundSelection\Controller
 */
class IndexController extends ActionController
{

    /**
     * @var \Standardlife\SlFundSelection\Domain\Repository\FundRepository
     * @inject
     */
    protected $fundRepository;

    /**
     * @var \Standardlife\SlFundSelection\Domain\Repository\FundGroupRepository
     * @inject
     */
    protected $fundGroupRepository;

    /**
     * @var \Standardlife\SlFundSelection\Utility\FundUtil
     * @inject
     */
    protected $fundUtil;

    /**
     * @plugin FundSelection
     * @noCache
     * @return string
     */
    public function indexAction()
    {
        /** @var Fund[] $funds */
        $funds = $this->fundRepository->getFundFrontend();

        $fundGroups = [];
        foreach ($funds as $fund) {
            if ($fund->getFundGroup() !== null) {
                $fundGroups[$fund->getFundGroup()->getUid()] = $fund->getFundGroup();
            }
        }
        $this->view->assignMultiple(array(
            'funds' => $funds,
            'fundGroups' => $fundGroups,
        ));


        return $this->view->render();
    }


}