<?php

namespace Standardlife\SlFundSelection\Domain\Model;

use TYPO3\CMS\Extbase\DomainObject\AbstractEntity;

/**
 * Class Fund
 * @package Standardlife\SlFundSelection
 *
 * @db
 */
class FundGroup extends AbstractEntity
{

    /**
     * @var string
     */
    protected $hidden;
    /**
     * @var string
     * @db
     */
    protected $name;
    /**
     * @var string
     * @db
     */
    protected $cssClass;

    /**
     * @return string
     */
    public function getHidden()
    {
        return $this->hidden;
    }

    /**
     * @param string $hidden
     */
    public function setHidden($hidden)
    {
        $this->hidden = $hidden;
    }

    /**
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * @param string $name
     */
    public function setName($name)
    {
        $this->name = $name;
    }

    /**
     * @return string
     */
    public function getCssClass()
    {
        return $this->cssClass;
    }

    /**
     * @param string $cssClass
     */
    public function setCssClass($cssClass)
    {
        $this->cssClass = $cssClass;
    }

}