<?php

namespace Standardlife\SlFundSelection\Domain\Model;

use TYPO3\CMS\Extbase\DomainObject\AbstractEntity;

/**
 * Class Fund
 * @package Standardlife\SlFundSelection
 *
 * @db
 */
class Fund extends AbstractEntity
{

    /**
     * @var string
     */
    protected $hidden;
    /**
     * @var string
     * @db
     */
    protected $name;
    /**
     * @var \Standardlife\SlFundSelection\Domain\Model\FundGroup
     * @db
     */
    protected $fundGroup;
    /**
     * @var \DateTime
     * @db
     */
    protected $stand;
    /**
     * @var string
     * @db
     */
    protected $risikoklasse;
    /**
     * @var string
     * @db
     */
    protected $manager;
    /**
     * @var \DateTime
     * @db
     */
    protected $auflagedatum;
    /**
     * @var string
     * @db
     */
    protected $waehrung;
    /**
     * @var string
     * @db
     */
    protected $volumen;
    /**
     * @var string
     * @db
     */
    protected $volatilitaet;
    /**
     * @var string
     * @db
     */
    protected $isin;
    /**
     * @var string
     * @db
     */
    protected $isinIntern;
    /**
     * @var string
     * @db
     */
    protected $fundCode;
    /**
     * @var string
     * @db
     */
    protected $performance1;
    /**
     * @var string
     * @db
     */
    protected $performance2;
    /**
     * @var string
     * @db
     */
    protected $performance3;
    /**
     * @var string
     * @db
     */
    protected $performance4;
    /**
     * @var string
     * @db
     */
    protected $performance5;
    /**
     * @var string
     * @db
     */
    protected $seitAuflage;
    /**
     * @var \Standardlife\SlDownload\Domain\Model\Download
     * @db
     */
    protected $kurzpraesentation;
    /**
     * @var \Standardlife\SlDownload\Domain\Model\Download
     * @db
     */
    protected $factsheet;
    /**
     * @var \Standardlife\SlDownload\Domain\Model\Download
     * @db
     */
    protected $wichtigeAnlegerinfo;
    /**
     * @var \TYPO3\CMS\Extbase\Domain\Model\FileReference
     * @db
     */
    protected $chartImage;
    /**
     * @var boolean
     * @db
     */
    protected $notInNewBusiness;
    /**
     * @var string
     * @db
     */
    protected $color;

    /**
     * @var \Standardlife\SlCrd\Domain\Model\Crd
     * @db
     */
    protected $crd;

    /**
     * @return string
     */
    public function getHidden()
    {
        return $this->hidden;
    }

    /**
     * @param string $hidden
     */
    public function setHidden(string $hidden)
    {
        $this->hidden = $hidden;
    }

    /**
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * @param string $name
     */
    public function setName(string $name)
    {
        $this->name = $name;
    }

    /**
     * @return FundGroup
     */
    public function getFundGroup()
    {
        return $this->fundGroup;
    }

    /**
     * @param FundGroup $fundGroup
     */
    public function setFundGroup(FundGroup $fundGroup)
    {
        $this->fundGroup = $fundGroup;
    }

    /**
     * @return \DateTime
     */
    public function getStand()
    {
        return $this->stand;
    }

    /**
     * @param \DateTime $stand
     */
    public function setStand(\DateTime $stand)
    {
        $this->stand = $stand;
    }

    /**
     * @return string
     */
    public function getRisikoklasse()
    {
        return $this->risikoklasse;
    }

    /**
     * @param string $risikoklasse
     */
    public function setRisikoklasse(string $risikoklasse)
    {
        $this->risikoklasse = $risikoklasse;
    }

    /**
     * @return string
     */
    public function getManager()
    {
        return $this->manager;
    }

    /**
     * @param string $manager
     */
    public function setManager(string $manager)
    {
        $this->manager = $manager;
    }

    /**
     * @return \DateTime
     */
    public function getAuflagedatum()
    {
        return $this->auflagedatum;
    }

    /**
     * @param \DateTime $auflagedatum
     */
    public function setAuflagedatum(\DateTime $auflagedatum)
    {
        $this->auflagedatum = $auflagedatum;
    }

    /**
     * @return string
     */
    public function getWaehrung()
    {
        return $this->waehrung;
    }

    /**
     * @param string $waehrung
     */
    public function setWaehrung(string $waehrung)
    {
        $this->waehrung = $waehrung;
    }

    /**
     * @return string
     */
    public function getVolumen()
    {
        return $this->volumen;
    }

    /**
     * @param string $volumen
     */
    public function setVolumen(string $volumen)
    {
        $this->volumen = $volumen;
    }

    /**
     * @return string
     */
    public function getVolatilitaet()
    {
        return $this->volatilitaet;
    }

    /**
     * @param string $volatilitaet
     */
    public function setVolatilitaet(string $volatilitaet)
    {
        $this->volatilitaet = $volatilitaet;
    }

    /**
     * @return string
     */
    public function getIsin()
    {
        return $this->isin;
    }

    /**
     * @param string $isin
     */
    public function setIsin(string $isin)
    {
        $this->isin = $isin;
    }

    /**
     * @return string
     */
    public function getIsinIntern()
    {
        return $this->isinIntern;
    }

    /**
     * @param string $isinIntern
     */
    public function setIsinIntern(string $isinIntern)
    {
        $this->isinIntern = $isinIntern;
    }

    /**
     * @return string
     */
    public function getFundCode()
    {
        return $this->fundCode;
    }

    /**
     * @param string $fundCode
     */
    public function setFundCode(string $fundCode)
    {
        $this->fundCode = $fundCode;
    }

    /**
     * @return string
     */
    public function getPerformance1()
    {
        return $this->performance1;
    }

    /**
     * @param string $performance1
     */
    public function setPerformance1(string $performance1)
    {
        $this->performance1 = $performance1;
    }

    /**
     * @return string
     */
    public function getPerformance2()
    {
        return $this->performance2;
    }

    /**
     * @param string $performance2
     */
    public function setPerformance2(string $performance2)
    {
        $this->performance2 = $performance2;
    }

    /**
     * @return string
     */
    public function getPerformance3()
    {
        return $this->performance3;
    }

    /**
     * @param string $performance3
     */
    public function setPerformance3(string $performance3)
    {
        $this->performance3 = $performance3;
    }

    /**
     * @return string
     */
    public function getPerformance4()
    {
        return $this->performance4;
    }

    /**
     * @param string $performance4
     */
    public function setPerformance4(string $performance4)
    {
        $this->performance4 = $performance4;
    }

    /**
     * @return string
     */
    public function getPerformance5()
    {
        return $this->performance5;
    }

    /**
     * @param string $performance5
     */
    public function setPerformance5(string $performance5)
    {
        $this->performance5 = $performance5;
    }

    /**
     * @return string
     */
    public function getSeitAuflage()
    {
        return $this->seitAuflage;
    }

    /**
     * @param string $seitAuflage
     */
    public function setSeitAuflage(string $seitAuflage)
    {
        $this->seitAuflage = $seitAuflage;
    }

    /**
     * @return \Standardlife\SlDownload\Domain\Model\Download
     */
    public function getKurzpraesentation()
    {
        return $this->kurzpraesentation;
    }

    /**
     * @param \Standardlife\SlDownload\Domain\Model\Download $kurzpraesentation
     */
    public function setKurzpraesentation(\Standardlife\SlDownload\Domain\Model\Download $kurzpraesentation)
    {
        $this->kurzpraesentation = $kurzpraesentation;
    }

    /**
     * @return \Standardlife\SlDownload\Domain\Model\Download
     */
    public function getFactsheet()
    {
        return $this->factsheet;
    }

    /**
     * @param \Standardlife\SlDownload\Domain\Model\Download $factsheet
     */
    public function setFactsheet(\Standardlife\SlDownload\Domain\Model\Download $factsheet)
    {
        $this->factsheet = $factsheet;
    }

    /**
     * @return \Standardlife\SlDownload\Domain\Model\Download
     */
    public function getWichtigeAnlegerinfo()
    {
        return $this->wichtigeAnlegerinfo;
    }

    /**
     * @param \Standardlife\SlDownload\Domain\Model\Download $wichtigeAnlegerinfo
     */
    public function setWichtigeAnlegerinfo(\Standardlife\SlDownload\Domain\Model\Download $wichtigeAnlegerinfo)
    {
        $this->wichtigeAnlegerinfo = $wichtigeAnlegerinfo;
    }

    /**
     * @return \TYPO3\CMS\Extbase\Domain\Model\FileReference
     */
    public function getChartImage()
    {
        return $this->chartImage;
    }

    /**
     * @param \TYPO3\CMS\Extbase\Domain\Model\FileReference $chartImage
     */
    public function setChartImage(\TYPO3\CMS\Extbase\Domain\Model\FileReference $chartImage)
    {
        $this->chartImage = $chartImage;
    }

    /**
     * @return bool
     */
    public function isNotInNewBusiness()
    {
        return $this->notInNewBusiness;
    }

    /**
     * @param bool $notInNewBusiness
     */
    public function setNotInNewBusiness(bool $notInNewBusiness)
    {
        $this->notInNewBusiness = $notInNewBusiness;
    }

    /**
     * @return string
     */
    public function getColor()
    {
        return $this->color;
    }

    /**
     * @param string $color
     */
    public function setColor($color)
    {
        $this->color = $color;
    }

    /**
     * @return \Standardlife\SlCrd\Domain\Model\Crd
     */
    public function getCrd()
    {
        return $this->crd;
    }

    /**
     * @param \Standardlife\SlCrd\Domain\Model\Crd $crd
     */
    public function setCrd(\Standardlife\SlCrd\Domain\Model\Crd $crd)
    {
        $this->crd = $crd;
    }

}