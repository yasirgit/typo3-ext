<?php

namespace Standardlife\SlFundSelection\Domain\Model;

use TYPO3\CMS\Extbase\DomainObject\AbstractEntity;

/**
 * Class FundPrice
 * @package Standardlife\SlFundSelection
 *
 * @db
 */
class FundPrice extends AbstractEntity
{

    /**
     * @var \Standardlife\SlFundSelection\Domain\Model\Fund
     */
    protected $fund;
    /**
     * @var \DateTime
     */
    protected $priceDate;
    /**
     * @var float
     */
    protected $price;
    /**
     * @var float
     */
    protected $prevPrice;

    /**
     * @return Fund
     */
    public function getFund()
    {
        return $this->fund;
    }

    /**
     * @param Fund $fund
     */
    public function setFund($fund)
    {
        $this->fund = $fund;
    }

    /**
     * @return \DateTime
     */
    public function getPriceDate()
    {
        return $this->priceDate;
    }

    /**
     * @param \DateTime $priceDate
     */
    public function setPriceDate($priceDate)
    {
        $this->priceDate = $priceDate;
    }

    /**
     * @return float
     */
    public function getPrice()
    {
        return $this->price;
    }

    /**
     * @param float $price
     */
    public function setPrice($price)
    {
        $this->price = $price;
    }

    /**
     * @return float
     */
    public function getPrevPrice()
    {
        return $this->prevPrice;
    }

    /**
     * @param float $prevPrice
     */
    public function setPrevPrice($prevPrice)
    {
        $this->prevPrice = $prevPrice;
    }
}