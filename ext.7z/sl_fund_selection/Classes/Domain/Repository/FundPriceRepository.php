<?php

namespace Standardlife\SlFundSelection\Domain\Repository;

use TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings;
use TYPO3\CMS\Extbase\Persistence\Repository;

/**
 * Class FundPriceRepository
 * @package SL\Fundselection\Domain\Repository
 */
class FundPriceRepository extends Repository {

    /**
     * Initialization default query settings
     */
    public function initializeObject() {
        /* @var $querySettings Typo3QuerySettings */
        $querySettings = $this->objectManager->get(Typo3QuerySettings::class);

        $querySettings->setRespectStoragePage(false);

        $this->setDefaultQuerySettings($querySettings);
    }

    /**
     * Retrieve chart data from database
     * @param int $fundId
     * @param string $minDate SQL date string
     * @param bool $isPopup
     * @param bool $isWideChart
     * @param bool $myfolio
     * @return array|\TYPO3\CMS\Extbase\Persistence\QueryResultInterface
     */
    public function getChartData($fundId, $minDate, $isPopup = false, $isWideChart = false, $myfolio = false)
    {
        $cols = 'fp.*';
        $tables = 'tx_slfundselection_domain_model_fundprice fp INNER JOIN tx_slfundselection_domain_model_fund f on (fp.fund = f.uid)';
        $where = 'f.deleted=0 AND ';

        if($myfolio){
            $where .= 'f.uid IN (3,6,7)';
        }
        else{
            $where .= 'f.uid = ' . (int)$fundId;
        }

        $where .= ' and f.hidden = 0';

        if(!$isPopup && !$isWideChart) {
            // restriction - used for overview page
            $where .= ' and fp.price_date >= "' . $minDate . '"';
        }
        $where .= ' order by fp.price_date desc ';

        $query = $this->createQuery();
        $query->statement('SELECT ' . $cols . ' FROM ' . $tables . ' WHERE ' . $where);

        $result = $query->execute(true);

        return $result;
    }

    /**
     * Check if chart content is existent
     * @param int $fundId
     * @return bool
     */
    public function checkChartContentExists($fundId) {
        $query = $this->createQuery();
        $query->getQuerySettings()->setRespectStoragePage(false);


        $where = '';
        $statement = 'SELECT count(*) priceCount
                       FROM tx_slfundselection_domain_model_fundprice fp
                       INNER JOIN tx_slfundselection_domain_model_fund f ON (fp.fund = f.uid)';


        $where .= ' f.deleted = 0 AND fp.deleted = 0 AND f.uid = ' . (int)$fundId;

        $statement .= ' WHERE ' . $where;

        $query->statement($statement);

        $result = $query->execute(true);

        if ($result[0]['priceCount'] > 0) {
            return true;
        }

        return false;
    }

}