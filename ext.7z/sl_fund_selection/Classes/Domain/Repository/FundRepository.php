<?php

namespace Standardlife\SlFundSelection\Domain\Repository;

use TYPO3\CMS\Extbase\Persistence\Repository;
use TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings;


/**
 * Class FundRepository
 * @package Standardlife\SlFundSelection\Domain\Repository
 */
class FundRepository extends Repository {

    public function initializeObject() {
        /* @var $querySettings \TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings */
        $querySettings = $this->objectManager->get(Typo3QuerySettings::class);

        $querySettings->setRespectStoragePage(false);

        $this->setDefaultQuerySettings($querySettings);
    }

    /**
     * @return array
     */
    public function findAll()
    {
        $query = $this->createQuery();
        $query->getQuerySettings()->setRespectStoragePage(false);

        $query->setOrderings(['sort' => $query::ORDER_ASCENDING]);
        $result = $query->execute();

        return $result->toArray();
    }

    /**
     * @param array $groupIds
     * @param array $fundIds
     * @return array
     */
    public function getFundFrontend($groupIds = array(), $fundIds = array()) {
        $query = $this->createQuery();
        $query->getQuerySettings()->setRespectStoragePage(false);


        $statement = 'SELECT DISTINCT f.*
                       FROM tx_slfundselection_domain_model_fund f';

        $where = '1';
        $orderBy = '';
        if (!empty($groupIds)) {
            $where .= ' and f.fund_group IN (' . join(', ', $groupIds ) . ')';
        }

        if (!empty($fundIds)) {
            $where .= ' and f.uid IN (' . join(', ', $fundIds ) . ')';
        }



        if($orderBy == ''){
            $orderBy = 'f.sorting, f.name';
        }

        $where .= ' and f.hidden = 0';

        $statement .= ' WHERE ' . $where . ' ORDER BY ' . $orderBy;

        $query->statement($statement);

        $result = $query->execute()->toArray();

        return $result;
    }

}