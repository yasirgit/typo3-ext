<?php

namespace Standardlife\SlFundSelection\Domain\Repository;

use TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings;
use TYPO3\CMS\Extbase\Persistence\Repository;
use TYPO3\CMS\Extbase\Utility\DebuggerUtility;


/**
 * Class FundGroupRepository
 * @package Standardlife\SlFundSelection\Domain\Repository
 */
class FundGroupRepository extends Repository {

    public function initializeObject() {
        /* @var $querySettings \TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings */
        $querySettings = $this->objectManager->get(Typo3QuerySettings::class);

        $querySettings->setRespectStoragePage(false);

        $this->setDefaultQuerySettings($querySettings);
    }

    /**
     * @return array
     */
    public function findAll()
    {
        $query = $this->createQuery();
        $query->getQuerySettings()->setRespectStoragePage(false);

        $result = $query->execute();

        return $result->toArray();
    }

    /**
     * @param $fundIds
     * @return array
     */
    public function findByFunds($fundIds)
    {

        if (!is_array($fundIds) || empty($fundIds)) {
            return array();
        }

        $query = $this->createQuery();
        $query->getQuerySettings()->setRespectStoragePage(false);

        $statement = 'SELECT DISTINCT fg.*
                      FROM tx_slfundselection_domain_model_fundgroup fg
                      JOIN tx_slfundselection_domain_model_fund f ON (f.fund_group = fg.uid)
                      WHERE f.uid IN (' . join(', ', $fundIds) . ')';


        $query->statement($statement);

        $result = $query->execute();

        return $result->toArray();
    }

}