<?php
namespace Standardlife\SlFundSelection\Tasks;

use Standardlife\SlFundSelection\Jobs\FundPriceImportJob;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Object\ObjectManager;
use TYPO3\CMS\Scheduler\Task\AbstractTask;

/**
 * Class FundPriceImportTask
 * @package Standardlife\SlFundSelection\Tasks
 */
class FundPriceImportTask extends AbstractTask
{

    public function execute()
    {
        $success = true;
        /** @var \TYPO3\CMS\Extbase\Object\ObjectManager $objectManager */
        $objectManager = GeneralUtility::makeInstance(ObjectManager::class);

        /** @var FundPriceImportJob $importJob */
        $importJob = $objectManager->get(FundPriceImportJob::class);
        $importJob->run();

        return $success;
    }

}