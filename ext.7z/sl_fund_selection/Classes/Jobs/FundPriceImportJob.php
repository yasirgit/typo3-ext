<?php

namespace Standardlife\SlFundSelection\Jobs;

use Standardlife\SlFundSelection\Domain\Model\FundPrice;
use Standardlife\SlFundSelection\Domain\Repository\FundPriceRepository;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Object\ObjectManager;
use TYPO3\CMS\Extbase\Persistence\Generic\PersistenceManager;
use TYPO3\CMS\Extbase\Service\CacheService;

/**
 * Class FundPriceImportJob
 * @package Standardlife\SlFundSelection\Jobs
 */
class FundPriceImportJob
{

    protected $fundPricePid = 99; // pageId - get from config

    /**
     * @return array
     */
    public function run()
    {
        $importUrl = '';
        $fundPrices = $this->getData($importUrl);

        $this->processFundPrices($fundPrices, $this->fundPricePid);

        /** @var ObjectManager $objectManager */
        $objectManager = GeneralUtility::makeInstance(ObjectManager::class);
        /** @var CacheService $cacheService */
        $cacheService = $objectManager->get(CacheService::class);

        // clear page cache of pages
        $cacheService->clearPageCache([]); // insert page ids of display pages

        return [];
    }

    /**
     * @param array $items
     * @param int $pid
     */
    protected function processFundPrices($items, $pid)
    {
        /** @var ObjectManager $objectManager */
        $objectManager = GeneralUtility::makeInstance(ObjectManager::class);
        /** @var PersistenceManager $persistenceManager */
        $persistenceManager = $objectManager->get(PersistenceManager::class);

        /** @var FundPriceRepository $fundPriceRepository */
        $fundPriceRepository = $objectManager->get(FundPriceRepository::class);

        // iterate through items and set additional data. add or update in database
        foreach ($items as $item) {
            /** @var FundPrice $item */

            $item->setPid($pid);

            if ($item->getUid() === null) {
                $fundPriceRepository->add($item);
            } else {
                $fundPriceRepository->update($item);
            }

            $persistenceManager->persistAll();
        }
    }

    /**
     * Retrieve data from importUrl and map to objects
     * @param string $importUrl
     * @return FundPrice[]
     */
    protected function getData($importUrl)
    {
        $xml = simplexml_load_file($importUrl);

        /** @var FundPrice[] $items */
        $items = [];
        foreach ($xml->channel->item as $node) {
            $item = new FundPrice();
            $item->setPrice(floatval($node->price));

            $items[] = $item;
        }

        return $items;
    }

}