<?php

namespace Standardlife\SlFundSelection\Utility;

use OH\Ohmex\Renderer\FluidTemplateRenderer;
use SL\Fundselection\Domain\Model\Fund;
use SL\Fundselection\Domain\Model\FundPrice;

/**
 * Class FundUtil
 * @package Standardlife\SlFundSelection\Utility
 */
class FundUtil
{

    /**
     * @var \Standardlife\SlFundSelection\Domain\Repository\FundGroupRepository
     * @inject
     */
    protected $fundGroupRepository;
    /**
     * @var \Standardlife\SlFundSelection\Domain\Repository\FundPriceRepository
     * @inject
     */
    protected $fundPriceRepository;
    /**
     * @var \Standardlife\SlFundSelection\Domain\Repository\FundRepository
     * @inject
     */
    protected $fundRepository;

    protected $colorCodeArr = array(
        'fundsRed' => '#dc002e',
        'fundsOrange' => '#e67d00',
        'fundsYellow' => '#ffcb05',
        'fundsBlue1' => '#81c2e3',
        'fundsBlue2' => '#008ac9',
        'fundsBlue3' => '#0061a1',
        'fundsBlue4' => '#26afdd',
        'fundsBlue5' => '#00285f',
        'fundsGreen1' => '#6a9519',
        'fundsGreen2' => '#a6bc74',
        'fundsLilac' => '#be8dae',
        'fundsPurple' => '#933175',
        'fundsApricot' => '#e6695c'
    );

    /**
     * @param array $funds
     * @return array
     */
    public function getFrontendData($funds)
    {
        $groupedFunds = array();

        $fundIds = array();
        $fundGroupIcons = array();
        foreach ($funds as $fund) {
            /** @var $fund Fund */
            $groupId = $fund->getFundGroup()->getUid();

            $fundIds[] = $fund->getUid();
            if (!array_key_exists($groupId, $groupedFunds)) {
                $groupedFunds[$groupId] = array();
            }
            if (!array_key_exists($groupId, $fundGroupIcons)) {
                $fundGroupIcons[$groupId] = array();
            }

            $groupedFunds[$groupId][] = $fund;
            $fundGroupIcons[$groupId][$fund->getColor()] = $fund->getColor();
        }

        $fundGroups = $this->fundGroupRepository->findByFunds($fundIds);
        $groupedFundGroups = array();
        foreach ($fundGroups as $fundGroup) {
            $groupId = $fundGroup->getUid();
            $groupedFundGroups[$groupId] = $fundGroup;
        }


        return array(
            'groupedFunds' => $groupedFunds,
            'groupedFundGroups' => $groupedFundGroups,
            'fundGroupIcons' => $fundGroupIcons,
        );
    }

    /**
     * @param Fund $fund
     * @param bool $isPopup
     * @param bool $isWide
     * @return string
     */
    public function getChartEmbedHtml(Fund $fund, $isPopup = false, $isWide = false){

        $hasFundChart = $this->fundPriceRepository->checkChartContentExists($fund->getUid());


        $html = $this->getFluidTemplateRenderer()->render(
            'Chart',
            array(
                'fund' => $fund,
                'isPopup' => $isPopup,
                'isWide' => $isWide,
                'hasFundChart' => $hasFundChart,
            )
        );

        return $html;
    }

    /**
     * @param $fundID
     * @param $isPopup
     * @param $isJewelPopup
     * @param $isWideChart
     * @return array
     */
    public function getChartJson($fundID, $isPopup, $isJewelPopup, $isWideChart){

        $rowsArr    = array();
        $returnArr  = array();
        $myfolioDataArr = array();

        $isPopup        = $isPopup == 'true' ? true : false;
        $isJewelPopup   = $isJewelPopup == 'true' ? true : false;
        $isWideChart    = $isWideChart == 'true' ? true : false;

        $minDate = date('Y-m-d', mktime(0, 0, 0, date("m"), date("d"), date("Y")-1));

        //extrawurst nur wenn myfolio und popup!
        $myfolio = $fundID == 3 && (($isPopup && $isJewelPopup) || $isWideChart) ? true : false;

        $fundPrices = $this->fundPriceRepository->getChartData($fundID, $minDate, $isPopup, $isWideChart, $myfolio);

        if(count($fundPrices) > 0){
            $chartArr = array(
                'cols' => array(
                    array('id' => '', 'label' => '', 'pattern' => '', 'type' => 'date'),
                    array('id' => '', 'label' => '', 'pattern' => '', 'type' => 'number')
                ),
                'rows' => array());
            $even = false;

            foreach ($fundPrices as $fundPrice) {
                $even = $even ? false : true;
                if($myfolio){
                    $priceDateArr = explode('-', $fundPrice['price_date']);
                    $month = (int)$priceDateArr['1'] -1;
                    $dateStr = (int)$priceDateArr['0'] . ', ' . $month . ', ' . (int)$priceDateArr['2'];
                    $price = $fundPrice['price'];
                    $myfolioDataArr[$dateStr][$fundPrice['fund']] = $price;
                }elseif($even || $isPopup) {
                    //in der uebersicht einschraenken
                    $priceDateArr = explode('-', $fundPrice['price_date']);
                    $month = (int)$priceDateArr['1'] -1;
                    $dateStr = (int)$priceDateArr['0'] . ', ' . $month . ', ' . (int)$priceDateArr['2'];
                    $price = $fundPrice['price'];
                    $rowsArr[] = array('c' => array(array('v' => 'Date(' . $dateStr . ')', 'f' => null), array('v' => $price, 'f' => null)));
                }
            }

            if($myfolio){
                $chartArr['cols'][] = array('id' => '', 'label' => '', 'pattern' => '', 'type' => 'number');
                $chartArr['cols'][] = array('id' => '', 'label' => '', 'pattern' => '', 'type' => 'number');
                foreach($myfolioDataArr as $dateStr => $pricesArr){
                    $rowsArr[] = array('c' => array(array('v' => 'Date(' . $dateStr . ')', 'f' => null),
                        array('v' => $pricesArr[3], 'f' => null),
                        array('v' => $pricesArr[6], 'f' => null),
                        array('v' => $pricesArr[7], 'f' => null)
                    ));
                }
                $fundIDArr = array(3,6,7);

            }
            else{
                $fundIDArr = array($fundID);
            }

            $colorArr = array();


            $funds = $this->fundRepository->getFundFrontend(array(), $fundIDArr);

            foreach ($funds as $fund) {
                /** @var Fund $fund */
                $colorArr[] = $this->colorCodeArr[$fund->getColor()];
            }


            $fundArr = array('color' => $colorArr);


            $chartArr['rows'] = $rowsArr;



            $returnArr = array('chartArr' => $chartArr, 'fundArr' => $fundArr);

        }

        return $returnArr;
    }

    /**
     * @return FluidTemplateRenderer
     */
    protected function getFluidTemplateRenderer()
    {
        return new FluidTemplateRenderer(
            __DIR__ . '/../../Resources/Private/Views/',
            __DIR__ . '/../../Resources/Private/Partials/'
        );
    }
}