<?php

namespace Standardlife\SlFundSelection\Service\Json;

use OH\Ohmex\Renderer\FluidTemplateRenderer;
use Standardlife\SlFundSelection\Domain\Repository\FundRepository;
use TYPO3\CMS\Core\SingletonInterface;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Object\ObjectManager;

/**
 * Class NewsService
 * @package Standardlife\SlFundSelection\Service\Json
 */
class FundService implements SingletonInterface
{

    /** @var FluidTemplateRenderer */
    protected $fluidTemplateRenderer;

    /**
     * Deliver rendered fund details
     * @param int $fundUid
     * @return array
     */
    public function detail($fundUid)
    {
        /** @var Fund $fund */
        $fund = $this->getFundRepository()->findByUid($fundUid);

        $html = $this->getFluidTemplateRenderer()->render('Detail', [
            'fund' => $fund,
        ]);

        return [
            'success' => true,
            'html' => $html,
            'color' => $fund->getColor(),
        ];
    }

    /**
     * @return FundRepository
     */
    protected function getFundRepository()
    {
        /** @var ObjectManager $objectManager */
        $objectManager = GeneralUtility::makeInstance(ObjectManager::class);
        /** @var FundRepository $fundRepository */
        $fundRepository = $objectManager->get(FundRepository::class);

        return $fundRepository;
    }

    /**
     * @return FluidTemplateRenderer
     */
    protected function getFluidTemplateRenderer()
    {
        if ($this->fluidTemplateRenderer === null) {
            $this->fluidTemplateRenderer = new FluidTemplateRenderer(
                __DIR__ . '/../../../Resources/Private/Partials/Funds/'
            );
        }

        return $this->fluidTemplateRenderer;
    }


}