<?php

namespace Standardlife\SlFundSelection\Hooks;


use TYPO3\CMS\Core\Utility\ExtensionManagementUtility;

/**
 * Class FundSelectionWizardItem
 * @package Standardlife\SlFundSelection\Hooks
 */
class FundSelectionWizardItem {

    const KEY = 'slfundselection_fundselection';

    /**
     * Processing the wizard items array
     *
     * @param array $wizardItems The wizard items
     * @return array array with wizard items
     */
    public function proc($wizardItems) {
        $wizardItems['plugins_tx_' . self::KEY] = array(
            'icon'			=> ExtensionManagementUtility::extPath('sl_fund_selection' /*self::KEY*/) . 'Resources/Public/Icons/ce_wiz.gif',
            'title'			=> 'Fund Selection', //$GLOBALS['LANG']->sL('LLL:EXT:news/Resources/Private/Language/locallang_be.xlf:pi1_title'),
            'description'	=> 'Display funds', //$GLOBALS['LANG']->sL('LLL:EXT:news/Resources/Private/Language/locallang_be.xlf:pi1_plus_wiz_description'),
            'params'		=> '&defVals[tt_content][CType]=list&defVals[tt_content][list_type]=' . self::KEY // . '_pi1'
        );

        return $wizardItems;
    }

} 