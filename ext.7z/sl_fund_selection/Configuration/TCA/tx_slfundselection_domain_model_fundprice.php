<?php

use HDNET\Autoloader\Utility\ArrayUtility;
use HDNET\Autoloader\Utility\ModelUtility;

// return (function () {

    $base = ModelUtility::getTcaInformation(\Standardlife\SlFundSelection\Domain\Model\FundPrice::class);

    // custom manipulation calls here
    $custom = [];

    return ArrayUtility::mergeRecursiveDistinct($base, $custom);

// })();
