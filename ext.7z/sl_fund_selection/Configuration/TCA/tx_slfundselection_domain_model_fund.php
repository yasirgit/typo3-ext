<?php

use HDNET\Autoloader\Utility\ArrayUtility;
use HDNET\Autoloader\Utility\ModelUtility;

// return (function () {

$base = ModelUtility::getTcaInformation(\Standardlife\SlFundSelection\Domain\Model\Fund::class);

// custom manipulation calls here
$custom = [
    'columns' => [
        'stand' => [
            'config' => [
                'eval' => 'date',
            ],
        ],

        'auflagedatum' => [
            'config' => [
                'eval' => 'date',
            ],
        ],

        'risikoklasse' => [
            'config' => [
                'type' => 'select',
                'items' => [
                    [1, 1],
                    [2, 2],
                    [3, 3],
                    [4, 4],
                    [5, 5],
                    [6, 6],
                    [7, 7],
                ],
            ],
        ],

        'color' => [
            'config' => [
                'type' => 'select',
                'items' => [
                    ['blue01', 'fundsBlue01'],
                    ['blue02', 'fundsBlue02'],
                    ['blue03', 'fundsBlue03'],
                    ['blue04', 'fundsBlue04'],
                    ['blue05', 'fundsBlue05'],
                    ['blue06', 'fundsBlue06'],
                    ['green01', 'fundsGreen01'],
                    ['green02', 'fundsGreen02'],
                    ['green03', 'fundsGreen03'],
                    ['green04', 'fundsGreen04'],
                    ['purple01', 'fundsPurple01'],
                    ['yellow01', 'fundsYellow01'],
                    ['orange01', 'fundsOrange01'],
                ],
            ],
        ],

        'waehrung' => [
            'config' => [
                'type' => 'select',
                'items' => [
                    ['EUR', 'EUR'],
                    ['USD', 'USD'],
                ],
            ],
        ],

        'fund_group' => [
            'config' => [
                'type' => 'select',
                'foreign_table' => 'tx_slfundselection_domain_model_fundgroup',
                'foreign_table_where' => 'AND tx_slfundselection_domain_model_fundgroup.sys_language_uid IN (-1,0)',
                /*'items' => [
                    ['', -1],
                ],*/
            ],
        ],

        'kurzpraesentation' => [
            'config' => [
                'type' => 'group',
                'internal_type' => 'db',
                'allowed' => 'tx_sldownload_domain_model_download',
                'size' => 1,
                'maxitems' => 1,
                'minitems' => 0,
                'foreign_table' => 'tx_sldownload_domain_model_download',
                'foreign_table_where' => 'AND tx_sldownload_domain_model_download.deleted = 0
                                        AND tx_sldownload_domain_model_download.hidden = 0
                                        AND tx_sldownload_domain_model_download.t3ver_oid = 0
                                        ORDER BY tx_sldownload_domain_model_download.name',
                'show_thumbs' => 1,

                'wizards' => [
                    'suggest' => [
                        'type' => 'suggest',
                    ],
                ],
            ],
        ],

        'wichtige_anlegerinfo' => [
            'config' => [
                'type' => 'group',
                'internal_type' => 'db',
                'allowed' => 'tx_sldownload_domain_model_download',
                'size' => 1,
                'maxitems' => 1,
                'minitems' => 0,
                'foreign_table' => 'tx_sldownload_domain_model_download',
                'foreign_table_where' => 'AND tx_sldownload_domain_model_download.deleted = 0
                                        AND tx_sldownload_domain_model_download.hidden = 0
                                        AND tx_sldownload_domain_model_download.t3ver_oid = 0
                                        ORDER BY tx_sldownload_domain_model_download.name',
                'show_thumbs' => 1,

                'wizards' => [
                    'suggest' => [
                        'type' => 'suggest',
                    ],
                ],
            ],
        ],

        'factsheet' => [
            'config' => [
                'type' => 'group',
                'internal_type' => 'db',
                'allowed' => 'tx_sldownload_domain_model_download',
                'size' => 1,
                'maxitems' => 1,
                'minitems' => 0,
                'foreign_table' => 'tx_sldownload_domain_model_download',
                'foreign_table_where' => 'AND tx_sldownload_domain_model_download.deleted = 0
                                        AND tx_sldownload_domain_model_download.hidden = 0
                                        AND tx_sldownload_domain_model_download.t3ver_oid = 0
                                        ORDER BY tx_sldownload_domain_model_download.name',
                'show_thumbs' => 1,

                'wizards' => [
                    'suggest' => [
                        'type' => 'suggest',
                    ],
                ],
            ],
        ],


    ],

    'palettes' => [
        'main' => [
            'showitem' => 'name, stand',
        ],
        'codes' => [
            'showitem' => 'isin, isin_intern, --linebreak--, fund_code'
        ],
        'performance' => [
            'showitem' => 'performance1, performance2, performance3, performance4, seit_auflage'
        ],
        'files' => [
            'showitem' => 'kurzpraesentation, wichtige_anlegerinfo, --linebreak--, factsheet, chart_image'
        ],
        'manager_date' => [
            'showitem' => 'manager, auflagedatum'
        ],
        'volume_currency' => [
            'showitem' => 'volumen, waehrung, --linebreak--, volatilitaet'
        ],
        'group_risikoklasse' => [
            'showitem' => 'fund_group, risikoklasse, --linebreak--, color'
        ],
    ],

    'types' => [
        '1' => [
            'showitem' => ',--div--;Fund
                                   ,--palette--;;main
                                   ,--palette--;;group_risikoklasse
                                   ,--palette--;;manager_date
                                   ,--palette--;;volume_currency
                                   ,--palette--;;codes
                                   ,--palette--;Performance;performance
                                   ,--palette--;;files
                               ,--div--;Anzeigeoptionen
                                   ,--palette--;LLL:EXT:frontend/Resources/Private/Language/locallang_tca.xlf:pages.palettes.access;access
                               ,--div--;CRD
                                   ,crd
                               '
        ],
    ],
];

$tca = ArrayUtility::mergeRecursiveDistinct($base, $custom);

if (\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::isLoaded('sl_crd')) {
    $tca = \Standardlife\SlCrd\Utilities\CrdUtil::addTca($tca);
}

return $tca;

// })();
