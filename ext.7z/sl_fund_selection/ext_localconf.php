<?php

if (!defined('TYPO3_MODE')) {
    die('Access denied.');
}

\HDNET\Autoloader\Loader::extLocalconf('Standardlife', $_EXTKEY);


$GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['scheduler']['tasks'][\Standardlife\SlFundSelection\Tasks\FundPriceImportTask::class] = [
    'extension' => $_EXTKEY,
    'title' => 'Fund Selection | Fund Price Import',
    'description' => 'Import-Service for fund prices',
];