<?php

namespace Standardlife\SlQuickAccess\Controller;

use TYPO3\CMS\Extbase\Mvc\Controller\ActionController;

/**
 * Class QuickAccessController
 * @package Standardlife\SlQuickAccess\Controller
 */
class QuickAccessController extends ActionController
{

    /**
     * @var \Standardlife\SlQuickAccess\Domain\Repository\QuickAccessEntryRepository
     * @inject
     */
    protected $quickAccessEntryRepository;

    /**
     * Display active quick access entries
     * @plugin QuickAccess!
     */
    public function indexAction()
    {
        $items = $this->quickAccessEntryRepository->findActive();

        $this->view->assignMultiple([
            'items' => $items,
        ]);
    }

}