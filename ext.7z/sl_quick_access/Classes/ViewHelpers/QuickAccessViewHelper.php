<?php

namespace Standardlife\SlQuickAccess\ViewHelpers;

use OH\Ohmex\Renderer\FluidTemplateRenderer;
use Standardlife\SlQuickAccess\Domain\Repository\QuickAccessEntryRepository;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Object\ObjectManager;
use TYPO3Fluid\Fluid\Core\ViewHelper\AbstractViewHelper;

/**
 * Class QuickAccessViewHelper
 * @package Standardlife\SlQuickAccess\ViewHelpers
 */
class QuickAccessViewHelper extends AbstractViewHelper
{

    /** @var FluidTemplateRenderer */
    protected $fluidTemplateRenderer;

    /**
     * @return string
     */
    public function render()
    {
        /** @var ObjectManager $objectManager */
        $objectManager = GeneralUtility::makeInstance(ObjectManager::class);

        /** @var QuickAccessEntryRepository $quickAccessEntryRepository */
        $quickAccessEntryRepository = $objectManager->get(QuickAccessEntryRepository::class);

        $items = $quickAccessEntryRepository->findActive();

        $html = $this->getFluidTemplateRenderer()->render('Index', [
            'items' => $items,
        ]);

        return $html;
    }

    /**
     * @return FluidTemplateRenderer
     */
    protected function getFluidTemplateRenderer()
    {
        if ($this->fluidTemplateRenderer === null) {
            $this->fluidTemplateRenderer = new FluidTemplateRenderer(
                __DIR__ . '/../../Resources/Private/Templates/QuickAccess/'
            );
        }

        return $this->fluidTemplateRenderer;
    }

}
