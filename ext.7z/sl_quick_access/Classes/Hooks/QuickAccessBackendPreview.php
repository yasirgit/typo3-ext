<?php

namespace Standardlife\SlQuickAccess\Hooks;


use OH\Ohmex\Renderer\FluidTemplateRenderer;
use Standardlife\SlQuickAccess\Domain\Model\QuickAccessEntry;
use Standardlife\SlQuickAccess\Domain\Repository\QuickAccessEntryRepository;
use TYPO3\CMS\Backend\View\PageLayoutView;
use TYPO3\CMS\Backend\View\PageLayoutViewDrawItemHookInterface;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Object\ObjectManager;

/**
 * Class QuickAccessBackendPreview
 * @package Standardlife\SlTeaser\Hooks
 * @hook TYPO3_CONF_VARS|SC_OPTIONS|cms/layout/class.tx_cms_layout.php|tt_content_drawItem
 */
class QuickAccessBackendPreview implements PageLayoutViewDrawItemHookInterface
{

    protected $extensionKey = 'sl_quick_access';

    protected $listType = 'slquickaccess_quickaccess';

    protected $backendTemplate = 'QuickAccess/IndexBackend';

    protected $fileSuffix = '.html';

    protected $modelClass = QuickAccessEntry::class;

    protected $templatePath = __DIR__ . '/../../Resources/Private/Templates/';

    protected $partialPath = __DIR__ . '/../../Resources/Private/Templates/';

    protected $typeName = 'Plugin: Quick access';

    /**
     * @param PageLayoutView $parentObject
     * @param bool $drawItem
     * @param string $headerContent
     * @param string $itemContent
     * @param array $row
     */
    public function preProcess(PageLayoutView &$parentObject, &$drawItem, &$headerContent, &$itemContent, array &$row)
    {
        if ($row['CType'] == 'list' && $row['list_type'] == $this->listType) {
            $backendPreview = $this->getBackendPreview($row);

            if ($backendPreview !== null) {
                $itemContent = $backendPreview;
                $drawItem = false;
            }
        }
    }

    /**
     * @param $row
     * @return null|string
     */
    protected function getBackendPreview($row)
    {
        $path = $this->templatePath . $this->backendTemplate . $this->fileSuffix;

        if (!file_exists($path)) {
            return null;
        }

        $items = $this->getItems();

        $fluidTemplateRenderer = new FluidTemplateRenderer(
            realpath($this->templatePath) . '/',
            realpath($this->partialPath) . '/'
        );

        $html = $fluidTemplateRenderer->render($this->backendTemplate, [
            'data' => $row,
            'items' => $items,
        ]);

        return $this->getTypeHtml() . $html;
    }

    /**
     * @return string
     */
    protected function getTypeHtml()
    {
        return '<strong>' . $this->typeName . '</strong><br />';
    }

    /**
     * @return null|array
     */
    protected function getItems()
    {

        /** @var QuickAccessEntryRepository $quickAccessEntryRepository */
        $quickAccessEntryRepository = GeneralUtility::makeInstance(ObjectManager::class)->get(QuickAccessEntryRepository::class);
        $items = $quickAccessEntryRepository->findActive();

        return $items;
    }

}