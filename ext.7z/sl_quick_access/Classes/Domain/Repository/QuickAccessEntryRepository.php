<?php

namespace Standardlife\SlQuickAccess\Domain\Repository;

use TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings;
use TYPO3\CMS\Extbase\Persistence\QueryInterface;
use TYPO3\CMS\Extbase\Persistence\Repository;

/**
 * Class QuickAccessRepository
 * @package Standardlife\SlQuickAccess\Domain\Repository
 */
class QuickAccessEntryRepository extends Repository
{

    public function initializeObject()
    {
        /** @var $defaultQuerySettings Typo3QuerySettings */
        $defaultQuerySettings = $this->objectManager->get(Typo3QuerySettings::class);
        // add sys_language_uid constraint
        $defaultQuerySettings->setRespectSysLanguage(true);
        $defaultQuerySettings->setRespectStoragePage(false);
        $this->setDefaultQuerySettings($defaultQuerySettings);
    }

    /**
     * Find active quick access entries sorted ascending
     * @return array
     */
    public function findActive()
    {
        $q = $this->createQuery();
        $q->matching($q->equals('hidden', 0));
        $q->setOrderings(['sorting' => QueryInterface::ORDER_ASCENDING]);
        $result = $q->execute();

        return $result->toArray();
    }
}