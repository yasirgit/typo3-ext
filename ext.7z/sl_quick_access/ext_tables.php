<?php

if (!defined('TYPO3_MODE')) {
    die('Access denied.');
}


$extPath = \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extPath($_EXTKEY);

// Allow usage of a table on standard page
\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::allowTableOnStandardPages('tx_slquickaccess_domain_model_quickaccess');

\HDNET\Autoloader\Loader::extTables('Standardlife', $_EXTKEY);


$GLOBALS['TBE_MODULES_EXT']['xMOD_db_new_content_el']['addElClasses'][\Standardlife\SlQuickAccess\Hooks\QuickAccessWizardItem::class] = $extPath . 'Classes/Hooks/QuickAccessWizardItem.php';