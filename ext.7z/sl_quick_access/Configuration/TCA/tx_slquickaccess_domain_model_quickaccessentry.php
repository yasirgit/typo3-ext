<?php

use HDNET\Autoloader\Utility\ArrayUtility;
use HDNET\Autoloader\Utility\ModelUtility;

// return (function () {

    $base = ModelUtility::getTcaInformation(\Standardlife\SlQuickAccess\Domain\Model\QuickAccessEntry::class);

    // custom manipulation calls here
    $custom = [
        'columns' => [

            'link' => [
                'exclude' => 1,
                'config' => [
                    'type' => 'input',
                    'renderType' => 'inputLink',
                ],
            ],

        ],
    ];

    return ArrayUtility::mergeRecursiveDistinct($base, $custom);

// })();
