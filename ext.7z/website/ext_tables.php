<?php

if (!defined('TYPO3_MODE')) {
    die('Access denied.');
}

// Allow usage of a table on standard page
//\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::allowTableOnStandardPages('tx_website_domain_model_button');

\HDNET\Autoloader\Loader::extTables('Standardlife', $_EXTKEY);