tt_content.stdWrap.innerWrap >

#noch mehr entfernen
tt_content.stdWrap.dataWrap =

# remove default headers
lib.stdheader >

# remove prepended anchor in tt_content, source: http://stackoverflow.com/a/8417983
tt_content.stdWrap.prepend >