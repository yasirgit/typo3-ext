config {

    linkVars = L

    absRefPrefix = /

    doctype = html5
    doctype(
<!DOCTYPE html>
<!--[if lt IE 9]><html class="no-js fadeIn lt-ie9" > <![endif]-->
<!--[if IE 9]><html class="no-js fadeIn lt-ie9" > <![endif]-->
<!--[if gt IE 9]><!-->
    )

    htmlTag_setParams = class="no-js fadeIn" lang="de"><!--<![endif]--

    xmlprologue = none

    xhtml_cleaning = all
    #no_cache = 1
    admPanel = 0
    removeDefaultCSS = 1
    removeDefaultJS = 0
    #Kommentare ausblenden
    disablePrefixComment = 1
    #wandelte alle CSS in Files um
    inlineStyle2TempFile = 1
    disableImgBorderAttr = 1
    index_enable = 1


    prefixLocalAnchors = all
    simulateStaticDocuments = 0
    tx_realurl_enable = 1

    sys_language_uid = 0
    language = de
    locale_all = de_DE.UTF-8
    htmlTag_langKey = de_DE
    #sys_language_overlay = 1

    sys_language_mode = strict

    ###1 sorgt dafür, dass der Seitentitel ohne "Name der Website: " ausgegeben wird###
    ###bei 2 wird gar kein Pagetitle mehr gerendert###
    noPageTitle = 2




    spamProtectEmailAddresses = 2
    spamProtectEmailAddresses_atSubst = &#x40;
    spamProtectEmailAddresses_lastDotSubst = &#x2e;

    disableBaseWrap = 1
}

[globalVar = GP:L = 1]
    config {
        sys_language_uid = 1
        language = at
    }
[end]