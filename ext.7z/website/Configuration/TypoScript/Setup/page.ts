
page.config {
    linkVars = L

    simulateStaticDocuments = 0
    tx_realurl_enable = 1


    baseURL = /
    absRefPrefix = /


    #sys_language_uid = 0
    #language = de
    #locale_all = de_DE.UTF-8
    #htmlTag_langKey = de_DE

}

page.config.noPageTitle = 2