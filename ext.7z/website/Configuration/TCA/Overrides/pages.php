<?php

use HDNET\Autoloader\Utility\ArrayUtility;
use HDNET\Autoloader\Utility\ModelUtility;

$GLOBALS['TCA']['pages'] = ModelUtility::getTcaOverrideInformation('website', 'pages');

// custom manipulation calls here
$custom = [];

$GLOBALS['TCA']['pages'] = ArrayUtility::mergeRecursiveDistinct($GLOBALS['TCA']['pages'], $custom);

$GLOBALS['TCA']['pages']['palettes']['title']['showitem'] = str_replace(
    'nav_title_formlabel, --linebreak--,',
    'nav_title_formlabel, --linebreak--, tx_mobile_nav_title;Mobile Navigation Title (default: "Übersicht"), --linebreak--,',
    $GLOBALS['TCA']['pages']['palettes']['title']['showitem']
);

if (\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::isLoaded('sl_crd')) {
    $GLOBALS['TCA']['pages'] = \Standardlife\SlCrd\Utilities\CrdUtil::addTca($GLOBALS['TCA']['pages']);
}

