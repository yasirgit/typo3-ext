<?php

use HDNET\Autoloader\Utility\ArrayUtility;
use HDNET\Autoloader\Utility\ModelUtility;

$GLOBALS['TCA']['fe_groups'] = ModelUtility::getTcaOverrideInformation('website', 'fe_groups');

// custom manipulation calls here
$custom = [];

$GLOBALS['TCA']['fe_groups'] = ArrayUtility::mergeRecursiveDistinct($GLOBALS['TCA']['fe_groups'], $custom);
