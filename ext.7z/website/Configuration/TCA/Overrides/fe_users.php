<?php

use HDNET\Autoloader\Utility\ArrayUtility;
use HDNET\Autoloader\Utility\ModelUtility;

$GLOBALS['TCA']['fe_users'] = ModelUtility::getTcaOverrideInformation('website', 'fe_users');

// custom manipulation calls here
$custom = [];

$GLOBALS['TCA']['fe_users'] = ArrayUtility::mergeRecursiveDistinct($GLOBALS['TCA']['fe_users'], $custom);
