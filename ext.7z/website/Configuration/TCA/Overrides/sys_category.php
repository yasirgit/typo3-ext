<?php

use HDNET\Autoloader\Utility\ArrayUtility;
use HDNET\Autoloader\Utility\ModelUtility;

$GLOBALS['TCA']['sys_category'] = ModelUtility::getTcaOverrideInformation('website', 'sys_category');

// custom manipulation calls here
$custom = [];

$GLOBALS['TCA']['sys_category'] = ArrayUtility::mergeRecursiveDistinct($GLOBALS['TCA']['sys_category'], $custom);
