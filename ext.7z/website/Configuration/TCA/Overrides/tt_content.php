<?php

use HDNET\Autoloader\Utility\ArrayUtility;
use HDNET\Autoloader\Utility\ModelUtility;

$GLOBALS['TCA']['tt_content'] = ModelUtility::getTcaOverrideInformation('sl_content', 'tt_content');

// custom manipulation calls here
$custom = [
    'columns' => [
        'tx_icon' => [
            'label' => 'Icon',
            'config' => [
                'displayCond' => [
                    'FIELD:tx_gridelements_backend_layout:EQ:t3ddy-item',
                    'FIELD:layout:EQ:highlight',
                ],
                'type' => 'select',
                'items' => [
                    ['None', ''],
                    ['Aktien', '&#xea1a;'],
                    ['Dokument', '&#xea27;'],
                    ['Überweisungen', '&#xedc2;'],
                    ['Scheck', '&#xea05;'],
                ],
            ],
        ],
        'tx_style' => [
            'label' => 'Style',
            'config' => [
                'displayCond' => [
                    'FIELD:tx_gridelements_backend_layout:EQ:t3ddy-tab-container',
                ],
                'type' => 'select',
                'items' => [
                    ['Default', ''],
                    ['Short type', 'tabType01'],
                ],
            ],
        ],
    ],
];

$GLOBALS['TCA']['tt_content'] = ArrayUtility::mergeRecursiveDistinct($GLOBALS['TCA']['tt_content'], $custom);


$GLOBALS['TCA']['tt_content']['types']['text']['showitem'] = str_replace(';headers,', ';headers, tx_icon,', $GLOBALS['TCA']['tt_content']['types']['text']['showitem']);
$GLOBALS['TCA']['tt_content']['types']['textpic']['showitem'] = str_replace(';headers,', ';headers, tx_icon,', $GLOBALS['TCA']['tt_content']['types']['textpic']['showitem']);
$GLOBALS['TCA']['tt_content']['types']['textmedia']['showitem'] = str_replace(';headers,', ';headers, tx_icon,', $GLOBALS['TCA']['tt_content']['types']['textmedia']['showitem']);


$GLOBALS['TCA']['tt_content']['types']['gridelements_pi1']['showitem'] = '
	--palette--;LLL:EXT:frontend/Resources/Private/Language/locallang_ttc.xlf:palette.general;general,
	--palette--;LLL:EXT:frontend/Resources/Private/Language/locallang_ttc.xlf:palette.header;header,
	subheader,
	tx_style,
	tx_icon,
	tx_gridelements_backend_layout,
	pi_flexform,
	tx_gridelements_children,
    --div--;LLL:EXT:frontend/Resources/Private/Language/locallang_ttc.xlf:tabs.appearance,
    --palette--;LLL:EXT:frontend/Resources/Private/Language/locallang_ttc.xlf:palette.frames;frames,
    --palette--;LLL:EXT:frontend/Resources/Private/Language/locallang_ttc.xlf:palette.appearanceLinks;appearanceLinks,
    media,
    --div--;LLL:EXT:core/Resources/Private/Language/Form/locallang_tabs.xlf:language,--palette--;;language,
    --div--;LLL:EXT:core/Resources/Private/Language/Form/locallang_tabs.xlf:access,
    --palette--;;hidden,
    --palette--;LLL:EXT:frontend/Resources/Private/Language/locallang_ttc.xlf:palette.access;access,
    --div--;LLL:EXT:lang/Resources/Private/Language/locallang_tca.xlf:sys_category.tabs.category,
	categories,
    --div--;LLL:EXT:core/Resources/Private/Language/Form/locallang_tabs.xlf:notes,rowDescription
	';