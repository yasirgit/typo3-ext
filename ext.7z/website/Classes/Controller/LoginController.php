<?php

namespace Standardlife\Website\Controller;


use TYPO3\CMS\Extbase\Mvc\Controller\ActionController;

/**
 * Class LoginController
 * @package Standardlife\Website\Controller
 */
class LoginController extends ActionController
{

    /**
     * @plugin LoginTile!
     * @noCache
     */
    public function tileAction()
    {
        $extensionConfiguration = unserialize($GLOBALS['TYPO3_CONF_VARS']['EXT']['extConf']['website']);

        $loginUrl = '#';
        $forgotPasswordUrl = '#';
        $registrationUrl = '#';
        if (array_key_exists('login.', $extensionConfiguration)) {
            $loginConfig = $extensionConfiguration['login.'];

            if (array_key_exists('loginUrl', $loginConfig)) {
                $loginUrl = $loginConfig['loginUrl'];
            }
            if (array_key_exists('forgotPasswordUrl', $loginConfig)) {
                $forgotPasswordUrl = $loginConfig['forgotPasswordUrl'];
            }
            if (array_key_exists('registrationUrl', $loginConfig)) {
                $registrationUrl = $loginConfig['registrationUrl'];
            }
        }

        $this->view->assignMultiple([
            'loginUrl' => $loginUrl,
            'forgotPasswordUrl' => $forgotPasswordUrl,
            'registrationUrl' => $registrationUrl,
        ]);
    }

}