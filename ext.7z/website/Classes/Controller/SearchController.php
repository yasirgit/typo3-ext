<?php

namespace Standardlife\Website\Controller;

use Elastica\Request;
use OH\Ohsearch\Service\Client;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Mvc\Controller\ActionController;
use TYPO3\CMS\Extbase\Utility\DebuggerUtility;


/**
 * Class SearchController
 * @package Standardlife\Website\Controller
 */
class SearchController extends ActionController
{

    /**
     * @var \Standardlife\Website\Domain\Repository\PagesRepository
     * @inject
     */
    protected $pagesRepository;

    /**
     * @plugin SearchResult!
     * @noCache
     * @throws \Exception
     */
    public function indexAction()
    {
        $size = 5;
        $from = (int)GeneralUtility::_GET('page');
        $searchTerm = GeneralUtility::_GET('q');

        if (is_nan($from)) {
            $from = 0;
        } else if ($from > 0) {
            $from--;
        }

        $client = new Client();

        $extConfig = unserialize($GLOBALS['TYPO3_CONF_VARS']['EXT']['extConf']['ohsearch']);

        if (!array_key_exists('index', $extConfig)) {
            throw new \Exception('No ElasticSearch index given!');
        }
        $indexName = $extConfig['index'];

        $index = $client->getIndex($indexName);


        if (trim($searchTerm) !== '') {
            /*$sysLanguageUid = $GLOBALS['TSFE']->sys_language_uid;
            $workspaceId = $GLOBALS['TSFE']->sys_page->versioningWorkspaceId;
            if ($workspaceId === null) {
                $workspaceId = 0;
            }*/

            $feGroupRestriction = array(
                'term' => array('fe_group' => ''),
            );

            $feGroupIds = array();
            foreach ($GLOBALS['TSFE']->fe_user->groupData['uid'] as $groupId) {
                $feGroupIds[] = $groupId;
            }

            if (!empty($feGroupIds)) {
                $feGroupRestriction[] = array(
                    'term' => array(
                        array(
                            'fe_group' => $feGroupIds,
                        ),
                    )
                );
            }

            $queryArray = array(
                'size' => $size,
                'from' => $from,
                'query' => array(
                    'multi_match' => [
                        'query' => $searchTerm,
                        'fields' => ['title^10', '_all'],
                        'type' => 'phrase_prefix',
                    ],

                ),


                /*
                'query' => array(
                    'filtered' => array(
                        'query' => array(
                            'bool' => array(
                                'must' => array(
                                    'and' => array(
                                        array(
                                            'multi_match' => array(
                                                'query' => $searchTerm,
                                                'fields' => array('title^10', 'bodytext^5', 'content^5', '_all'),
                                                'type' => 'phrase_prefix',
                                            ),
                                        ),
                                        array(
                                            'match' => array('sys_language_uid' => $sysLanguageUid),
                                        ),
                                    )
                                )
                            )
                        ),
                        'sort' => array()
                    )
                )*/
            );


            $query = json_encode($queryArray);

            //$query = '{"query":{"query_string":{"query":"' . $searchTerm . '"}}}';

            $response = $index->request('/_search', Request::GET, $query);
            $responseArray = $response->getData();


            $hits = $responseArray['hits'];

            //DebuggerUtility::var_dump($hits);

            $pageIds = [];
            foreach ($hits['hits'] as $hit) {
                $pageIds[] = $hit['_source']['page_id'];
            }

            $pages = $this->pagesRepository->findByUids($pageIds);

            $totalPages = ($hits['total'] % $size !== 0 ? floor($hits['total'] / $size) + 1 : floor($hits['total'] / $size));
            $nextPage = $from+1 < $totalPages ? $from+2 : null;
            $previousPage = $from > -1 ? $from : null;
            //DebuggerUtility::var_dump($pages);
        } else {
            $pages = '';
            $hits = [];
            $totalPages = 0;
            $nextPage = null;
            $previousPage = null;
        }


        $this->view->assignMultiple([
            'items' => $pages,
            'searchTerm' => $searchTerm,
            'hits' => $hits,
            'resultPage' => $from + 1,
            'resultPages' => $totalPages,
            'nextPage' => $nextPage,
            'previousPage' => $previousPage,
        ]);
    }

}