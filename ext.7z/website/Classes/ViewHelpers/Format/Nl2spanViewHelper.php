<?php

namespace Standardlife\Website\ViewHelpers\Format;


use TYPO3\CMS\Fluid\Core\ViewHelper\AbstractViewHelper;
use TYPO3Fluid\Fluid\Core\Rendering\RenderingContextInterface;
use TYPO3Fluid\Fluid\Core\ViewHelper\Traits\CompileWithContentArgumentAndRenderStatic;

/**
 * Class Nl2spanViewHelper
 * @package Standardlife\Website\ViewHelpers\Format
 */
class Nl2spanViewHelper extends AbstractViewHelper
{
    use CompileWithContentArgumentAndRenderStatic;

    /**
     * @var bool
     */
    protected $escapeOutput = false;

    /**
     * Initialize arguments.
     *
     * @throws \TYPO3Fluid\Fluid\Core\ViewHelper\Exception
     */
    public function initializeArguments()
    {
        parent::initializeArguments();
        $this->registerArgument('value', 'string', 'string to format');
    }

    /**
     * Applies nl2br() on the specified value.
     *
     * @param array $arguments
     * @param \Closure $renderChildrenClosure
     * @param \TYPO3Fluid\Fluid\Core\Rendering\RenderingContextInterface $renderingContext
     * @return string
     */
    public static function renderStatic(array $arguments, \Closure $renderChildrenClosure, RenderingContextInterface $renderingContext)
    {
        $content = trim($renderChildrenClosure());

        $contentElements = preg_split("/\\r\\n|\\r|\\n/", $content);

        if (empty($contentElements)) {
            return '';
        }

        $newContent = array_shift($contentElements);
        foreach ($contentElements as $contentElement) {
            $newContent .= '<span>' . $contentElement . '</span>';
        }

        return $newContent;
    }
}
