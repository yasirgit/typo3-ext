<?php

namespace Standardlife\Website\ViewHelpers;




use TYPO3Fluid\Fluid\Core\ViewHelper\AbstractViewHelper;

/**
 * Class GetPageViewHelper
 * @package Standardlife\Website\ViewHelpers
 */
class GetPageViewHelper extends AbstractViewHelper
{

    /**
     * @var \Standardlife\Website\Domain\Repository\PagesRepository
     * @inject
     */
    protected $pagesRepository;


    public function initializeArguments()
    {
        $this->registerArgument('uid', 'integer', 'Page uid', true, null);
    }

    /**
     * @return void
     */
    public function render()
    {
        $uid = $this->arguments['uid'];

        if ($uid == null) {
            return;
        }


        $page = $this->pagesRepository->findByUid($uid);

        $name = 'page';
        $value = $page;

        if ($this->templateVariableContainer->exists($name) === TRUE) {
            $this->templateVariableContainer->remove($name);
        }
        $this->templateVariableContainer->add($name, $value);
    }
}
