<?php

namespace Standardlife\Website\ViewHelpers;




use TYPO3\CMS\Fluid\Core\ViewHelper\AbstractViewHelper;


/**
 * Class GetExtensionConfigViewHelper
 * @package Standardlife\Website\ViewHelpers
 */
class GetExtensionConfigViewHelper extends AbstractViewHelper
{
    /**
     * Initialize arguments
     */
    public function initializeArguments()
    {
        parent::initializeArguments();

        $this->registerArgument('extension', 'string', 'Name of extension', true);
        $this->registerArgument('key', 'string', 'Key of variable', true);
    }

    /**
     * @return string
     */
    public function render()
    {
        $extensionName = $this->arguments['extension'];
        $key = $this->arguments['key'];

        $extConf = $GLOBALS['TYPO3_CONF_VARS']['EXT']['extConf'];

        if (!array_key_exists($extensionName, $extConf)) {
            return '';
        }

        $extensionConfiguration = unserialize($extConf[$extensionName]);

        $keyElements = explode('.', $key);

        foreach ($keyElements as $keyElement) {
            if (!array_key_exists($keyElement, $extensionConfiguration)) {
                $keyElement .= '.';
                if (!array_key_exists($keyElement, $extensionConfiguration)) {
                    return '';
                }
            }

            $extensionConfiguration = $extensionConfiguration[$keyElement];
        }

        return $extensionConfiguration;
    }

}
