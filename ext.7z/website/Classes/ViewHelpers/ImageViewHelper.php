<?php

namespace Standardlife\Website\ViewHelpers;


use TYPO3\CMS\Core\Resource\FileInterface;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Domain\Model\AbstractFileFolder;
use TYPO3\CMS\Extbase\Object\ObjectManager;
use TYPO3\CMS\Extbase\Service\ImageService;

use TYPO3\CMS\Fluid\Core\ViewHelper\AbstractViewHelper;
use TYPO3\CMS\Fluid\View\StandaloneView;

/**
 * Class ImageViewHelper
 * @package Standardlife\Website\ViewHelpers
 */
class ImageViewHelper extends AbstractViewHelper
{
    /** @var ObjectManager */
    protected $objectManager;

    /**
     * @var boolean
     */
    protected $escapeChildren = false;

    /**
     * @var boolean
     */
    protected $escapeOutput = false;

    /**
     * ImageViewHelper constructor.
     */
    public function __construct()
    {
        $this->objectManager = GeneralUtility::makeInstance(ObjectManager::class);
    }


    /**
     * Initialize arguments
     */
    public function initializeArguments()
    {
        parent::initializeArguments();

        $this->registerArgument('file', 'object', 'File', true);
        $this->registerArgument('mobileFile', 'object', 'File for mobile images', false);
        $this->registerArgument('type', 'string', 'Rendering image size type', true);
        $this->registerArgument('class', 'string', 'CSS class', false);
        $this->registerArgument('lazyLoad', 'boolean', 'deactivate lazy mode (default: false)', false, false);
    }

    /**
     * @return string
     */
    public function render()
    {
        $file = $this->arguments['file'];
        $mobileFile = $this->arguments['mobileFile'];
        $type = $this->arguments['type'];
        $class = $this->arguments['class'];


        // get Resource Object (non ExtBase version)
        if (is_callable([$file, 'getOriginalResource'])) {
            // We have a domain model, so we need to fetch the FAL resource object from there
            $file = $file->getOriginalResource();
        }

        // get Resource Object (non ExtBase version)
        if ($mobileFile !== null && is_callable([$mobileFile, 'getOriginalResource'])) {
            // We have a domain model, so we need to fetch the FAL resource object from there
            $mobileFile = $mobileFile->getOriginalResource();
        }
        if (!($file instanceof FileInterface || $file instanceof AbstractFileFolder)) {
            throw new \UnexpectedValueException('Supplied file object type ' . get_class($file) . ' must be FileInterface or AbstractFileFolder.', 1454252193);
        }

        return $this->renderImage($file, $mobileFile, $type, $class);
    }


    /**
     * @param FileInterface $image
     * @param $mobileImage
     * @param $type
     * @param $class
     * @return string
     */
    protected function renderImage(FileInterface $image, $mobileImage, $type, $class)
    {
        $internalImage = null;
        $imageService = $this->getImageService();

        $config = [
            'grid-article-landscape' => [
                'default' => [
                    'width' => 616,
                    'height' => 420,
                ],
                'bp4' => [
                    'width' => 514,
                ],
                'bp7' => [
                    'width' => 411,
                ],
                'mobile' => [
                    'width' => 550,
                ],
            ],
            'grid-article-portrait' => [
                'default' => [
                    'width' => 498,
                    'height' => 616,
                ],
                'bp4' => [
                    'width' => 415,
                ],
                'bp7' => [
                    'width' => 332,
                ],
            ],
            'detail-header' => [
                'default' => [
                    'width' => 1322,
                    'height' => 500,
                ],
                'bp4' => [
                    'width' => 1102,
                ],
                'bp7' => [
                    'width' => 882,
                ],
                'mobile' => [
                    'width' => 550,
                ],
                'fullMobile' => [
                    'width' => 550,
                    'height' => 375,
                ],
            ],
            'detail-content-image' => [
                'default' => [
                    'width' => 1322,
                    'height' => 700,
                ],
                'bp4' => [
                    'width' => 1102,
                ],
                'bp7' => [
                    'width' => 882,
                ],
                'mobile' => [
                    'width' => 550,
                ],
            ],
            'content-slider' => [
                'default' => [
                    'width' => 1680,
                    'height' => 500,
                ],
                'bp4' => [
                    'width' => 1410,
                ],
                'bp7' => [
                    'width' => 1145,
                ],
                'mobile' => [
                    'width' => 850,
                ],
                'fullMobile' => [
                    'width' => 480,
                ],
            ],
            'colSet64-image' => [
                'default' => [
                    'width' => 710,
                    'height' => 500,
                ],
                'bp4' => [
                    'width' => 610,
                ],
                'bp7' => [
                    'width' => 488,
                ],
                'mobile' => [
                    'width' => 550,
                ],
            ],
            'cols4-image' => [
                'default' => [
                    'width' => 480,
                ],
                'bp4' => [
                    'width' => 421,
                ],
                'bp7' => [
                    'width' => 737,
                ],
                'mobile' => [
                    'width' => 550,
                ],
            ],
        ];

        $bpConfig = [
            'bp4' => '(max-width: 1410px)',
            'bp7' => '(max-width: 1145px)',
            'mobile' => '(max-width: 850px), (min-device-width : 768px) and (max-device-width : 1024px) and (orientation : portrait)',
            'fullMobile' => '(max-width: 480px)',
        ];

        if (!array_key_exists($type, $config)) {
            $imageUri = $imageService->getImageUri($image, true);

            $data = [
                [
                    'media' => '',
                    'width' => $image->getProperty('width'),
                    'height' => $image->getProperty('height'),
                    'position' => 0,
                    'uri' => $imageUri,
                    'retinaUri' => $imageUri,
                ]
            ];
        } else {

            $typeConfig = $config[$type];

            $data = [];
            foreach ($typeConfig as $breakpoint => $options) {

                $img = $image;
                if ($mobileImage !== null && in_array($breakpoint, ['mobile', 'fullMobile'])) {
                    $img = $mobileImage;
                }

                if ($breakpoint == 'default') {
                    continue;
                }

                $processingInstructions = [
                    'width' => $options['width'],
                    //'height' => $options['height'],
                    'crop' => null,//$cropArea->isEmpty() ? null : $cropArea->makeAbsoluteBasedOnFile($image),
                ];

                if (array_key_exists('height', $options)) {
                    $processingInstructions['height'] = $options['height'];
                }

                $processedImage = $imageService->applyProcessingInstructions($img, $processingInstructions);
                $imageUri = $imageService->getImageUri($processedImage, true);

                $retinaProcessingInstructions = $processingInstructions;
                $retinaProcessingInstructions['width'] *= 2;
                $retinaProcessingInstructions['height'] *= 2;

                $processedRetinaImage = $imageService->applyProcessingInstructions($img, $retinaProcessingInstructions);
                $retinaImageUri = $imageService->getImageUri($processedRetinaImage, true);

                $data[] = [
                    'media' => $bpConfig[$breakpoint],
                    'width' => $options['width'],
                    'height' => $options['height'],
                    'position' => array_search($breakpoint, array_keys($bpConfig)),
                    'uri' => $imageUri,
                    'retinaUri' => $retinaImageUri,
                ];
            }
        }

/*
        uasort($data, function($a, $b) {
            return $a['width'] > $b['width'];
        });
        */
        uasort($data, function($a, $b) {
            return $a['position'] < $b['position'];
        });


        /** @var \TYPO3\CMS\Fluid\View\StandaloneView $view */
        $view = $this->objectManager->get(StandaloneView::class);
        $view->setTemplatePathAndFilename(__DIR__ . '/../../Resources/Private/Views/ImageViewHelper/render-image.html');

        $view->assignMultiple([
            'imageUri' => $imageService->getImageUri($image, true),
            'data' => $data,
            'class' => $class,
            'lazyLoad' => $this->arguments['lazyLoad'],
        ]);

        return $view->render();
    }

    /**
     * Return an instance of ImageService
     *
     * @return ImageService
     */
    protected function getImageService()
    {
        return $this->objectManager->get(ImageService::class);
    }

}