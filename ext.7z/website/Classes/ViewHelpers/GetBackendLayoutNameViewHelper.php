<?php

namespace Standardlife\Website\ViewHelpers;



use Standardlife\Website\Domain\Model\Pages;


use TYPO3Fluid\Fluid\Core\ViewHelper\AbstractViewHelper;

/**
 * Class GetBackendLayoutNameViewHelper
 * @package Standardlife\Website\ViewHelpers
 */
class GetBackendLayoutNameViewHelper extends AbstractViewHelper
{

    /**
     * @var \Standardlife\Website\Domain\Repository\PagesRepository
     * @inject
     */
    protected $pagesRepository;

    public function initializeArguments()
    {
        $this->registerArgument('pageUid', 'integer', 'Page uid', true, null);
    }

    /**
     * @return string|null
     */
    public function render()
    {
        $pageUid = $this->arguments['pageUid'];

        if ($pageUid == null) {
            return null;
        }

        /** @var Pages $page */
        $page = $this->pagesRepository->findByUid($pageUid);
        //$pageInfo = BackendUtility::readPageAccess($pageUid, '');
        $backendLayoutName = $page->getBackendLayout();

        if (empty($backendLayoutName)) {
            /*$pageInfo = BackendUtility::readPageAccess($pageInfo['pid'], '');
            $backendLayoutName = $pageInfo['backend_layout'];*/


            $page = $this->pagesRepository->findByUid($page->getPid());
            //$pageInfo = BackendUtility::readPageAccess($pageUid, '');
            $backendLayoutName = $page->getBackendLayout();
        }

        if (stripos($backendLayoutName, 'autoloader') !== false) {
            $backendLayoutName = explode('__', $backendLayoutName)[1];
        }

        return $backendLayoutName;
    }

}
