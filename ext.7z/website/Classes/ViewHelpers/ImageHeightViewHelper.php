<?php

namespace Standardlife\Website\ViewHelpers;
use TYPO3Fluid\Fluid\Core\ViewHelper\AbstractViewHelper;

/**
 * Class ImageHeightViewHelper
 * @package Standardlife\Website\ViewHelpers
 */
class ImageHeightViewHelper extends AbstractViewHelper
{

    /**
     * @param string $url
     * @return mixed|string
     */
    public function render($url)
    {
        $imagePath = PATH_site . ltrim($url, '/');

        $imageSize = getimagesize($imagePath);

        return $imageSize[1];
    }

}
