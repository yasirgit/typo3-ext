<?php

namespace Standardlife\Website\ViewHelpers;

use TYPO3Fluid\Fluid\Core\ViewHelper\AbstractViewHelper;

/**
 * Class TypoLinkTextViewHelper
 * @package Standardlife\Website\ViewHelpers
 */
class TypoLinkTextViewHelper extends AbstractViewHelper
{


    public function initializeArguments()
    {
        $this->registerArgument('link', 'string', 'Typo3 link', true, null);
        $this->registerArgument('default', 'string', 'Default link text', false, '');
    }

    /**
     * @return string
     */
    public function render()
    {
        $link = (string)$this->arguments['link'];

        preg_match('/"(.*)"/is', $link, $matches);

        if (count($matches) > 0 && array_key_exists(1, $matches)) {
            return $matches[1];
        }

        $pos = strrpos($link, '-');
        if ($pos !== false) {
            return trim(substr($link, $pos + 1));
        }


        return (string)$this->arguments['default'];
    }

}
