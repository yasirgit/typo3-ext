<?php

namespace Standardlife\Website\ViewHelpers;


use TYPO3Fluid\Fluid\Core\ViewHelper\AbstractViewHelper;

/**
 * Class TimestampViewHelper
 * @package Standardlife\Website\ViewHelpers
 */
class TimestampViewHelper extends AbstractViewHelper
{

    /**
     * @param \DateTime|string $date
     * @return mixed|string
     */
    public function render($date)
    {
        if (!$date instanceof \DateTime) {
            return '0';
        }

        return $date->getTimestamp();
    }

}
