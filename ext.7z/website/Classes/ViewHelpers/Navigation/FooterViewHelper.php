<?php

namespace Standardlife\Website\ViewHelpers\Navigation;

use TYPO3\CMS\Extbase\Utility\DebuggerUtility;

/**
 * Class FooterViewHelper
 * @package Standardlife\Website\ViewHelpers\Navigation
 */
class FooterViewHelper extends AbstractNavigationViewHelper
{

    /**
     * @return string
     */
    public function render()
    {
        // get active page ids
        $this->activePageIds = $this->getActivePageIds($GLOBALS['TSFE']->id);

        if (isset($_GET['debug'])) {
            DebuggerUtility::var_dump($this->activePageIds);
        }

        $pageRepo = $this->getPageRepository();

        $where = ' AND doktype IN (1,2,3,4,7)';
        $data = $pageRepo->getMenu($this->getRootPageUid(), '*', 'sorting', $where);

        /*
         * remove hidden pages (nav_hide).
         *
         * Don't try to remove them in the where statement.
         * Because of workspaces one only knows the value of nav_hide
         * after the workspace overlay data has been loaded.
         */
        foreach ($data as $key => $pageRow) {
            if ($pageRow['nav_hide'] != '0') {
                unset($data[$key]);
            }
        }

        $counter = 1;

        $pages = [];
        foreach ($data as $pageData) {
            // retrieve sub pages
            $where = ' AND doktype IN (1,2,3,4,7) ';
            $subPages = $pageRepo->getMenu($pageData['uid'], '*', 'sorting', $where);
            /*
             * remove hidden pages (nav_hide).
             *
             * Don't try to remove them in the where statement.
             * Because of workspaces one only knows the value of nav_hide
             * after the workspace overlay data has been loaded.
             */
            $pageData['subPages'] = [];
            foreach ($subPages as $key => $pageRow) {
                if ($pageRow['nav_hide'] != '0') {
                    unset($subPages[$key]);
                } else {
                    $pageData['subPages'][] = $pageRow;
                }
            }


            $pages[] = $pageData;
            $counter++;
        }

        $firstPages = array_slice($pages, 0, 1);
        $pages = array_slice($pages, 1);

        $html = $this->renderMainNavigation($firstPages, $pages);

        return $html;
    }

    /**
     * @param array $firstPages
     * @param array $pages
     * @return string
     */
    protected function renderMainNavigation($firstPages, $pages)
    {
        $mainNavigationHtml = $this->getFluidTemplateRenderer()->render('Navigation/Footer', array(
            'firstPages' => $firstPages,
            'pages' => $pages,
        ));

        return $mainNavigationHtml;
    }

    /**
     * Retrieve root page uid from extension navigation
     * @return int
     */
    protected function getRootPageUid()
    {
        $extensionConfiguration = unserialize($GLOBALS['TYPO3_CONF_VARS']['EXT']['extConf']['website']);

        $rootPageUid = 8;
        if (array_key_exists('footerNavigationRootPageUid', $extensionConfiguration)) {
            $rootPageUid = $extensionConfiguration['footerNavigationRootPageUid'];
        }

        return $rootPageUid;
    }
}