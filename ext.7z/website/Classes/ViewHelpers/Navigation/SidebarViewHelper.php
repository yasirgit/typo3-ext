<?php

namespace Standardlife\Website\ViewHelpers\Navigation;




/**
 * Class BreadcrumbViewHelper
 * @package Standardlife\Website\ViewHelpers\Navigation
 */
class SidebarViewHelper extends BreadcrumbViewHelper
{

    /**
     * @return string
     */
    public function render()
    {
        $currentPageId = (int)$GLOBALS['TSFE']->id;
        $activePageIds = $this->getActivePageIds($currentPageId);
        $activePageIds = array_reverse($activePageIds);
        $activePageIds = array_slice($activePageIds, 1);

        $rootPageId = reset($activePageIds);


        $pageRepo = $this->getPageRepository();


        $rootPage = $pageRepo->getPage($rootPageId);
        $rootPage['active'] = true;

        $where = ' AND doktype IN (1,2,3,4,7)';
        $data = $pageRepo->getMenu($rootPageId, '*', 'sorting', $where);


        $counter = 1;

        $pages = [];
        foreach ($data as $pageData) {
            // retrieve sub pages
            $where = ' AND doktype IN (1,2,3,4,7) ';
            $subPages = $pageRepo->getMenu($pageData['uid'], '*', 'sorting', $where);

            $pageData['active'] = in_array($pageData['uid'], $activePageIds);
            $pageData['current'] = (int)$pageData['uid'] === $currentPageId;

            /*
             * remove hidden pages (nav_hide).
             *
             * Don't try to remove them in the where statement.
             * Because of workspaces one only knows the value of nav_hide
             * after the workspace overlay data has been loaded.
             */
            $pageData['subPages'] = [];
            foreach ($subPages as $key => $pageRow) {
                if ($pageRow['nav_hide'] != '0') {
                    unset($subPages[$key]);
                } else {
                    $pageRow['subPages'] = [];
                    $pageRow['active'] = in_array($pageRow['uid'], $activePageIds);
                    $pageRow['current'] = (int)$pageRow['uid'] === $currentPageId;


                    $subPages2 = $pageRepo->getMenu($pageRow['uid'], '*', 'sorting', $where);
                    foreach ($subPages2 as $key2 => $pageRow2) {
                        if ($pageRow2['nav_hide'] != '0') {
                            unset($subPages2[$key2]);
                        } else {
                            $pageRow2['subPages'] = [];
                            $pageRow2['active'] = in_array($pageRow2['uid'], $activePageIds);
                            $pageRow2['current'] = (int)$pageRow2['uid'] === $currentPageId;

                            $subPages3 = $pageRepo->getMenu($pageRow2['uid'], '*', 'sorting', $where);
                            foreach ($subPages3 as $key3 => $pageRow3) {
                                if ($pageRow3['nav_hide'] != '0') {
                                    unset($subPages3[$key3]);
                                } else {
                                    $pageRow3['subPages'] = [];
                                    $pageRow3['active'] = in_array($pageRow3['uid'], $activePageIds);
                                    $pageRow3['current'] = (int)$pageRow3['uid'] === $currentPageId;

                                    $subPages4 = $pageRepo->getMenu($pageRow3['uid'], '*', 'sorting', $where);
                                    foreach ($subPages4 as $key4 => $pageRow4) {
                                        if ($pageRow4['nav_hide'] != '0') {
                                            unset($subPages4[$key4]);
                                        } else {
                                            $pageRow4['subPages'] = [];
                                            $pageRow4['active'] = in_array($pageRow4['uid'], $activePageIds);
                                            $pageRow4['current'] = (int)$pageRow4['uid'] === $currentPageId;

                                            $subPages5 = $pageRepo->getMenu($pageRow4['uid'], '*', 'sorting', $where);
                                            foreach ($subPages5 as $key5 => $pageRow5) {
                                                if ($pageRow5['nav_hide'] != '0') {
                                                    unset($subPages5[$key5]);
                                                } else {
                                                    $pageRow5['active'] = in_array($pageRow5['uid'], $activePageIds);
                                                    $pageRow5['current'] = (int)$pageRow5['uid'] === $currentPageId;
                                                    $pageRow4['subPages'][] = $pageRow5;
                                                }
                                            }
                                            $pageRow3['subPages'][] = $pageRow4;
                                        }
                                    }

                                    $pageRow2['subPages'][] = $pageRow3;

                                }
                            }

                            $pageRow['subPages'][] = $pageRow2;
                        }
                    }

                    $pageData['subPages'][] = $pageRow;
                }
            }


            $pages[] = $pageData;
            $counter++;
        }

        $rootPage['subPages'] = $pages;




/*
        $pageRepo = $this->getPageRepository();
        $rootPage = $pageRepo->getPage(reset($activePageIds));
        $rootPage['active'] = true;
        $ref = &$rootPage;
        $activePageIds = array_slice($activePageIds, 1);
        for ($i = 0; $i < count($activePageIds); $i++) {
            if ($i === count($activePageIds) -1) {
                $where = ' AND doktype IN (1,2,3,4,7) ';
                $subPages = $pageRepo->getMenu($activePageIds[$i - 1], '*', 'sorting', $where);

                foreach ($subPages as &$subPage) {
                    if (in_array($subPage['uid'], $activePageIds)) {
                        $subPage['active'] = true;
                    }
                }

                $ref['subPages'] = $subPages;
            } else {
                $subPage = $pageRepo->getPage($activePageIds[$i]);
                if (in_array($subPage['uid'], $activePageIds)) {
                    $subPage['active'] = true;
                }
                $ref['subPages'] = [&$subPage];
                $ref = &$subPage;
            }
        }
*/
        $html = $this->renderSidebar($rootPage);

        return $html;
    }

    /**
     * @param array $page
     * @return string
     */
    protected function renderSidebar($page)
    {
        $mainNavigationHtml = $this->getFluidTemplateRenderer()->render('Navigation/Sidebar', array(
            'page' => $page,
        ));

        return $mainNavigationHtml;
    }

    /**
     * Retrieve active page ids by page
     * @param $pageId
     * @return array
     */
    protected function getActivePageIds($pageId)
    {
        $page = $this->getPageRepository()->getPage($pageId);

        $pageLevelCount = 1;
        $activePageIds = array($pageId);

        $maxCount = 20;

        while($page != null && $page['pid'] != 0) {
            $page = $this->getPageRepository()->getPage($page['pid']);
            $pageLevelCount++;

            array_push($activePageIds, (int)$page['uid']);

            if ($pageLevelCount > $maxCount) {
                break;
            }
        }

        return $activePageIds;
    }
}