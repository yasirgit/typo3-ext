<?php

namespace Standardlife\Website\ViewHelpers\Navigation;

use OH\Ohmex\Renderer\FluidTemplateRenderer;

use TYPO3\CMS\Extbase\Mvc\Controller\ControllerContext;
use TYPO3\CMS\Extbase\Mvc\Web\Routing\UriBuilder;

use TYPO3\CMS\Frontend\Page\PageRepository;
use TYPO3Fluid\Fluid\Core\ViewHelper\AbstractViewHelper;

/**
 * Class AbstractNavigationViewHelper
 * @package Standardlife\Website\ViewHelpers\Navigation
 */
abstract class AbstractNavigationViewHelper extends AbstractViewHelper
{

    /** @var PageRepository */
    protected $pageRepository = null;

    /** @var FluidTemplateRenderer */
    protected $fluidTemplateRenderer = null;

    /**
     * @var array
     */
    protected $activePageIds = [];

    /** @var ControllerContext */
    protected $controllerContext;

    /**
     * Render navigation element
     * @return string
     */
    public abstract function render();

    /**
     * Retrieve active page ids by page
     * @param $pageId
     * @return array
     */
    protected function getActivePageIds($pageId)
    {
        $page = $this->getPageRepository()->getPage($pageId);

        $pageLevelCount = 1;
        $activePageIds = array();

        array_push($activePageIds, (int)$pageId);

        /*return $activePageIds;
        */
        $maxCount = 20;

        while($page != null && $page['pid'] != 0) {
            $page = $this->getPageRepository()->getPage($page['pid']);
            $pageLevelCount++;

            array_push($activePageIds, (int)$page['uid']);

            if ($pageLevelCount > $maxCount) {
                break;
            }
        }

        return $activePageIds;
    }


    /**
     * Retrieve typo3 database connection
     * @return \TYPO3\CMS\Core\Database\DatabaseConnection
     */
    protected function getDatabaseConnection()
    {
        return $GLOBALS['TYPO3_DB'];
    }

    /**
     * Retrieve root page uid from extension navigation
     * @return int
     */
    protected abstract function getRootPageUid();

    /**
     * Retrieve typo3 page repository
     * @return PageRepository
     */
    protected function getPageRepository()
    {
        /** @var PageRepository $pageRepo */
        $pageRepo = $GLOBALS['TSFE']->sys_page;
        $pageRepo->init(false);

        return $pageRepo;
    }

    /**
     * Retrieve UriBuilder
     * @return UriBuilder
     */
    protected function getUriBuilder()
    {
        /** @var UriBuilder $uriBuilder */
        $uriBuilder = $this->renderingContext->getControllerContext()->getUriBuilder();

        $uriBuilder
            ->reset()
            ->setArguments(array(
                //'L' => $GLOBALS['TSFE']->sys_language_uid,
            ));

        return $uriBuilder;
    }

    /**
     * @return FluidTemplateRenderer
     */
    protected function getFluidTemplateRenderer()
    {
        if ($this->fluidTemplateRenderer === null) {
            $this->fluidTemplateRenderer = new FluidTemplateRenderer(
                __DIR__ . '/../../../Resources/Private/Views/'
            );
        }

        return $this->fluidTemplateRenderer;
    }

    /**
     * @param $controllerContext
     */
    public function setControllerContext($controllerContext) {
        $this->controllerContext = $controllerContext;
    }
}
