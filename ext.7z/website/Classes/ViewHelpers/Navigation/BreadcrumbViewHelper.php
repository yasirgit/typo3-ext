<?php

namespace Standardlife\Website\ViewHelpers\Navigation;

use OH\Ohmex\Renderer\FluidTemplateRenderer;
use TYPO3\CMS\Extbase\Utility\DebuggerUtility;
use TYPO3\CMS\Frontend\Page\PageRepository;
use TYPO3Fluid\Fluid\Core\ViewHelper\AbstractViewHelper;

/**
 * Class BreadcrumbViewHelper
 * @package Standardlife\Website\ViewHelpers\Navigation
 */
class BreadcrumbViewHelper extends AbstractViewHelper
{

    /** @var FluidTemplateRenderer */
    protected $fluidTemplateRenderer = null;

    /**
     * Initialize arguments
     */
    public function initializeArguments()
    {
        parent::initializeArguments();

        $this->registerArgument('pageUid', 'integer', 'Page uid', false, null);
        $this->registerArgument('wrappingTagName', 'string', 'Wrapping tag name for breadcrumb', false, 'section');
    }

    /**
     * @return string
     */
    public function render()
    {
        $pageUid = $this->arguments['pageUid'];
        if ($pageUid === null) {
            $pageUid = $GLOBALS['TSFE']->id;
        }

        $pages = $this->getBreadcrumbPages($pageUid);

        $html = $this->renderBreadcrumb($pages, $this->arguments['wrappingTagName']);

        return $html;
    }

    /**
     * @param array $pages
     * @return string
     */
    protected function renderBreadcrumb($pages, $wrappingTagName)
    {
        $mainNavigationHtml = $this->getFluidTemplateRenderer()->render('Navigation/Breadcrumb', array(
            'pages' => $pages,
            'wrappingTagName' => $wrappingTagName,
        ));

        return $mainNavigationHtml;
    }

    /**
     * @param $currentPageId
     * @return array
     */
    protected function getBreadcrumbPages($currentPageId) {
        $page = $this->getPageRepository()->getPage($currentPageId);

        $pageLevelCount = 1;
        $pages = [$page];

        $maxCount = 20;
        while($page != null && $page['pid'] != 0) {
            $page = $this->getPageRepository()->getPage($page['pid']);
            $pageLevelCount++;

            if ($page['doktype'] == PageRepository::DOKTYPE_SYSFOLDER) {
                continue;
            }

            array_push($pages, $page);

            if ($pageLevelCount > $maxCount) {
                break;
            }
        }

        $pages = array_reverse($pages);

        return $pages;
    }

    /**
     * Retrieve typo3 page repository
     * @return PageRepository
     */
    protected function getPageRepository()
    {
        /** @var PageRepository $pageRepo */
        $pageRepo = $GLOBALS['TSFE']->sys_page;
        $pageRepo->init(false);

        return $pageRepo;
    }

    /**
     * @return FluidTemplateRenderer
     */
    protected function getFluidTemplateRenderer()
    {
        if ($this->fluidTemplateRenderer === null) {
            $this->fluidTemplateRenderer = new FluidTemplateRenderer(
                __DIR__ . '/../../../Resources/Private/Views/'
            );
        }

        return $this->fluidTemplateRenderer;
    }

}