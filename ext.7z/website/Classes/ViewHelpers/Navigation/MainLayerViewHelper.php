<?php

namespace Standardlife\Website\ViewHelpers\Navigation;

use TYPO3\CMS\Extbase\Utility\DebuggerUtility;

/**
 * Class MainLayerViewHelper
 * @package Standardlife\Website\ViewHelpers\Navigation
 */
class MainLayerViewHelper extends AbstractNavigationViewHelper
{
    /**
     * Initialize arguments
     */
    public function initializeArguments()
    {
        parent::initializeArguments();

        $this->registerArgument('radioButtonsOnly', 'boolean', 'render radio buttons', false, false);
    }

    /**
     * @return string
     */
    public function render()
    {
        $radioButtonsOnly = $this->arguments['radioButtonsOnly'];

        // get active page ids
        $this->activePageIds = $this->getActivePageIds($GLOBALS['TSFE']->id);

        if (isset($_GET['debug'])) {
            DebuggerUtility::var_dump($this->activePageIds);
        }

        $pageRepo = $this->getPageRepository();

        $where = ' AND doktype IN (1,2,3,4,7)';
        $data = $pageRepo->getMenu($this->getRootPageUid(), '*', 'sorting', $where);

        /*
         * remove hidden pages (nav_hide).
         *
         * Don't try to remove them in the where statement.
         * Because of workspaces one only knows the value of nav_hide
         * after the workspace overlay data has been loaded.
         */
        foreach ($data as $key => $pageRow) {
            if ($pageRow['nav_hide'] != '0') {
                unset($data[$key]);
            }
        }

        $counter = 1;

        $pages = [];
        foreach ($data as $pageData) {
            // retrieve sub pages
            $where = ' AND doktype IN (1,2,3,4,7) ';
            $subPages = $pageRepo->getMenu($pageData['uid'], '*', 'sorting', $where);
            /*
             * remove hidden pages (nav_hide).
             *
             * Don't try to remove them in the where statement.
             * Because of workspaces one only knows the value of nav_hide
             * after the workspace overlay data has been loaded.
             */
            $pageData['subPages'] = [];
            foreach ($subPages as $key => $pageRow) {
                if ($pageRow['nav_hide'] != '0') {
                    unset($subPages[$key]);
                } else {
                    $pageRow['subPages'] = [];

                    $subPages2 = $pageRepo->getMenu($pageRow['uid'], '*', 'sorting', $where);
                    foreach ($subPages2 as $key2 => $pageRow2) {
                        if ($pageRow2['nav_hide'] != '0') {
                            unset($subPages2[$key2]);
                        } else {
                            $pageRow2['subPages'] = [];

                            $subPages3 = $pageRepo->getMenu($pageRow2['uid'], '*', 'sorting', $where);
                            foreach ($subPages3 as $key3 => $pageRow3) {
                                if ($pageRow3['nav_hide'] != '0') {
                                    unset($subPages3[$key3]);
                                } else {
                                    $pageRow3['subPages'] = [];

                                    $subPages4 = $pageRepo->getMenu($pageRow3['uid'], '*', 'sorting', $where);
                                    foreach ($subPages4 as $key4 => $pageRow4) {
                                        if ($pageRow4['nav_hide'] != '0') {
                                            unset($subPages4[$key4]);
                                        } else {
                                            $pageRow4['subPages'] = [];

                                            $subPages5 = $pageRepo->getMenu($pageRow4['uid'], '*', 'sorting', $where);
                                            foreach ($subPages5 as $key5 => $pageRow5) {
                                                if ($pageRow5['nav_hide'] != '0') {
                                                    unset($subPages5[$key5]);
                                                } else {
                                                    $pageRow5['active'] = in_array($pageRow5['uid'], $this->activePageIds);
                                                    $pageRow4['subPages'][] = $pageRow5;
                                                }
                                            }

                                            $pageRow4['active'] = in_array($pageRow4['uid'], $this->activePageIds);
                                            $pageRow3['subPages'][] = $pageRow4;
                                        }
                                    }

                                    $pageRow3['active'] = in_array($pageRow3['uid'], $this->activePageIds);
                                    $pageRow2['subPages'][] = $pageRow3;

                                }
                            }

                            $pageRow2['active'] = in_array($pageRow2['uid'], $this->activePageIds);
                            $pageRow['subPages'][] = $pageRow2;
                        }
                    }

                    $pageRow['active'] = in_array($pageRow['uid'], $this->activePageIds);
                    $pageData['subPages'][] = $pageRow;
                }
            }


            $pages[] = $pageData;
            $counter++;
        }

        $html = $this->renderMainNavigation($pages, $radioButtonsOnly);

        return $html;
    }

    /**
     * @param array $pages
     * @param bool $radioButtonsOnly
     * @return string
     */
    protected function renderMainNavigation($pages, $radioButtonsOnly)
    {
        $mainNavigationHtml = $this->getFluidTemplateRenderer()->render('Navigation/MainLayer', array(
            'pages' => $pages,
            'radioButtonsOnly' => $radioButtonsOnly,
        ));

        return $mainNavigationHtml;
    }

    /**
     * Retrieve root page uid from extension navigation
     * @return int
     */
    protected function getRootPageUid()
    {
        $extensionConfiguration = unserialize($GLOBALS['TYPO3_CONF_VARS']['EXT']['extConf']['website']);

        $rootPageUid = 1;
        if (array_key_exists('mainNavigationRootPageUid', $extensionConfiguration)) {
            $rootPageUid = $extensionConfiguration['mainNavigationRootPageUid'];
        }

        return $rootPageUid;
    }
}
