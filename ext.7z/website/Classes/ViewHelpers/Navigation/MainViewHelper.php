<?php

namespace Standardlife\Website\ViewHelpers\Navigation;




use TYPO3\CMS\Extbase\Utility\DebuggerUtility;


/**
 * Class MainViewHelper
 * @package Standardlife\Website\ViewHelpers\Navigation
 */
class MainViewHelper extends AbstractNavigationViewHelper
{

    /**
     * @return string
     */
    public function render()
    {
        // get active page ids
        $this->activePageIds = $this->getActivePageIds($GLOBALS['TSFE']->id);

        if (isset($_GET['debug'])) {
            DebuggerUtility::var_dump($this->activePageIds);
        }

        $pageRepo = $this->getPageRepository();

        $where = ' AND doktype IN (1,2,3,4,7)';
        $data = $pageRepo->getMenu($this->getRootPageUid(), '*', 'sorting', $where);

        /*
         * remove hidden pages (nav_hide).
         *
         * Don't try to remove them in the where statement.
         * Because of workspaces one only knows the value of nav_hide
         * after the workspace overlay data has been loaded.
         */
        foreach ($data as $key=>$pageRow) {
            if ($pageRow['nav_hide'] != '0') {
                unset($data[$key]);
            }
        }

        $navigationHtml = '';
        $counter = 1;

        foreach ($data as $pageData) {
            // retrieve sub pages
            $where = ' AND doktype IN (1,2,3,4,7) ';
            $subPages = $pageRepo->getMenu($pageData['uid'], '*', 'sorting', $where);
            /*
             * remove hidden pages (nav_hide).
             *
             * Don't try to remove them in the where statement.
             * Because of workspaces one only knows the value of nav_hide
             * after the workspace overlay data has been loaded.
             */
            foreach ($subPages as $key=>$pageRow) {
                if ($pageRow['nav_hide'] != '0') {
                    unset($subPages[$key]);
                }
            }

            $navigationHtml .= $this->renderFirstLevelNavigationItem($counter, $pageData['uid'], ($pageData['nav_title'] != '' ? $pageData['nav_title'] : $pageData['title']), $pageData, $subPages);

            $counter++;
        }


        $mainNavigationHtml = $this->renderMainNavigation($navigationHtml);

        $html = $mainNavigationHtml;

        return $html;
    }


    /**
     * @param $navigationHtml
     * @return string
     */
    protected function renderMainNavigation($navigationHtml)
    {
        $mainNavigationHtml = $this->getFluidTemplateRenderer()->render('Navigation/Main', array(
            'navigationHtml' => $navigationHtml,
        ));

        return $mainNavigationHtml;
    }

    /**
     * @param $counter
     * @param $uid
     * @param $title
     * @param $pageData
     * @param $subPages
     * @return string
     */
    protected function renderFirstLevelNavigationItem($counter, $uid, $title, $pageData, $subPages)
    {
        $uriBuilder = $this->getUriBuilder();

        $isActive = in_array((int)$uid, $this->activePageIds);

        $target = '';
        if ($pageData['target']) {
            $target = ' target="' . $pageData['target'] . '"';
        }
        if ($pageData['doktype'] == 3 && $pageData['url'] != '') {
            $link = '//' . $pageData['url'];

        } else {

            // add caseStudy category id
            $link = $uriBuilder
                ->setTargetPageUid($uid)
                ->buildFrontendUri();

        }

        $html = '<li' . ($isActive ? ' class="active"' : '') . '>';
        $html .= '  <label for="mainNavControl' . $counter . '">
                        <a href="' . $link . '"' . $target . ' class="hasSubMenu"><span>' . $title . '</span></a>
                    </label>
                </li>';

        return $html;
    }

    /**
     * Retrieve root page uid from extension navigation
     * @return int
     */
    protected function getRootPageUid()
    {
        $rootLine = $GLOBALS['TSFE']->rootLine;
        return $rootLine[0]['uid'];

        $extensionConfiguration = unserialize($GLOBALS['TYPO3_CONF_VARS']['EXT']['extConf']['website']);

        $rootPageUid = 1;
        if (array_key_exists('mainNavigationRootPageUid', $extensionConfiguration)) {
            $rootPageUid = $extensionConfiguration['mainNavigationRootPageUid'];
        }

        return $rootPageUid;
    }

}
