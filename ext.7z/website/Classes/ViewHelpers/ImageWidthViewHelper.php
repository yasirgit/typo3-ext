<?php

namespace Standardlife\Website\ViewHelpers;


use TYPO3Fluid\Fluid\Core\ViewHelper\AbstractViewHelper;

/**
 * Class ImageWidthViewHelper
 * @package Standardlife\Website\ViewHelpers
 */
class ImageWidthViewHelper extends AbstractViewHelper
{

    /**
     * @param string $url
     * @return mixed|string
     */
    public function render($url)
    {
        $imagePath = PATH_site . ltrim($url, '/');

        $imageSize = getimagesize($imagePath);

        return $imageSize[0];
    }

}
