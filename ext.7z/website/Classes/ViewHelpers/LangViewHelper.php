<?php

namespace Standardlife\Website\ViewHelpers;




use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Utility\DebuggerUtility;
use TYPO3\CMS\Fluid\Core\ViewHelper\AbstractViewHelper;


/**
 * Class LangViewHelper
 * @package Standardlife\Website\ViewHelpers
 */
class LangViewHelper extends AbstractViewHelper
{
    /**
     * Initialize arguments
     */
    public function initializeArguments()
    {
        parent::initializeArguments();
    }

    /**
     * @return string
     */
    public function render()
    {
        //DebuggerUtility::var_dump(GeneralUtility::_GP('L'));
        //DebuggerUtility::var_dump(GeneralUtility::_GP('test'));
        //DebuggerUtility::var_dump($GLOBALS['TSFE']);
        return '';
    }

}
