<?php

namespace Standardlife\Website\ViewHelpers;




use TYPO3\CMS\Fluid\Core\ViewHelper\AbstractViewHelper;


/**
 * Class GetEnvViewHelper
 * @package Standardlife\Website\ViewHelpers
 */
class GetEnvViewHelper extends AbstractViewHelper
{
    /**
     * Initialize arguments
     */
    public function initializeArguments()
    {
        parent::initializeArguments();

        $this->registerArgument('name', 'string', 'Name of environment variable', true);
    }

    /**
     * @return string
     */
    public function render()
    {
        $name = $this->arguments['name'];
        $value = (isset($_ENV[$name]) ? $_ENV[$name] : '');

        return $value;
    }

}
