<?php

namespace Standardlife\Website\ViewHelpers;




use TYPO3Fluid\Fluid\Core\ViewHelper\AbstractViewHelper;

/**
 * Class TextToDashViewHelper
 * @package Standardlife\Website\ViewHelpers
 */
class TextToDashViewHelper extends AbstractViewHelper
{


    /**
     * @return string
     * @param string $text
     */
    public function render($text)
    {
        if ($text == '' || !is_string($text)) {
            return '';
        }
        $text = strtolower($text);
        $text = str_replace('ä', 'ae', $text);
        $text = str_replace('ö', 'oe', $text);
        $text = str_replace('ü', 'ue', $text);
        $text = str_replace('ß', 'ss', $text);
        $text = preg_replace('/\s+/is', ' ', $text);
        $text = str_replace(' ', '-', $text);
        $text = preg_replace('/[^a-z0-9\-\_\s]+/is', '', $text);

        return $text;
    }

}
