<?php

namespace Standardlife\Website\ViewHelpers;


use TYPO3Fluid\Fluid\Core\ViewHelper\AbstractViewHelper;

/**
 * Class PrettyDateViewHelper
 * @package Standardlife\Website\ViewHelpers
 */
class PrettyDateViewHelper extends AbstractViewHelper
{

    /**
     * @param \DateTime|string $date
     * @return mixed|string
     */
    public function render($date)
    {
        if (!$date instanceof \DateTime) {
            return '';
        }

        $day = $date->format('d');
        $month = $date->format('m');
        $year = $date->format('Y');

        $monthNames = ['Januar', 'Februar', 'März', 'April', 'Mai', 'Juni', 'Juli', 'August', 'September', 'Oktober', 'November', 'Dezember'];
        $monthName = $monthNames[$month - 1];

        $resultDate = $day . '. ' . $monthName . ' ' . $year;

        return $resultDate;
    }

}
