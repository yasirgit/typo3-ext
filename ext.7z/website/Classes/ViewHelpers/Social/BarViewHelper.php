<?php

namespace Standardlife\Website\ViewHelpers\Social;

use OH\Ohmex\Renderer\FluidTemplateRenderer;


use TYPO3Fluid\Fluid\Core\ViewHelper\AbstractViewHelper;

/**
 * Class BarViewHelper
 * @package Standardlife\Website\ViewHelpers\Social
 */
class BarViewHelper extends AbstractViewHelper
{

    /** @var FluidTemplateRenderer */
    protected $fluidTemplateRenderer;

    /**
     * @return string
     */
    public function render()
    {



        return $this->renderBar();
    }


    /**
     * @return string
     */
    protected function renderBar()
    {
        $html = $this->getFluidTemplateRenderer()->render('Social/Bar', [

        ]);

        return $html;
    }


    /**
     * @return FluidTemplateRenderer
     */
    protected function getFluidTemplateRenderer()
    {
        if ($this->fluidTemplateRenderer === null) {
            $this->fluidTemplateRenderer = new FluidTemplateRenderer(
                __DIR__ . '/../../../Resources/Private/Views/'
            );
        }

        return $this->fluidTemplateRenderer;
    }

}
