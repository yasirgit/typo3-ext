<?php

namespace Standardlife\Website\Hooks;


use HDNET\Autoloader\Hooks\BackendLayoutProvider;
use TYPO3\CMS\Backend\Utility\BackendUtility;
use TYPO3\CMS\Backend\View\BackendLayout\BackendLayout;
use TYPO3\CMS\Backend\Wizard\NewContentElementWizardHookInterface;
use TYPO3\CMS\Core\TypoScript\Parser\TypoScriptParser;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Object\ObjectManager;


/**
 * Class NewContentElementWizardHook
 * @package Standardlife\Website\Hooks
 * @hook TYPO3_CONF_VARS|SC_OPTIONS|cms|db_new_content_el|wizardItemsHook
 */
class NewContentElementWizardHook implements NewContentElementWizardHookInterface
{

    /**
     * Only display allowed wizard items, allowed by property "allowed" in backend_layout per column
     *
     * @param array $wizardItems
     * @param \TYPO3\CMS\Backend\Controller\ContentElement\NewContentElementController $parentObject
     */
    public function manipulateWizardItems(&$wizardItems, &$parentObject)
    {
        // handling if new content element is called from gridelement
        $container = (int)GeneralUtility::_GP('tx_gridelements_container');

        if ($container > 0) {
            return;
        }

        $backendLayout = $this->getBackendLayout($parentObject->id);

        if ($backendLayout === null) {
            return;
        }

        $data = $this->getBackendLayoutArrayConfig($backendLayout);
        $cTypeMapping = $this->extractCTypeMapping($wizardItems);
        $allowedWizardItems = [];

        foreach ($data['backend_layout.']['rows.'] as $rowId => $row) {
            foreach ($row['columns.'] as $columnId => $column) {
                if ($column['colPos'] != $parentObject->colPos) {
                    continue;
                }

                if (array_key_exists('allowed', $column)) {
                    // wildcard used - all items are allowed, do not proceed
                    if (trim($column['allowed']) == '*') {
                        break;
                    }

                    $allowedContentElements = explode(',', $column['allowed']);


                    foreach ($allowedContentElements as $allowedContentElement) {
                        $allowedContentElement = trim($allowedContentElement);

                        $key = $cTypeMapping[$allowedContentElement];

                        if (array_key_exists($key, $wizardItems)) {
                            // add item to allowed wizard items
                            $allowedWizardItems[$key] = $wizardItems[$key];

                            // add tab to allowed wizard items
                            $tabName = explode('_', $key)[0];
                            $allowedWizardItems[$tabName] = $wizardItems[$tabName];
                        }
                    }

                    // unset not allowed wizard items
                    foreach ($wizardItems as $key => $el) {
                        if (!array_key_exists($key, $allowedWizardItems)) {
                            unset($wizardItems[$key]);
                        }
                    }
                }

                break;
            }
        }
    }

    /**
     * @param $pageUid
     * @return NULL|BackendLayout
     */
    protected function getBackendLayout($pageUid)
    {
        if ($pageUid == 0) {
            return null;
        }
        /** @var ObjectManager $objectManager */
        $objectManager = GeneralUtility::makeInstance(ObjectManager::class);
        /** @var BackendLayoutProvider $backendLayoutProvider */
        $backendLayoutProvider = $objectManager->get(BackendLayoutProvider::class);


        $pageInfo = BackendUtility::readPageAccess($pageUid, '');
        $backendLayoutName = $pageInfo['backend_layout'];
        if (stripos($backendLayoutName, 'autoloader') !== false) {
            $backendLayoutName = explode('__', $backendLayoutName)[1];
        }

        if (empty($backendLayoutName)) {
            return $this->getBackendLayout($pageInfo['pid']);
        }

        $backendLayout = $backendLayoutProvider->getBackendLayout($backendLayoutName, $pageUid);

        return $backendLayout;
    }

    /**
     * @param BackendLayout $backendLayout
     * @return array
     */
    protected function getBackendLayoutArrayConfig(BackendLayout $backendLayout)
    {
        $typoScriptParser = new TypoScriptParser();
        $typoScriptParser->parse($backendLayout->getConfiguration());
        $data = $typoScriptParser->setup;

        return $data;
    }

    /**
     * @param $wizardItems
     * @return array
     */
    protected function extractCTypeMapping($wizardItems)
    {
        $cTypeMapping = [];

        foreach ($wizardItems as $key => $entry) {
            $cTypeMapping[$entry['tt_content_defValues']['CType']] = $key;
        }

        return $cTypeMapping;
    }
}
