<?php

namespace Standardlife\Website\Enumeration;

/**
 * Class ScopeEnum
 * @package Standardlife\Website\Enumeration
 */
class ScopeEnum
{

    const DE = 'DE';
    const AT = 'AT';
    const DE_AND_AT = '';

    /**
     * @return array
     */
    public static function getTcaItems()
    {
        $oClass = new \ReflectionClass(__CLASS__);
        $consts = $oClass->getConstants();

        $items = [];
        foreach ($consts as $key => $value) {
            $items[] = [$value, $key];
        }

        return $items;
    }

}