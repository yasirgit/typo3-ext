<?php

namespace Standardlife\Website\Domain\Repository;

use TYPO3\CMS\Extbase\Domain\Repository\FrontendUserRepository;
use TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings;

/**
 * Class FeUsersRepository
 * @package Standardlife\Website\Domain\Repository
 */
class FeUsersRepository extends FrontendUserRepository
{

    protected $tableName = 'fe_users';

    public function initializeObject()
    {
        /** @var $defaultQuerySettings Typo3QuerySettings */
        $defaultQuerySettings = $this->objectManager->get(Typo3QuerySettings::class);
        // add sys_language_uid constraint 8
        $defaultQuerySettings->setRespectSysLanguage(false);
        $defaultQuerySettings->setRespectStoragePage(false);
        $this->setDefaultQuerySettings($defaultQuerySettings);
    }

}