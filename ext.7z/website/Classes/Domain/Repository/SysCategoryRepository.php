<?php

namespace Standardlife\Website\Domain\Repository;


use Standardlife\Website\Domain\Model\SysCategory;
use TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings;
use TYPO3\CMS\Extbase\Persistence\Repository;
use TYPO3\CMS\Extbase\Utility\DebuggerUtility;

/**
 * Class SysCategoryRepository
 * @package Standardlife\Website\Domain\Repository
 */
class SysCategoryRepository extends Repository
{

    public function initializeObject()
    {
        /** @var $defaultQuerySettings Typo3QuerySettings */
        $defaultQuerySettings = $this->objectManager->get(Typo3QuerySettings::class);
        $defaultQuerySettings->setRespectSysLanguage(true);
        $defaultQuerySettings->setRespectStoragePage(false);
        $this->setDefaultQuerySettings($defaultQuerySettings);
    }

    /**
     * @param array $uids
     * @return SysCategory[]
     */
    public function findByUids($uids)
    {
        if (empty($uids)) {
            return [];
        }

       $q = $this->createQuery();
       $q->matching($q->in('uid', $uids));

       $result = $q->execute();

       return $result->toArray();
    }

    /**
     * @param $name
     * @return SysCategory|bool
     */
    public function findByName($name)
    {
        $name = (string)$name;

        DebuggerUtility::var_dump($name);

        $q = $this->createQuery();
        $q->matching($q->equals('title', $name));

        //$q->setLimit(1);
        $result = $q->execute();

        return reset($result->toArray());
    }

    /**
     * @param SysCategory $parentCategory
     * @return SysCategory[]
     */
    public function findChildCategories($parentCategory)
    {
        $uid = $parentCategory->getUid();

        $q = $this->createQuery();
        $q->matching($q->equals('parent', $uid));

        $result = $q->execute();

        /** @var SysCategory[] $categories */
        $categories = $result->toArray();
        if (count($categories) > 0) {
            foreach ($categories as &$category) {
                $category->setSubCategories($this->findChildCategories($category));
            }
        }


        return $categories;
    }
}