<?php

namespace Standardlife\Website\Domain\Repository;


use Standardlife\Website\Domain\Model\Pages;
use TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings;
use TYPO3\CMS\Extbase\Persistence\Repository;

/**
 * Class PagesRepository
 * @package Standardlife\Website\Domain\Repository
 */
class PagesRepository extends Repository
{

    public function initializeObject()
    {
        /** @var $defaultQuerySettings Typo3QuerySettings */
        $defaultQuerySettings = $this->objectManager->get(Typo3QuerySettings::class);
        // add sys_language_uid constraint 8
        $defaultQuerySettings->setRespectSysLanguage(true);
        $defaultQuerySettings->setRespectStoragePage(false);
        $this->setDefaultQuerySettings($defaultQuerySettings);
    }

    /**
     * @param array $uids
     * @return array
     */
    public function findByUids($uids)
    {
        if (count($uids) == 0) {
            return [];
        }

        $q = $this->createQuery();
        $q->getQuerySettings()->setRespectStoragePage(false);

        $constraints = [
            $q->in('uid', $uids),
        ];

        $q->matching($q->logicalAnd($constraints));

        $result = $q->execute()->toArray();

        return $result;
    }

    /**
     * @param $parentPageUid
     * @return Pages[]|\TYPO3\CMS\Extbase\Persistence\QueryResultInterface
     */
    public function getSubPages($parentPageUid)
    {
        $q = $this->createQuery();
        $q->matching(
            $q->logicalAnd(
                $q->equals('pid', (int)$parentPageUid),
                $q->in('doktype', [1, 2, 3, 4, 7]),
                $q->equals('hidden', false)
            )
        );
        return $q->execute();
    }

    /**
     * @param $parentPageUid
     * @param null $categoryUid
     * @param int $page
     * @param int $itemsPerPage
     * @return Pages[]|\TYPO3\CMS\Extbase\Persistence\QueryResultInterface
     */
    public function getTilePages($parentPageUid, $categoryUid = null, $page = 1, $itemsPerPage = 2)
    {
        $itemsPerPage = (int)$itemsPerPage;

        $q = $this->createQuery();
        $condition1 = $q->logicalAnd(
            $q->equals('pid', (int)$parentPageUid),
            $q->in('doktype', [1, 2, 3, 4, 7]),
            $q->equals('hidden', false)
        );

        if ($categoryUid !== null) {
            $condition2 = $q->equals('categories.uid', (int)$categoryUid);

            $conditions = $q->logicalAnd(
                $condition1,
                $condition2
            );
        } else {
            $conditions = $condition1;
        }

        $q->matching($conditions);
        $q->setOffset(($page - 1) * $itemsPerPage);
        $q->setLimit($itemsPerPage);
        return $q->execute();
    }

    /**
     * @param $parentPageUid
     * @param null $categoryUid
     * @param int $page
     * @param int $itemsPerPage
     * @return int
     */
    public function pageExists($parentPageUid, $categoryUid = null, $page = 1, $itemsPerPage = 2)
    {
        $itemsPerPage = (int)$itemsPerPage;

        $q = $this->createQuery();
        $condition1 = $q->logicalAnd(
            $q->equals('pid', (int)$parentPageUid),
            $q->in('doktype', [1, 2, 3, 4, 7]),
            $q->equals('hidden', false)
        );

        if ($categoryUid !== null) {
            $condition2 = $q->equals('categories.uid', (int)$categoryUid);

            $conditions = $q->logicalAnd(
                $condition1,
                $condition2
            );
        } else {
            $conditions = $condition1;
        }

        $q->matching($conditions);
        $q->setOffset(($page - 1) * $itemsPerPage);
        $q->setLimit($itemsPerPage);
        $count = $q->execute()->count();

        return $count > 0;
    }
}