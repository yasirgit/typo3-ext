<?php

namespace Standardlife\Website\Domain\Model;


use TYPO3\CMS\Extbase\Domain\Model\FrontendUser;
use TYPO3\CMS\Extbase\Persistence\ObjectStorage;

/**
 * A Frontend User
 * @db fe_users
 */
class FeUsers extends FrontendUser
{
    /**
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\TYPO3\CMS\Extbase\Domain\Model\FileReference>
     */
    protected $image;

    /**
     * Constructs a new Front-End User
     *
     * @api
     * @param string $username
     * @param string $password
     */
    public function __construct($username = '', $password = '')
    {
        parent::__construct($username, $password);

        $this->image = new ObjectStorage();
    }

    /**
     * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage
     */
    public function getImage()
    {
        return $this->image;
    }

    /**
     * @return string
     */
    public function getFullName() {
        return ($this->getFirstName() != '' ? $this->getFirstName() . ' ' : '') . ($this->getMiddleName() != '' ? $this->getMiddleName() . ' ' : '') . $this->getLastName();
    }

}
