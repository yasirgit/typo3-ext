<?php
namespace Standardlife\Website\Domain\Model;
use TYPO3\CMS\Extbase\Domain\Model\FrontendUserGroup;

/**
 * A Frontend User Group
 * @db fe_groups
 */
class FeGroups extends FrontendUserGroup
{

}
