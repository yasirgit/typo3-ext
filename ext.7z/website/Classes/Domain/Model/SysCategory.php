<?php

namespace Standardlife\Website\Domain\Model;

use TYPO3\CMS\Extbase\Domain\Model\Category;
use TYPO3\CMS\Extbase\DomainObject\AbstractEntity;

/**
 * Class SysCategory
 * @package Standardlife\Website\Domain\Model
 *
 * @db         sys_category
 */
class SysCategory extends AbstractEntity
{

    /** @var int */
    protected $uid;

    /** @var string */
    protected $title;

    /** @var int */
    protected $sorting;

    /** @var Category[] */
    protected $subCategories;

    /**
     * @return int
     */
    public function getUid()
    {
        return $this->uid;
    }

    /**
     * @param int $uid
     */
    public function setUid($uid)
    {
        $this->uid = $uid;
    }

    /**
     * @return string
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * @param string $title
     */
    public function setTitle($title)
    {
        $this->title = $title;
    }

    /**
     * @return int
     */
    public function getSorting()
    {
        return $this->sorting;
    }

    /**
     * @param int $sorting
     */
    public function setSorting($sorting)
    {
        $this->sorting = $sorting;
    }

    /**
     * @return Category[]
     */
    public function getSubCategories()
    {
        return $this->subCategories;
    }

    /**
     * @param Category[] $subCategories
     */
    public function setSubCategories(array $subCategories)
    {
        $this->subCategories = $subCategories;
    }

}