<?php

namespace Standardlife\Website\Domain\Model;

use TYPO3\CMS\Backend\Utility\BackendUtility;
use TYPO3\CMS\Extbase\Domain\Model\Category;
use TYPO3\CMS\Extbase\DomainObject\AbstractEntity;
use TYPO3\CMS\Extbase\Persistence\ObjectStorage;

/**
 * Class Pages
 * @package Standardlife\Website\Domain\Model
 *
 * @db         pages
 */
class Pages extends AbstractEntity
{

    /**
     * @var int
     */
    protected $uid;

    /** @var string */
    protected $title;

    /** @var string */
    protected $subtitle;

    /** @var string */
    protected $navTitle;

    /**
     * @var string
     * @db
     */
    protected $txMobileNavTitle;

    /** @var string */
    protected $backendLayout;

    /** @var string */
    protected $backendLayoutNextLevel;

    /** @var string */
    protected $backendLayoutName;

    /**
     * @var \TYPO3\CMS\Extbase\Domain\Model\FileReference
     * @db
     */
    protected $txHeaderImage;

    /**
     * @var \TYPO3\CMS\Extbase\Domain\Model\FileReference
     * @db
     */
    protected $txTileImagePortrait;

    /**
     * @var \TYPO3\CMS\Extbase\Domain\Model\FileReference
     * @db
     */
    protected $txTileImageLandscape;

    /**
     * @var string
     * @db
     */
    protected $txTeaserText;

    /**
     * @var string
     * @db
     */
    protected $txType;

    /**
     * @var \DateTime
     * @db
     */
    protected $txDate;

    /**
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\TYPO3\CMS\Extbase\Domain\Model\Category>
     */
    protected $categories;

    /**
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\TYPO3\CMS\Extbase\Domain\Model\Category>
     * @db
     */
    protected $txTags;

    /**
     * @var \TYPO3\CMS\Extbase\Domain\Model\FileReference
     */
    protected $txKoningopengraphImage;

    /**
     * @var string
     */
    protected $txKoningopengraphTitle;

    /**
     * @var string
     */
    protected $txKoningopengraphDescription;

    /**
     * @var string
     */
    protected $txKoningopengraphType;

    /**
     * @var \Standardlife\SlCrd\Domain\Model\Crd
     * @db
     */
    protected $crd;

    /**
     * @var Pages[]
     */
    protected $subPages = [];

    /**
     * Pages constructor.
     */
    public function __construct()
    {
        $this->categories = new ObjectStorage();

        $this->backendLayoutName = $this->getBackendLayoutName();
    }


    /**
     * @return int
     */
    public function getUid()
    {
        return $this->uid;
    }

    /**
     * @param int $uid
     */
    public function setUid($uid)
    {
        $this->uid = $uid;
    }

    /**
     * @return string
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * @param string $title
     */
    public function setTitle($title)
    {
        $this->title = $title;
    }

    /**
     * @return string
     */
    public function getSubtitle()
    {
        return $this->subtitle;
    }

    /**
     * @param string $subtitle
     */
    public function setSubtitle($subtitle)
    {
        $this->title = $subtitle;
    }

    /**
     * @return string
     */
    public function getNavTitle()
    {
        return $this->navTitle;
    }

    /**
     * @param string $navTitle
     */
    public function setNavTitle($navTitle)
    {
        $this->navTitle = $navTitle;
    }

    /**
     * @return string
     */
    public function getTxMobileNavTitle()
    {
        return $this->txMobileNavTitle;
    }

    /**
     * @param string $txMobileNavTitle
     */
    public function setTxMobileNavTitle(string $txMobileNavTitle)
    {
        $this->txMobileNavTitle = $txMobileNavTitle;
    }

    /**
     * @return ObjectStorage
     */
    public function getCategories()
    {
        return $this->categories;
    }

    /**
     * @param ObjectStorage $categories
     */
    public function setCategories($categories)
    {
        $this->categories = $categories;
    }

    /**
     * @return \TYPO3\CMS\Extbase\Domain\Model\FileReference
     */
    public function getTxHeaderImage()
    {
        return $this->txHeaderImage;
    }

    /**
     * @param \TYPO3\CMS\Extbase\Domain\Model\FileReference $txHeaderImage
     */
    public function setTxHeaderImage($txHeaderImage)
    {
        $this->txHeaderImage = $txHeaderImage;
    }

    /**
     * @return \TYPO3\CMS\Extbase\Domain\Model\FileReference
     */
    public function getTxTileImagePortrait()
    {
        return $this->txTileImagePortrait;
    }

    /**
     * @param \TYPO3\CMS\Extbase\Domain\Model\FileReference $txTileImagePortrait
     */
    public function setTxTileImagePortrait($txTileImagePortrait)
    {
        $this->txTileImagePortrait = $txTileImagePortrait;
    }

    /**
     * @return \TYPO3\CMS\Extbase\Domain\Model\FileReference
     */
    public function getTxTileImageLandscape()
    {
        return $this->txTileImageLandscape;
    }

    /**
     * @param \TYPO3\CMS\Extbase\Domain\Model\FileReference $txTileImageLandscape
     */
    public function setTxTileImageLandscape($txTileImageLandscape)
    {
        $this->txTileImageLandscape = $txTileImageLandscape;
    }

    /**
     * @return string
     */
    public function getTxTeaserText()
    {
        return $this->txTeaserText;
    }

    /**
     * @param string $txTeaserText
     */
    public function setTxTeaserText($txTeaserText)
    {
        $this->txTeaserText = $txTeaserText;
    }

    /**
     * @return string
     */
    public function getTxType()
    {
        return $this->txType;
    }

    /**
     * @param string $txType
     */
    public function setTxType($txType)
    {
        $this->txType = $txType;
    }

    /**
     * @return \DateTime
     */
    public function getTxDate()
    {
        return $this->txDate;
    }

    /**
     * @param \DateTime $txDate
     */
    public function setTxDate($txDate)
    {
        $this->txDate = $txDate;
    }

    /**
     * @return ObjectStorage
     */
    public function getTxTags()
    {
        return $this->txTags;
    }

    /**
     * @var string
     * @return string
     */
    public function getTagsString()
    {
        $tagIds = array();
        foreach ($this->txTags->toArray() as $tag) {
            /** @var Category $tag */
            $tagIds[] = $tag->getUid();
        }

        return ',' . join(',', $tagIds) . ',';
    }

    /**
     * @param ObjectStorage $txTags
     */
    public function setTxTags($txTags)
    {
        $this->txTags = $txTags;
    }

    /**
     * @return string
     */
    public function getBackendLayout()
    {
        return $this->backendLayout;
    }

    /**
     * @param string $backendLayout
     */
    public function setBackendLayout($backendLayout)
    {
        $this->backendLayout = $backendLayout;
    }

    /**
     * @return string
     */
    public function getBackendLayoutNextLevel()
    {
        return $this->backendLayoutNextLevel;
    }

    /**
     * @param string $backendLayoutNextLevel
     */
    public function setBackendLayoutNextLevel($backendLayoutNextLevel)
    {
        $this->backendLayoutNextLevel = $backendLayoutNextLevel;
    }

    /**
     * @return string
     */
    public function getBackendLayoutName()
    {
        $pageInfo = BackendUtility::readPageAccess($this->uid, '');
        $backendLayoutName = $pageInfo['backend_layout'];

        if (stripos($backendLayoutName, 'autoloader') !== false) {
            $backendLayoutName = explode('__', $backendLayoutName)[1];
        }

        return $backendLayoutName;
    }

    /**
     * @return \TYPO3\CMS\Extbase\Domain\Model\FileReference
     */
    public function getTxKoningopengraphImage()
    {
        return $this->txKoningopengraphImage;
    }

    /**
     * @param \TYPO3\CMS\Extbase\Domain\Model\FileReference $txKoningopengraphImage
     */
    public function setTxKoningopengraphImage($txKoningopengraphImage)
    {
        $this->txKoningopengraphImage = $txKoningopengraphImage;
    }

    /**
     * @return string
     */
    public function getTxKoningopengraphTitle()
    {
        return $this->txKoningopengraphTitle;
    }

    /**
     * @param string $txKoningopengraphTitle
     */
    public function setTxKoningopengraphTitle($txKoningopengraphTitle)
    {
        $this->txKoningopengraphTitle = $txKoningopengraphTitle;
    }

    /**
     * @return string
     */
    public function getTxKoningopengraphDescription()
    {
        return $this->txKoningopengraphDescription;
    }

    /**
     * @param string $txKoningopengraphDescription
     */
    public function setTxKoningopengraphDescription($txKoningopengraphDescription)
    {
        $this->txKoningopengraphDescription = $txKoningopengraphDescription;
    }

    /**
     * @return string
     */
    public function getTxKoningopengraphType()
    {
        return $this->txKoningopengraphType;
    }

    /**
     * @param string $txKoningopengraphType
     */
    public function setTxKoningopengraphType($txKoningopengraphType)
    {
        $this->txKoningopengraphType = $txKoningopengraphType;
    }

    /**
     * @return \Standardlife\SlCrd\Domain\Model\Crd
     */
    public function getCrd()
    {
        return $this->crd;
    }

    /**
     * @param \Standardlife\SlCrd\Domain\Model\Crd $crd
     */
    public function setCrd($crd)
    {
        $this->crd = $crd;
    }

    /**
     * @return Pages[]
     */
    public function getSubPages()
    {
        return $this->subPages;
    }

    /**
     * @param $subPages
     */
    public function setSubPages($subPages)
    {
        $this->subPages = $subPages;
    }

}