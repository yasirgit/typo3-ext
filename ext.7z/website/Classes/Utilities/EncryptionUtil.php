<?php

namespace Standardlife\Website\Utilities;

/**
 * Class EncryptionUtil
 * @package Standardlife\Website\Utilities
 */
class EncryptionUtil {

    protected static $method = 'aes-256-cbc';
    protected static $password = 'nk38Gp_?,?mX%A|F)[tP9uu*d9yWCr';
    protected static $iv = 'IV';

    /**
     * @param $data
     * @return string
     */
    public static function encrypt($data) {
        $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length(self::$method));
        $cryptedData = openssl_encrypt($data, self::$method, self::$password, 0, $iv);
        return $cryptedData . ':' . base64_encode($iv);
    }

    /**
     * @param $data
     * @return string
     */
    public static function decrypt($data) {
        $parts = explode(':', $data);
        $iv = base64_decode($parts[1]);
        return openssl_decrypt($parts[0], self::$method, self::$password, 0, $iv);
    }
}