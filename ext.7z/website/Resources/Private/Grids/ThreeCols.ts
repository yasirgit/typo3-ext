config {
    colCount = 1
    rowCount = 1
    rows {
        1 {
            columns {
                1 {
                    name = Content
                    colPos = 401
                    allowed = *
                }
            }
        }
    }
}