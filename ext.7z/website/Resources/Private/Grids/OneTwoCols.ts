config {
    colCount = 1
    rowCount = 2
    rows {
        1 {
            columns {
                1 {
                    name = Left
                    colPos = 401
                    allowed = *
                }
            }
        }
        2 {
            columns {
                1 {
                    name = Right
                    colPos = 402
                    allowed = *
                }
            }
        }
    }
}