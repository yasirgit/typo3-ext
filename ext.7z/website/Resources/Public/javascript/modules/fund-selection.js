define(
    ['jquery', 'data-tables'],
    function ($, dataTables) {

        var term = '',
            risk = '',
            fundGroup = '',
            product = '',
            strategy = '',
            resultCount = null,
            strategyMapping = {
                '': [],
                '1': [1, 2],
                '2': [3, 4],
                '3': [5, 6, 7]
            };


        /**
         * Filter result table
         * @param $dataTable
         */
        function filterTable($dataTable) {
            /**if (searchTerm.length < 3) {
                $dataTable.find('tbody tr').removeClass('hidden');
                return;
            }*/

            $dataTable.find('tbody tr').each(function (i, el) {
                var $el = $(el),
                    searchTerm = term.toLowerCase(),
                    name = $el.attr('data-name').toLowerCase(),
                    isin = $el.attr('data-isin').toLowerCase(),
                    wkn = $el.attr('data-wkn').toLowerCase(),
                    riskData = $el.attr('data-risk'),
                    groupData = $el.attr('data-group'),
                    allowedStrategyRiskValues = strategyMapping[strategy];

                if (
                    (
                        (searchTerm != '' && searchTerm.length > 1 && (name.indexOf(searchTerm) > -1 || isin.indexOf(searchTerm) > -1 || wkn.indexOf(searchTerm) > -1))
                        || (searchTerm === '' || searchTerm.length < 2)
                    )
                    && (
                        (risk != '' && (riskData === risk))
                        || (risk === '')
                    )
                    && (
                        (fundGroup != '' && (groupData === fundGroup))
                        || (fundGroup === '')
                    )
                    && (
                        (strategy != '' && ($.inArray(parseInt(riskData, 10), allowedStrategyRiskValues) > -1))
                        || (strategy === '')
                    )
                ) {
                    $el.removeClass('hidden');
                } else {
                    $el.addClass('hidden');
                }
            });

            setResultCount($dataTable);
        }

        /**
         * @todo: not final implementation
         * @param $fundSelection
         * @param $dataTable
         */
        function setFilterStatus($fundSelection, $dataTable) {
            var availableRisks = [],
                avaialableFundGroups = [],
                avaialableStrategies = [],
                $riskFilter = $fundSelection.find('.filterForm .riskFilter'),
                $fundGroupFilter = $fundSelection.find('.filterForm .fundGroupFilter'),
                $strategyFilter = $fundSelection.find('.filterForm .strategyFilter'),
                riskToStrategy = {};

            for (var propt in strategyMapping) {
                console.log(propt + ': ' + strategyMapping[propt]);
            }

            $dataTable.find('tr:not(.hidden)').each(function (i, el) {
                var $el = $(el),
                    risk = $el.attr('data-risk'),
                    group = $el.attr('data-group');

                console.log(risk);
                if ($.inArray(risk, availableRisks) === -1) {
                    availableRisks.push(risk);
                }
                if ($.inArray(group, avaialableFundGroups) === -1) {
                    avaialableFundGroups.push(group);
                }
            });

            $riskFilter.find('option').each(function (i, el) {
                console.log(availableRisks, el.value, $.inArray(el.value, availableRisks));
                if ($.inArray(el.value, availableRisks) > -1 || el.value === '') {
                    delete el.disabled;
                } else {
                    el.disabled = 'disabled';
                }
            });

            $fundGroupFilter.find('option').each(function (i, el) {
                if ($.inArray(el.value, avaialableFundGroups) > -1) {
                    delete el.disabled;
                } else {
                    el.disabled = 'disabled';
                }
            });

        }

        function setResultCount($dataTable) {
            var $fundSelection = $dataTable.parents('.fundSelection'),
                $filterResult = $fundSelection.find('.filterResult > div');

            resultCount = $dataTable.find('tbody tr:not(.hidden)').length;
            $filterResult.find('.resultCount').text(resultCount + ' ' + (resultCount === 1 ? 'Ergebnis' : 'Ergebnisse'));

            if (resultCount === 0) {
                $dataTable.addClass('hidden');
            } else {
                $dataTable.removeClass('hidden');
            }

            if (resultCount === $dataTable.find('tbody tr').length) {
                $filterResult.addClass('hidden');
            } else {
                $filterResult.removeClass('hidden');
            }
        }

        function initDataTables() {
            var $fundSelection = $('.fundSelection'),
                $dataTable = $fundSelection.find('.dataTable'),
                dataTable,
                $selectedFilters = $fundSelection.find('.selectedFilters');

            $dataTable.DataTable({
                searching: false,
                paging: false,
                info: false
            });

            setResultCount($dataTable);

            // filter handling events
            $fundSelection
                .on('submit', 'form.filterForm', function (e) {
                    e.preventDefault();
                    e.stopImmediatePropagation();
                })
                .on('keyup change', '.filterForm .searchFilter', function (e) {
                    if (this.value.length > 2) {
                        term = this.value;
                    } else {
                        term = '';
                    }

                    $selectedFilters.find('a.termFilter').parent().remove();

                    if ($.trim(term).length) {
                        $selectedFilters.append('<li><a href="#" class="termFilter">' + term + '</a></li>');
                    }

                    filterTable($dataTable);
                })
                .on('change', '.filterForm .riskFilter', function (e) {
                    risk = this.value;

                    $selectedFilters.find('a.riskFilter').parent().remove();

                    if (risk) {
                        $selectedFilters.append('<li><a href="#" class="riskFilter">Risikoklasse: ' + risk + '</a></li>');
                    }

                    filterTable($dataTable);
                })
                .on('change', '.filterForm .fundGroupFilter', function (e) {
                    var foundGroupName = $(this).find('option[value="' + this.value + '"]').text();
                    fundGroup = this.value;

                    $selectedFilters.find('a.fundGroupFilter').parent().remove();

                    if (fundGroup) {
                        $selectedFilters.append('<li><a href="#" class="fundGroupFilter">Fonsgruppe: ' + foundGroupName + '</a></li>');
                    }

                    filterTable($dataTable);
                })
                .on('change', '.filterForm .strategyFilter', function (e) {
                    var strategyName = $(this).find('option[value="' + this.value + '"]').text();
                    strategy = this.value;

                    $selectedFilters.find('a.strategyFilter').parent().remove();

                    if (strategy) {
                        $selectedFilters.append('<li><a href="#" class="strategyFilter">Anlagestrategie: ' + strategyName + '</a></li>');
                    }

                    filterTable($dataTable);
                })

                .on(
                    'click',
                    '.selectedFilters .termFilter',
                    function (e) {
                        e.preventDefault();
                        term = '';
                        $('.filterForm .searchFilter').val('');
                        filterTable($dataTable);
                        $(this).parent().remove();
                    }
                ).on(
                'click',
                '.selectedFilters .riskFilter',
                function (e) {
                    e.preventDefault();
                    risk = '';
                    $('.filterForm .riskFilter').val('');
                    filterTable($dataTable);
                    $(this).parent().remove();
                }
            ).on(
                'click',
                '.selectedFilters .fundGroupFilter',
                function (e) {
                    e.preventDefault();
                    fundGroup = '';
                    $('.filterForm .fundGroupFilter').val('');
                    filterTable($dataTable);
                    $(this).parent().remove();
                }
            ).on(
                'click',
                '.selectedFilters .strategyFilter',
                function (e) {
                    e.preventDefault();
                    strategy = '';
                    $('.filterForm .strategyFilter').val('');
                    filterTable($dataTable);
                    $(this).parent().remove();
                }
            );
        }

        function initDetailHandling() {
            var $fundSelection = $('.fundSelection'),
                $overlay = $fundSelection.find('section.fundSelectionOverlay');

            $fundSelection
                .on('click', '.showFundDetails', function (e) {
                    var $this = $(this),
                        fundUid = parseInt($this.attr('data-uid'), 10),
                        $row = $this.parents('tr'),
                        fundName = $row.attr('data-name'),
                        fundColor = $row.attr('data-color');

                    e.preventDefault();

                    $overlay
                        .attr('class', 'fundSelectionOverlay loading ' + fundColor)
                        .find('.name').html(fundName);
                    $('body').addClass('fundSelectionOpen');

                    $.jsonRPC.request('sl_fund_selection.FundService.detail', {
                        params: {
                            fundUid: fundUid
                        },
                        success: function (data) {
                            $overlay.removeClass('loading');
                            if (data.result.success) {
                                $overlay
                                    .addClass(data.result.color)
                                    .find('.content').html(data.result.html);
                            }
                        }
                    });
                })
                .on('click', '.fundSelectionOverlay .overlayClose', function (e) {
                    var $fundSelection = $('.fundSelection'),
                        $overlay = $fundSelection.find('section.fundSelectionOverlay');

                    e.preventDefault();

                    $('body').removeClass('fundSelectionOpen');
                    $overlay
                        .find('.content').html('').end()
                        .find('.name').html('');
                });
        }


        return {
            init: function () {
                initDataTables();
                initDetailHandling();
            }
        }
    }
);