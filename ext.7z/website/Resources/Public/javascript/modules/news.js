define(
    ['jquery', 'vendor/jquery/masonry.pkgd.min'],
    function ($, Masonry) {

        var msnry,
            activeTags = [],
            activeCategory = null,
            activeOrder = 'ASC';

        function newsDialogHandling() {
            var $newsBlock = $('.newsBlock');
            if ($newsBlock.length > 0) {
                $newsBlock.each(function(i, el) {
                    msnry = new Masonry(el, {
                        // options
                        itemSelector: 'article, h3',
                        columnWidth: '.newsBlock > article',
                        gutter: '.gutter-sizer',
                        percentPosition: true
                    });

                    window.setTimeout(function () {
                        msnry.layout();
                    }, 25);
                });

                $('.newsFilterWrap').on('click', 'a.hasSubMenu', function(e) {
                    var $this = $(this);

                    e.preventDefault();

                    if( $this.hasClass('open')){
                        $this.removeClass('open')
                    }
                    else{
                        $('.newsFilterWrap .dropDown > li > a').removeClass('open');
                        $this.addClass('open')
                    }
                });



                $('body')
                    .on('click', '.newsFilterPoints a', function(e) {
                        var $this = $(this),
                            uid = parseInt($this.attr('data-uid'), 10);

                        e.preventDefault();

                        if ($this.hasClass('active')) {
                            activeTags = $.grep(activeTags,  function(value) {
                                return value !== uid;
                            });

                            $this.removeClass('active');
                        } else {
                            activeTags.push(uid);
                            $this.addClass('active');
                        }

                        listNews();
                    })
                    .on('click', '.newsFilter a', function(e) {
                        var $this = $(this),
                            $newsFilter = $this.parents('.newsFilter'),
                            $newsFilterLinks = $newsFilter.find('a'),
                            uid = parseInt($this.attr('data-uid'), 10);

                        e.preventDefault();

                        // click on subcategory in dropdown should close the dropdown
                        if ($this.parents('.subCategories').length) {
                            $this.parents('.dropDown').find('.open').removeClass('open');
                        }

                        $newsFilterLinks.removeClass('active');
                        if (isNaN(uid)) {
                            $newsFilter.find('a.showAll').addClass('active');
                            activeCategory = null;
                        } else {
                            $this.addClass('active');
                            activeCategory = uid;
                        }

                        listNews();
                    });



            }
        }

        function listNews() {
            var $newsBlock = $('.newsBlock'),
                $newsFilterTagsWrapper = $('.newsFilterPoints'),
                gutterSizerHtml = '<div class="gutter-sizer">&nbsp;</div>';

            $newsBlock.addClass('loading').html('');

            $.jsonRPC.request('sl_news.NewsService.list', {
                params: {
                    contentUid: parseInt($('.newsOverview').attr('data-uid'), 10),
                    category: activeCategory,
                    tags: activeTags/*,
                    orderBy: activeOrderBy,
                    orderDirection: activeOrderDirection*/
                },
                success: function (data) {
                    console.log(data.result);

                    $newsBlock.removeClass('loading');
                    if (data.result.success) {
                        $newsBlock.html(gutterSizerHtml + data.result.news.join(''));


                        $newsFilterTagsWrapper.find('a').addClass('disabled');
                        $.each(data.result.availableTags, function(i, tagUid) {
                            console.log(i, tagUid);
                            $newsFilterTagsWrapper.find('a[data-uid="' + tagUid + '"]').removeClass('disabled');
                        });


                        msnry.reloadItems();
                        window.setTimeout(function () {
                            msnry.layout();
                        }, 25);
                    } else {
                        $newsBlock.html(gutterSizerHtml);
                        $newsFilterTagsWrapper.find('a').addClass('disabled');

                        msnry.reloadItems();
                        window.setTimeout(function () {
                            msnry.layout();
                        }, 25);
                    }
                }
            });
        }

        return {
            init: function () {
                newsDialogHandling();
            }
        }
    }
);