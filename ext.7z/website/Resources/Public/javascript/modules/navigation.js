define(
    ['jquery'],
    function ($) {

        var $body,
            navAnimationEnd,
            navAnimationEndTimer,
            mainNavInDelayTimer,
            mainNavOutDelayTimer;

        function hideMainNavLayer($target) {
            if (
                ($target.prop('tagName').toLowerCase() === 'a' && $target.parents('#mainNav').length)
                || ($target.parents('.subNav').length) || $target.hasClass('subNav')
            ) {
                return;
            }

            $('#mainNavCloseControl').prop('checked', true);
        }

        function mainNavigationHandling() {
            //Main Nav
            $('#mainNav > ul > li > label')
                .on('mouseenter', function() {
                    var $this = $(this);

                    if (window.mainNavInDelayTimer) {
                        window.clearTimeout(window.mainNavInDelayTimer);
                    }

                    if ($('#mainNavCloseControl').prop('checked')) {
                        window.mainNavInDelayTimer = window.setTimeout(function() {
                            $this.trigger('click');
                        }, 300);
                    } else {
                        $this.trigger('click');
                    }
                })
                .on('mouseleave', function(e) {
                    var $this = $(this);

                    e.stopImmediatePropagation();

                    if (window.mainNavInDelayTimer) {
                        window.clearTimeout(window.mainNavInDelayTimer);
                    }
                });

            $('body').on('mouseover', function(e) {
                var $target = $(e.target);

                if (mainNavOutDelayTimer) {
                    window.clearTimeout(mainNavOutDelayTimer);
                }

                mainNavOutDelayTimer = window.setTimeout(function () {
                    hideMainNavLayer($target);
                }, 500);
            });

            $('#mainNav > ul > li > label').on('click', function(e){
                e.stopImmediatePropagation();
            });

            //Subnav
            $('.subNav > section > article > nav > ul li').on('mouseover', function(e) {
                var $this = $(this);


                e.stopImmediatePropagation();
                $this.siblings().removeClass('open').find('li').removeClass('open');

                $this.find('li').removeClass('open');

                $(this).addClass('open');
                navAnimationEnd = false;

                if (navAnimationEndTimer) {
                    window.clearTimeout(navAnimationEndTimer);
                }

                navAnimationEndTimer = window.setTimeout(function() {
                    navAnimationEnd = true;
                }, 800);
            });

            $('.subNav > section > article > nav > ul li').on('mouseleave', function(e) {
                var $this = $(this);
                e.stopImmediatePropagation();

                if (navAnimationEnd) {
                    $this.removeClass('open');
                    $this.find('li').removeClass('open');
                }
            });


            //Sub Nav höhe berechnen
            $('.subNav').each(function(){
                var obj = $(this).find('ul');
                var itemHeight = 0;
                $.each( obj, function( key, value ) {
                    if( value.clientHeight > itemHeight ) {
                        itemHeight = value.clientHeight;
                    }
                });

                $(this).children('section').children('article:last-of-type').children('nav').children('ul').outerHeight(itemHeight);
            });
        }

        /*function footerNavigationHandling() {
            //FuncNav
            $('#func > ul > li > a').on('click', function(e){
                e.preventDefault();

                if( $(this).parent().hasClass('active')){
                    $(this).parent().removeClass('active')
                } else{
                    $('#func > ul > li').removeClass('active');
                    $(this).parent().addClass('active')
                }
            });
        }
        */
        function functionalNavigationHandling() {
            $('#func > ul > li > a').on('click', function (e) {
                var $this = $(this),
                    $parent = $this.parent(),
                    element = $this.attr('data-func-control');

                e.preventDefault();

                if ($parent.hasClass('active')) {
                    $parent.removeClass('active')
                } else {
                    $('#func > ul > li').removeClass('active');
                    $parent.addClass('active')
                }

                $body.addClass(element + 'Open');
            });

            $('.overlayClose').on('click', function (e) {
                var element = $(this).attr('data-func-close');

                e.preventDefault();

                $body.removeClass(element + 'Open');
                $('#func > ul > li').removeClass('active');
            });

            $('body').on('keypress', function(e) {
                var $this = $(this);
                if (!($this.hasClass('loginOpen') || $this.hasClass('searchOpen') || $this.hasClass('contactOpen'))) {
                    return;
                }
                if (e.keyCode === 27) {
                    $body.removeClass('loginOpen searchOpen contactOpen');
                    $('#func > ul > li').removeClass('active');
                }
            })
        }


        function mobileNavigationHandling() {
            $('.mobileNavToggler').on('click', function (e) {
                e.preventDefault();

                $('body').toggleClass('mainNavOpen');
            });
        }

        return {
            init: function () {
                $body = $('body');

                mainNavigationHandling();
                functionalNavigationHandling();
                mobileNavigationHandling();
                //footerNavigationHandling();
            }
        }
    }
);