define(
    ['jquery', 'js-cookie'],
    function ($, Cookies) {

        /*function trackPdfDownloads() {
            if (window.ga) {
                $('body').on('click', 'a[href$=".pdf"]', function (e) {
                    var href = $(this).attr('href'),
                        urlParts = href.split('/');

                    ga('send', {
                        hitType: 'event',
                        eventCategory: 'Downloads ' + (urlParts ? urlParts[urlParts.length - 2] : ''),
                        eventAction: 'click',
                        eventLabel: urlParts ? urlParts[urlParts.length - 1] : ''
                    });
                });
            }
        }*/

        function gaOptout() {
            if (window.ga) {
                var disableStr = 'ga-disable-' + window.gaProperty;
                if (document.cookie.indexOf(disableStr + '=true') > -1) {
                    window[disableStr] = true;
                }

                $('body').on('click', 'a.gaOptout', function(e) {
                    document.cookie = disableStr + '=true; expires=Thu, 31 Dec 2099 23:59:59 UTC; path=/';
                    window[disableStr] = true;
                });
            }
        }


        function cookieHintHandling() {
            var cookieName = 'sl_cookie_hint';

            if (!Cookies.get(cookieName)) {
                $('body').addClass('cookieInfoActive');
            }

            $('body').on('click', '.closeCookieInfo', function(e) {
                e.preventDefault();
                Cookies.set(cookieName, true);
                $('body').removeClass('cookieInfoActive');
            });
        }

        return {
            init: function () {
                //trackPdfDownloads();
                gaOptout();
                cookieHintHandling();
            }
        }
    }
);