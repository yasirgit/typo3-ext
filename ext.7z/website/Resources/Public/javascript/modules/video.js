define(
    ['jquery'],
    function ($) {

        function videoPlayerHandling() {
            $('body').on('click', '.videoWrapper > .videoPlay', function (e) {
                var $this = $(this),
                    $parent = $this.parent(),
                    source = $parent.attr('data-source');

                e.preventDefault();

                source += (source.indexOf('?') > -1 ? '&' : '?') + 'autoplay=1';

                $parent.addClass('active');
                $('<iframe frameborder="0" src="' + source + '" allowfullscreen></iframe>').insertAfter($this);
                $this.remove();
            });
        }

        return {
            init: function () {
                videoPlayerHandling();
            }
        }
    }
);