define(
    ['jquery', 'vendor/slick.min'],
    function ($) {

        function mainSliderHandling() {
            $('.mainSlider').each(function(){
                if($(this).children().length > 1){
                    $(this).slick({
                        autoplay:true,
                        autoplaySpeed:5000,
                        dots:true,
                        arrows: false,
                        fade:true,
                        infinite: true,
                        speed: 1000
                    });
                }else{
                    $(this).slick({
                        autoplay:false,
                        autoplaySpeed:5000,
                        dots:false,
                        arrows: false,
                        fade:true,
                        infinite: true,
                        speed: 1000
                    });

                }
            });
        }

        return {
            init: function () {
                mainSliderHandling();
            }
        }
    }
);