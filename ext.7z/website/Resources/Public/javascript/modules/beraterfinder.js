define(
    ['jquery', 'google-maps', 'google-maps-markerclusterer'],
    function ($) {
        var geocoder,
            map,
            $window = $(window),
            $htmlBody = $('html, body'),
            locations = [],
            infowindow = new google.maps.InfoWindow(),
            //svg icon
            icon = {
                path: "M32,1C20.69,1,9,9.64,9,24.09,9,39.24,30.38,60.8,31.29,61.71a1,1,0,0,0,1.41,0C33.62,60.8,55,39.24,55,24.09,55,9.64,43.31,1,32,1Zm0,31a8,8,0,1,1,8-8A8,8,0,0,1,32,32Z",
                fillColor: '#007BC3',
                fillOpacity: 1,
                anchor: new google.maps.Point(0, 80),
                strokeWeight: 1,
                strokeColor: '#ffffff',
                scale: 0.6
            },
            markers = [], //marker array for <a> click
            labels = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';  // Create an array of alphabetical characters used to label the markers.

        locations = [];

        // Sets the map on all markers in the array.
        function setMapOnAll(map) {
            for (var i = 0; i < markers.length; i++) {
                markers[i].setMap(map);
            }
        }

        // Removes the markers from the map, but keeps them in the array.
        function clearMarkers() {
            setMapOnAll(null);
        }

        // Shows any markers currently in the array.
        function showMarkers() {
            setMapOnAll(map);
        }

        // Deletes all markers in the array by removing references to them.
        function deleteMarkers() {
            clearMarkers();
            markers = [];
        }


        function placeMarker(loc, i) {
            console.log('place marker', i, loc);
            var latLng = new google.maps.LatLng(loc[1], loc[2]);
            var marker = new google.maps.Marker({
                position: latLng,
                map: map,
                icon: icon,
                //title: loc[0],
                label: labels[i % labels.length]
            });


            markers.push(marker); //add to marker array for <a> click
            console.log(markers);
            google.maps.event.addListener(marker, 'click', function () {
                infowindow.close(); // close previously opened infowindow
                infowindow.setContent('<div class="infoWindow"><p>' + loc[0] + '</p><p>' + loc[3] + '</p></div>');
                infowindow.open(map, marker);
            });
        }


        function initGoogleMap() {

            var bounds = new google.maps.LatLngBounds(
                new google.maps.LatLng(50.1210209, 8.6858255),
                new google.maps.LatLng(50.1014124, 8.7558661),
                new google.maps.LatLng(50.1325472, 8.744848),
                new google.maps.LatLng(50.1127505, 8.6623345),
                new google.maps.LatLng(50.0972382, 8.6664838),
                new google.maps.LatLng(50.0972382, 8.6664838)
            );

            var center = bounds.getCenter();
            var mapOptions = {
                //zoom: zoomLevel,
                scrollwheel: false,
                center: center,
                mapTypeId: google.maps.MapTypeId.ROADMAP,
                mapTypeControl: false,
                scaleControl: false,
                zoomControl: false,
                streetViewControl: false,
                fullScreenControl: false
            };

            map = new google.maps.Map(document.getElementById('googleMap'), mapOptions);


            // set markers
            for (var i = 0; i < locations.length; i++) {
                placeMarker(locations[i], i);
            }

            var markerCluster = new MarkerClusterer(map, markers,
                {imagePath: 'https://developers.google.com/maps/documentation/javascript/examples/markerclusterer/m'});

            //close infoWindow and allow Scrolling
            google.maps.event.addListener(map, 'click', function (event) {
                this.setOptions({scrollwheel: true});
                infowindow.close(); // close previously opened infowindow
            });

            //center to location (from <a>}
            function newLocation(id) {
                var location = locations[id];
                map.setCenter({
                    lat: location[1],
                    lng: location[2]
                });

                return false;
            }

            //activate marker on <a> click
            $('#googleMap').on('click', '.location', function (e) {
                e.preventDefault();

                $htmlBody.animate({ //scroll to map
                    scrollTop: $('#googleMap').offset().top - 150
                }, 1000);

                newLocation($(this).attr('data-location')); //center map
                google.maps.event.trigger(markers[$(this).attr('data-location')], 'click'); //open marker
            });

            map.fitBounds(bounds);

        }

        function setLocations(newLocations) {
            locations = newLocations;

            deleteMarkers();

            // set markers
            for (var i = 0; i < locations.length; i++) {
                placeMarker(locations[i], i);
            }
        }

        function initSearchHandling() {
            var $form =  $('form.beraterfinderSearchForm'),
                $searchTerm = $form.find('.searchTerm');

            $('body').on('submit', 'form.beraterfinderSearchForm', function (e) {
                e.preventDefault();
                e.stopImmediatePropagation();
                var $form = $(this),
                    searchTerm = $form.find('.searchTerm').val(),
                    $resultList = $('.beraterfinderResultList'),
                    $noResultHint = $('.beraterFinderNoResultHint'),
                    $resultHint = $('.beraterFinderResultHint');

                $noResultHint.addClass('hidden');
                $resultHint.addClass('hidden');

                $.jsonRPC.request('sl_beraterfinder.BeraterfinderService.list', {
                    params: {
                        searchTerm: searchTerm
                    },
                    success: function (data) {
                        if (data.result.success) {
                            setLocations(data.result.locations);

                            map.setCenter({
                                lat: data.result.location.latitude,
                                lng: data.result.location.longitude
                            });

                            $resultList.html(data.result.html);

                            if (data.result.locations.length) {
                                $resultHint
                                    .find('.beraterFinderResultCount')
                                        .text(data.result.locations.length)
                                        .end()
                                    .removeClass('hidden');
                            } else {
                                $noResultHint.removeClass('hidden');
                            }
                        }
                    }
                })
            });

            if ($searchTerm.val() !== '') {
                $form.trigger('submit');
            }
        }

        function initBeraterHandling() {
            $('body')
                .on('click', 'a.showOnMap', function (e) {
                    var locationCount = parseInt($(this).attr('data-location-count'), 10);

                    e.preventDefault();

                    map.setCenter({
                        lat: locations[locationCount][1],
                        lng: locations[locationCount][2]
                    });
                    new google.maps.event.trigger(markers[locationCount], 'click');

                    $('body').animate({scrollTop: 0}, 300);
                });
        }

        return {
            init: function () {
                if (document.getElementById('googleMap')) {
                    initGoogleMap();

                    initSearchHandling();
                    initBeraterHandling();
                }
            }
        }
    }
);