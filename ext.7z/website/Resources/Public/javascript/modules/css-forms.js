// @todo: textarea.autogrow, datepicker, placeholder polyfill


define(
    ['jquery', 'modules/css-forms/validation', 'modules/css-forms/styles', 'modules/css-forms/datepicker'],
    function($, Validation, Styles) {
        var pluginName = 'cssForms',
            defaults = {
                addRequiredIndicator: true,
                selectors: {
                    validateTrigger: '.cssfRequired > input, .cssfRequired > textarea, .cssfRequired > select, .cssfRequired > [contenteditable="true"]'
                },
                useErrorText: true,
                defaultErrorText: 'Please fill in or correct the field above.',
                Classes : {
                    cssForm: 'cssForm',
                    required: 'cssfRequired',
                    valid: 'cssfValid',
                    invalid: 'cssfError',
                    selectorGroup: 'selectorGroup',
                    filled: 'cssfFilled'
                },
                Const : {
                    VALID: true,
                    INVALID: false
                }
            };


        function Plugin(element, options) {
            this.element = element;
            this.$element = $(element);

            this.options = $.extend({}, defaults, options);

            this.init();
        }

        Plugin.prototype.init = function () {
            this.$element.addClass(this.options.Classes.cssForm);
            Validation.init(defaults, this.$element);
            Styles.init(defaults, this.$element);


/*          this.Placeholder.init(this);
            //this.DatePicker.init(this);
            this.FileStyle.init(this);
            this.Foldable.init(this);
            this.Autogrow.init(this);*/
        };



        // register as jQuery plugin
        $.fn[pluginName] = function (options) {
            this.each(function () {
                if (!$.data(this, 'plugin_' + pluginName)) {
                    $.data(this, 'plugin_' + pluginName, new Plugin(this, options));
                }
            });

            if (this.first().length > 0) {
                return this.first().data('plugin_' + pluginName);
            } else {
                return new Plugin(this, options);
            }
        };

        // automatically initialize the plugin on elements with class .cssForm
        $('.cssForm:not([data-init="custom"])').each(function (i, el) {
            $(el)[pluginName]();
        });


        return {
            init: function(defaultConfig) {
                defaultConfig = defaultConfig || {};

                defaults = $.extend({}, defaults, defaultConfig);
            }
        };
    }
);