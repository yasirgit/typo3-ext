define(
    ['jquery', 'vendor/queue', 'modules/animations'],
    function ($, queue, animations) {
        var $html = $('html'),
            $body = $('body'),
            $window = $(window),
            inViewAnimatesSelector = '.grid article:not(.inView), .flexContent > *:not(.inView), .inViewAnimate:not(.inView), #intro:not(.inView), .mainContent > header:not(.inView), #footerButtons > a:not(.inView)',
            $inViewAnimates = $(inViewAnimatesSelector);

        window.inViewAnimateQueue = new Queue();
        window.inViewAnimateQueueRunning = false;

        function animateQueueHandling() {
            if (window.inViewAnimateQueueRunning) {
                return;
            }

            window.inViewAnimateQueueRunning = true;
            animateQueueHandlingProcess();

        }

        function animateQueueHandlingProcess() {

            if (window.inViewAnimateQueue.isEmpty()) {
                window.inViewAnimateQueueRunning = false;
                return;
            }

            window.setTimeout(function () {
                dequeueAnimate();
                animateQueueHandlingProcess();
            }, 300);
        }

        function dequeueAnimate() {
            var $element = window.inViewAnimateQueue.dequeue();
            if (!$element) {
                animations.reveal();
                return;
            }
            $element.addClass('inView');

            setTimeout(function(){
                $element.addClass('inViewComplete');

                $element.find('svg .trigger').on('webkitAnimationEnd oanimationend msAnimationEnd animationend', function(e) {
                    $(this).closest('svg').addClass('reset');
                });

                $element.find('svg').on('mouseover', function(e){
                    $(this).removeClass('reset');
                });
            }, 700);


            animations.reveal();
            // if element has been marked as visible but is no longer visible -> go to next one
            if (!$element.visible(true, 1)) {
                dequeueAnimate();
            }
        }

        function scrollEvents() {
            $inViewAnimates.each(function (i, el) {
                var $el = $(el);

                if ($el.visible(true, 0.9) && !$el.hasClass('inView') && !$el.hasClass('queued')) {
                    $el.addClass('queued');
                    window.inViewAnimateQueue.enqueue($el);
                }
            });

            animateQueueHandling();
        }


        return {
            init: function () {
                $window.on('scroll resize', function () {
                    scrollEvents();
                });


                $('#detail').on('scroll resize', function() {
                    scrollEvents();
                });

                scrollEvents();
            },
            updateQueue: function() {
                $inViewAnimates = $(inViewAnimatesSelector);
                scrollEvents();
                window.setTimeout(scrollEvents, 250);
            }
        }

    }
);