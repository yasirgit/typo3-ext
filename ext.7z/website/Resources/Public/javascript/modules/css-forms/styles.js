define(
    ['jquery'],
    function($) {
        var config = {
            controls: 'input:not([type=radio]):not([type=checkbox]):not([type=hidden]):not([type=file]), .inputStyle, textarea, select',

            Classes: {
                placeholderClass: 'placeholder',
                filled: 'cssfFilled',
                fileUpload: 'cssfFileUpload'
            }
        };

        /**
         * reposition elements for better UX
         * @param $form
         */
        function repositionElements($form) {
            $form.find('fieldset:not(.rows):not(.cols) label:not(.ignoreCssForms)')
                .has(config.controls)
                .has('.lbl')
                .children(config.controls)
                .addClass('readyForMoving')
                .prev('.lbl').each(function (i, el) {
                var $el = $(el),
                    $control = $el.next();

                $el
                    .addClass('moving')
                    .detach()
                    .insertAfter($control);
            });

            $form.find('select')
                .closest('label')
                .addClass('styledSelect');

            $form.find('fieldset[data-errortext]').each(function(i, el) {
                var $el = $(el),
                    errorText = $el.attr('data-errortext');

                $el.attr('data-errortext', '')
                    .children('legend')
                    .attr('data-errortext', errorText);
            });

            $form.find('[required]')
                .closest('label')
                .addClass(config.Classes.required);

            $form.find('[disabled]')
                .closest('label')
                .addClass('disabled');

            $form.find('input[type=checkbox], input[type=radio]').each(function (i, el) {
                var $el = $(el),
                    errorText = $el.closest('label').attr('data-errortext');

                $(el)
                    .after('<span class="styled">')
                    .closest('label')
                    .attr('data-errortext', '')
                    .addClass('styledSelector')
                    .children('.lbl')
                    .attr('data-errortext', errorText);
            });

            $form.on('focus', this.controls, function () {
                $(this).addClass('seen');  // browsernative validierung wird erst nach "sehen" eines controls angezeigt
            });
        }

        /**
         * Add required indicators
         * @param $form
         */
        function setRequiredIndicators($form) {
            var $requiredElements = $form.find('.' + config.Classes.required),
                mand = '<span class="mand">*</span>';

            $requiredElements.each(function (i, el) {
                var $el = $(el),
                    $placeholderElement = $el.find('[placeholder]');

                if ($el.find('span.mand').length > 0) {
                    return;
                }

                $el.find('.lbl').append(mand);

                if (!$placeholderElement.parents('fieldset.rows, fieldset.cols').length) {
                    $placeholderElement.attr('placeholder', $placeholderElement.attr('placeholder') + '*');
                }
            });
        }

        /**
         * Add date picker
         * @param $form
         */
        function addDatePicker($form) {
            var $dateFields = $form.find('[type="date"]');

            $dateFields.each(function($el){
                $(this).after(
                    '<!-- //DATEcssfPicker -->' +
                    '<div class="cssfPicker">' +
                    '<table>' +
                    '<thead>' +
                    '<tr>' +
                    '<th class="prevMonth"><a href="#" title="Show January 2015"><span>Previous</span></a></th>' +
                    '<th colspan="5">Februar 2015</th>' +
                    '<th class="nextMonth"><a href="#" title="Show March 2015"><span>Next</span></a></th>' +
                    '</tr>' +
                    '</thead>' +
                    '<tbody>' +
                    '<tr>' +
                    '<th><span>Mo</span></th>' +
                    '<th><span>Di</span></th>' +
                    '<th><span>Mi</span></th>' +
                    '<th><span>Do</span></th>' +
                    '<th><span>Fr</span></th>' +
                    '<th><span>Sa</span></th>' +
                    '<th><span>So</span></th>' +
                    '</tr>' +
                    '</tbody>' +
                    '<tr>' +
                    '<td class="cssfPickerOldMonth"><span>26</span></td>' +
                    '<td class="cssfPickerOldMonth"><span>27</span></td>' +
                    '<td class="cssfPickerOldMonth"><a href="#" target="_self" title="Select this date">28</a></td>' +
                    '<td class="cssfPickerOldMonth"><a href="#" target="_self" title="Select this date">29</a></td>' +
                    '<td class="cssfPickerOldMonth"><a href="#" target="_self" title="Select this date">30</a></td>' +
                    '<td class="cssfPickerOldMonth"><a href="#" target="_self" title="Select this date">31</a></td>' +
                    '<td><a href="#" target="_self" title="Select this date">1</a></td>' +
                    '</tr>' +
                    '<tr>' +
                    '<td><a href="#" target="_self" title="Select this date">2</a></td>' +
                    '<td class="cssfPickerToday" ><a href="#" target="_self" title="Select this date">3</a></td>' +
                    '<td><a href="#" target="_self" title="Select this date">4</a></td>' +
                    '<td class="cssfPickerSelected" ><a href="#" target="_self" title="Select this date">5</a></td>' +
                    '<td><a href="#" target="_self" title="Select this date">6</a></td>' +
                    '<td><a href="#" target="_self" title="Select this date">7</a></td>' +
                    '<td><a href="#" target="_self" title="Select this date">8</a></td>' +
                    '</tr>' +
                    '<tr>' +
                    '<td><a href="#" target="_self" title="Select this date">9</a></td>' +
                    '<td ><a href="#" target="_self" title="Select this date">10</a></td>' +
                    '<td><a href="#" target="_self" title="Select this date">11</a></td>' +
                    '<td><span>12</span></td>' +
                    '<td><span>13</span></td>' +
                    '<td><span>14</span></td>' +
                    '<td><span>15</span></td>' +
                    '</tr>' +
                    '<tr>' +
                    '<td><span>16</span></td>' +
                    '<td><span>17</span></td>' +
                    '<td><span>18</span></td>' +
                    '<td><span>19</span></td>' +
                    '<td><span>20</span></td>' +
                    '<td><span>21</span></td>' +
                    '<td><span>22</span></td>' +
                    '</tr>' +
                    '<tr>' +
                    '<td><span>23</span></td>' +
                    '<td><span>24</span></td>' +
                    '<td><span>25</span></td>' +
                    '<td><span>26</span></td>' +
                    '<td><span>27</span></td>' +
                    '<td><span>28</span></td>' +
                    '<td class="cssfPickerNewMonth"><span>1</span></td>' +
                    '</tr>' +
                    '</table>' +
                    '</div>'

                );
                //@todo: add datepicker

                //$el.find('.lbl').append(mand);

            });
        }


        /**
         * Add time picker
         * @param $form
         */
        function addTimePicker($form) {
            var $dateFields = $form.find('[type="time"]');

            $dateFields.each(function($el){
                $(this).after(
                    '<!-- //DATEcssfPicker -->' +

                    '<div class="cssfPicker time">' +
                    '<table>' +
                    '<!-- thead>' +
                    '<tr>' +
                    '<th colspan="3">25 Februar 2015</th>' + //Nur wenn es ein kombinierter Date/TimePicker ist
                    '</tr>' +
                    '</thead -->' +
                    '<tbody>' +
                    '<tr>' +
                    '<!--th colspan="3">Pick a time</th-->' +
                    '</tr>' +
                    '<tr>' +
                    '<th class="upTime"><a href="#" title="Increase Hour"><span>Up</span></a></th>' +
                    '<th class="upTime"><a href="#" title="Increase Minutes"><span>Up</span></a></th>' +
                    '<th class="upTime"><a href="#" title="Change between PM and AM"><span>Up</span></a></th>' +
                    '</tr>' +
                    '<tr>' +
                    '<td><span class="time">09</span></td>' +
                    '<td><span class="time">45</span></td>' +
                    '<td><span class="time">PM</span></td>' +
                    '</tr>' +
                    '<tr>' +
                    '<th class="downTime"><a href="#" title="Show January 2015"><span>Down</span></a></th>' +
                    '<th class="downTime"><a href="#" title="Show January 2015"><span>Down</span></a></th>' +
                    '<th class="downTime"><a href="#" title="Show January 2015"><span>Down</span></a></th>' +
                    '</tr>' +
                    '</tbody>' +
                    '</table>' +
                    '</div>' +
                    '<!-- /END OF cssfPicker -->'
                );
                //@todo: add datepicker

                //$el.find('.lbl').append(mand);

            });
        }


        /**
         * Add number controls picker
         * @param $form
         */
        function addNumberControls($form) {
            var $dateFields = $form.find('[type="number"]');

            $dateFields.each(function($el){
                var $this = $(this),
                    $label = $this.closest('label'),
                    min = $this.attr('min'),
                    max = $this.attr('max'),
                    step = parseInt($this.attr('step'), 10) || 1;

                if ($label.hasClass('styledNumber')) {
                    return;
                }

                if (typeof min != 'undefined') {
                    min = parseInt(min, 10);
                } else {
                    min = null;
                }
                if (typeof max != 'undefined') {
                    max = parseInt(max, 10);
                } else {
                    max = null;
                }

                $label.addClass('styledNumber');

                $this
                    .after(
                        $('<a href="#" class="styled cssfDecreaseValue"><span>down</span></a>').on('click', function(e){
                            var value = parseInt($this.val(), 10) || 0;
                            e.preventDefault();

                            if (min != null && value-step <= min) {
                                $this.val(min);
                                $label.find('.cssfIncreaseValue').removeClass('disabled');
                                $label.find('.cssfDecreaseValue').addClass('disabled');
                                return;
                            }


                            $label.find('.cssfDecreaseValue, .cssfIncreaseValue').removeClass('disabled');

                            $this.val(value - step);
                        })
                    )
                    .after(
                        $('<a href="#" class="styled cssfIncreaseValue"><span>up</span></a>').on('click', function(e){
                            var value = parseInt($this.val(), 10) || 0;
                            e.preventDefault();

                            if (max != null && value+step >= max) {
                                $this.val(max);
                                $label.find('.cssfDecreaseValue').removeClass('disabled');
                                $label.find('.cssfIncreaseValue').addClass('disabled');
                                return;
                            }


                            $label.find('.cssfDecreaseValue, .cssfIncreaseValue').removeClass('disabled');

                            $this.val(value + step);
                        })
                    )
                    .on('keydown', function(e) {
                        var keyCode = e.keyCode;

                        switch (keyCode) {
                            case 8: // backspace
                            case 37: // left
                            case 38: // up
                            case 39: // right
                            case 40: // down
                            case 46: // delete
                                break;
                            default:
                                // 0-9 && numpad 0-9
                                if ((keyCode >= 48 && keyCode <= 57) || (keyCode >= 96 && keyCode <= 105)) {
                                    break;
                                }

                                if (e.ctrlKey && (keyCode == 67 || keyCode == 88 || keyCode == 86)) {
                                    break;
                                }

                                e.preventDefault();
                                return;
                        }
                    })
                    .on('keyup', function(e) {
                        var keyCode = e.keyCode,
                            $this = $(this),
                            value = parseInt($this.val(), 10);


                        switch (keyCode) {
                            case 8: // backspace
                            case 37: // left
                            case 38: // up
                            case 39: // right
                            case 40: // down
                            case 46: // delete
                                break;
                            default:
                                // 0-9 && numpad 0-9
                                if ((keyCode >= 48 && keyCode <= 57) || (keyCode >= 96 && keyCode <= 105)) {
                                    break;
                                }

                                if (e.ctrlKey && (keyCode == 67 || keyCode == 88 || keyCode == 86)) {
                                    break;
                                }

                                e.preventDefault();
                                return;
                        }

                        if (min != null && value < min) {
                            $this.val(min);
                        }
                        if (max != null && value > max) {
                            $this.val(max);
                        }
                    });



                var value = $this.val();

                if (max != null && value >= max) {
                    $label.find('.cssfDecreaseValue').removeClass('disabled');
                    $label.find('.cssfIncreaseValue').addClass('disabled');
                    return;
                }
                if (min != null && value <= min) {
                    $label.find('.cssfIncreaseValue').removeClass('disabled');
                    $label.find('.cssfDecreaseValue').addClass('disabled');
                    return;
                }


                $label.find('.cssfDecreaseValue, .cssfIncreaseValue').removeClass('disabled');
            });
        }

        /**
         * Styling for pseudo-placeholders in selects
         * @param $form
         */
        function selectPlaceholderStyle($form) {
            // nicht nÃ¶tig, da das einfach das Gegenteil von "filled" ist
            /*
             var placeholderClass = config.Classes.placeholderClass;

             $form.find('select').each(function(i, el) {
             var $el = $(el),
             $label = $el.closest('label'),
             $placeholderOption = $el.find('option[value=""], option:not([value])').eq(0);

             if ($el.val() == '') {
             $el.addClass(placeholderClass);
             } else {
             $el.removeClass(placeholderClass);
             }

             $el.on('change', function(e) {
             if ($el.val() == '') {
             $el.addClass(placeholderClass);
             } else {
             $el.removeClass(placeholderClass);
             }
             });
             });
             */
        }

        function filledStyle($form) {
            $form.on('change', config.controls, function(e) {
                var $this = $(this);

                if($this.is('select')) {
                    $thisVal = $this.find('option:selected').attr('value');
                } else {
                    $thisVal = $this.val();
                }

                if ($thisVal) {
                    $this.addClass(config.Classes.filled);
                } else {
                    $this.removeClass(config.Classes.filled);
                }
            });

            $form.find(config.controls).each(function(i, el) {
                var $el = $(el);

                if($el.is('select')) {
                    $thisVal = $el.find('option:selected').attr('value');
                } else {
                    $thisVal = $el.val();
                }

                if ($thisVal) {
                    $el.addClass(config.Classes.filled);
                } else {
                    $el.removeClass(config.Classes.filled);
                }
            });
        }

        function fileUploadStyle($form) {
            //@todo: passt das noch?
            $form.find('input[type=file]').each(function(i, el) {
                var $el = $(el),
                    $label = $el.closest('label');

                $label.addClass(config.Classes.fileUpload);
            });

            $form.on('change', '.' + config.Classes.fileUpload + ' input[type=file]', function(e) {
                var $this = $(this),
                    $label = $this.closest('label'),
                    $spanLbl = $label.find('span.lbl'),
                    $spanLblCount = $spanLbl.find('.count');

                if (!$spanLblCount.length) {
                    $spanLbl.append('<span class="count" />');
                }

                $label.addClass(config.Classes.filled);
                $spanLblCount = $spanLbl.find('.count');

                if (this.files) {
                    if (this.files.length) {
                        if (this.files.length == 1) {
                            $spanLblCount.html(' (' + this.files.length + ' Datei ausgewählt)');
                        } else {
                            $spanLblCount.html(' (' + this.files.length + ' Dateien ausgewählt)');
                        }
                    } else {
                        $spanLblCount.html('');
                    }
                    return;
                }

                if (this.value) {
                    $spanLblCount.html('(One file selected)');
                } else {
                    $spanLblCount.html('');
                }
            });
        }

        function addAutoGrow($form) {
            $form.find('textarea.autoGrow').each(function(i, el) {

                $(el).on('keyup', function(e) {
                    if (this.clientHeight < this.scrollHeight)
                    {
                        this.style.height = this.scrollHeight + 'px';
                        if (this.clientHeight < this.scrollHeight) {
                            this.style.height = (this.scrollHeight * 2 - this.clientHeight) + 'px';
                        }
                    }
                });
            });
        }

        return {
            init: function(cfg, $form) {
                config = $.extend(true, config, cfg);

                repositionElements($form);

                if (config.addRequiredIndicator) {
                    setRequiredIndicators($form);
                }
                selectPlaceholderStyle($form);
                filledStyle($form);
                fileUploadStyle($form);
                //addDatePicker($form);
                //addTimePicker($form);
                addNumberControls($form);
                addAutoGrow($form);
            }
        };
    }
);