define(
    ['jquery'],
    function($) {
        var Regex = {
                email: /^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/,
                url: /\b(((\S+)?)(@|mailto\:|(news|(ht|f)tp(s?))\:\/\/)\S+)\b/i,
                number: /[0-9]+/
            },
            config = {},

            Events = {
                validate: function (e, returnValue) {
                    var $element = this;

                    returnValue = returnValue || {};

                    // assume that the form is valid
                    returnValue.isValid = true;

                    $element.find(
                        config.selectors.validateTrigger
                    ).trigger('_validate', [returnValue]);

                    if (!returnValue.isValid) {
                        // scroll to first invalid field
                        $element.find('.' + config.Classes.invalid).first().focus();
                    }

                    returnValue.preventSubmit = !returnValue.isValid;
                },
                email: function (e, returnValue) {
                    var isValid = Validator.email(e.target);

                    setErrorText($(e.target).parents('label').first());
                    setValidationReturnValue(returnValue, isValid);
                },
                url: function (e, returnValue) {
                    var isValid = Validator.url(e.target);

                    setErrorText($(e.target).parents('label').first());
                    setValidationReturnValue(returnValue, isValid);
                },
                text: function (e, returnValue) {
                    var isValid = Validator.text(e.target);

                    setErrorText($(e.target).parents('label').first());
                    setValidationReturnValue(returnValue, isValid);
                },
                tel: function (e, returnValue) {
                    var isValid = Validator.text(e.target);

                    setErrorText($(e.target).parents('label').first());
                    setValidationReturnValue(returnValue, isValid);
                },
                number: function (e, returnValue) {
                    var isValid = Validator.number(e.target);

                    setErrorText($(e.target).parents('label').first());
                    setValidationReturnValue(returnValue, isValid);
                },
                numberKeyDown: function (e, returnValue) {
                    var keyCode = e.keyCode;

                    if (!( (keyCode == 8) || (keyCode == 46)
                            || (keyCode >= 48 && keyCode <= 57) || (keyCode >= 96 && keyCode <= 105)
                            || (keyCode >= 37 && keyCode <= 40)
                            || keyCode == 9 // tab
                            || keyCode == 173 || keyCode == 109 // minus
                        )) {
                        e.preventDefault();
                    }
                },
                file: function (e, returnValue) {
                    var isValid = Validator.file(e.target);

                    setErrorText($(e.target).parents('label').first());
                    setValidationReturnValue(returnValue, isValid);
                },
                select: function (e, returnValue) {
                    var isValid = Validator.select(e.target);

                    setErrorText($(e.target).parents('label').first());
                    setValidationReturnValue(returnValue, isValid);
                },
                checkbox: function (e, returnValue) {
                    var isValid = Validator.checkbox(e.target);

                    setErrorText($(e.target).parents('label').first());
                    setValidationReturnValue(returnValue, isValid);
                },
                radio: function (e, returnValue) {
                    var selectNeighbourInput = (e.type != '_validate'),
                        isValid = Validator.radio(e.target, selectNeighbourInput);

                    setErrorText($(e.target).parents('label').first());
                    setValidationReturnValue(returnValue, isValid);
                },
                contentEditable: function (e, returnValue) {
                    var isValid = Validator.contentEditable(e.target);

                    setErrorText($(e.target).parents('label').first());
                    setValidationReturnValue(returnValue, isValid);
                },
                submit: function (e) {
                    var $element = this,
                        returnValue = {
                            preventSubmit: false,
                            isValid: true
                        },
                        exp;

                    $element.trigger('beforeValidate.submit', [returnValue]);

                    if (returnValue.preventValidation !== true && $element.attr('data-preventsubmitvalidation') !== 'true') {
                        $element.trigger('validate', [returnValue]);
                    }
                    $element.trigger('afterValidate.submit', [returnValue]);

                    exp = (returnValue.preventSubmit !== true && returnValue.isValid);

                    if (!exp) {
                        e.preventDefault();
                    }

                    return exp;
                }
            },

            Validator = {
                email: function (element) {
                    var $this = $(element),
                        $parent = $this.parent(),
                        val = $this.val(),
                        pattern = $this.attr('pattern'),
                        modifier = $this.attr('data-modifier') || '',
                        regEx,
                        exp;

                    if (!$parent.hasClass(config.Classes.required) && val == '') {
                        return setStatus(true, $parent);
                    }

                    if ($.trim(val) == '') {
                        return setStatus(false, $parent);
                    }

                    if (pattern) {
                        regEx = new RegExp(pattern, modifier);
                        exp = regEx.test(val);
                    } else {
                        exp = Regex.email.test(val);
                    }

                    return setStatus(exp, $parent);
                },

                url: function (element) {
                    var $this = $(element),
                        $parent = $this.parent(),
                        val = $this.val(),
                        pattern = $this.attr('pattern'),
                        modifier = $this.attr('data-modifier') || '',
                        regEx,
                        exp;

                    if (pattern) {
                        regEx = new RegExp(pattern, modifier);
                        exp = regEx.test(val);
                    } else {
                        exp = Regex.url.test(val);
                    }

                    return setStatus(exp, $parent);
                },

                text: function (element) {
                    var $this = $(element),
                        $parent = $this.parent(),
                        val = $.trim($this.val()),
                        pattern = $this.attr('pattern'),
                        modifier = $this.attr('data-modifier') || '',
                        regEx,
                        exp = (val.length > 1);

                    if (pattern) {
                        regEx = new RegExp(pattern, modifier);
                        exp = regEx.test(val);
                    }

                    return setStatus(exp, $parent);
                },

                number: function (element) {
                    var $this = $(element),
                        $parent = $this.parent(),
                        val = $.trim($this.val()),
                        intVal = parseInt(val, 10),
                        min = parseInt($this.attr('min'), 10),
                        max = parseInt($this.attr('max'), 10),
                        expr = Regex.number.test(val);

                    if (min) {
                        expr = expr && !(intVal < min);
                    }

                    if (max) {
                        expr = expr && !(intVal > max);
                    }

                    return setStatus(expr, $parent);
                },

                file: function (element) {
                    var $this = $(element),
                        $parent = $this.parent(),
                        val = $.trim($this.val());

                    return setStatus(val.length > 1, $parent);
                },

                select: function (element) {
                    var $this = $(element),
                        $parent = $this.parent(),
                        val = $.trim($this.val());
                    return setStatus(val != '', $parent);
                },

                checkbox: function (element) {
                    var $this = $(element),
                        $parent = $this.parent();

                    return setStatus($this.prop('checked'), $parent);
                },

                radio: function (element, selectNeighbourInput) {
                    var $this = $(element),
                        $next = $this.next(),
                        $parent = $this.parent(),
                        $selectorGroup = $this.parents('.' + config.Classes.selectorGroup),
                        val = $.trim($this.val());

                    selectNeighbourInput = selectNeighbourInput || false;

                    if ($selectorGroup.length > 0) {
                        $parent = $selectorGroup;
                    }

                    if (selectNeighbourInput && $next.length > 0 && $next.prop('tagName').toLowerCase() == 'input') {
                        $next.focus();
                    }

                    return setStatus(val != '', $parent);
                },

                contentEditable: function (element) {
                    var $this = $(element),
                        $parent = $this.parent(),
                        val = $.trim($this.text());

                    return setStatus(val.length > 1, $parent);
                }
            };

        /**
         * bind default validation events
         * @param $form
         */
        function bindEvents($form) {
            var reqClass = config.Classes.required;

            // if novalidate has been set initially before plugin has been applied do not validate the fields
            if ($form.attr('novalidate')) {
                return;
            }

            // needed to prevent html5-browser-validations
            $form.attr('novalidate', 'novalidate');

            $form
                .on('validate', $.proxy(Events.validate, $form))
                .on(
                    '_validate change blur',
                    ':not(.customValidation, .selectorGroup) input[type="email"]',
                    $.proxy(Events.email, $form)
                )
                .on(
                    '_validate change blur',
                    '.' + reqClass + ':not(.customValidation, .selectorGroup) input[type="url"]',
                    $.proxy(Events.url, $form)
                )
                .on(
                    '_validate change blur',
                    '.' + reqClass + ':not(.customValidation, .selectorGroup) input[type="password"]',
                    $.proxy(Events.text, $form)
                )
                .on(
                    '_validate change blur',
                    '.' + reqClass + ':not(.customValidation, .selectorGroup) input[type="text"], .' + reqClass + ':not(.selectorGroup) textarea',
                    $.proxy(Events.text, $form)
                )
                .on(
                    '_validate change blur',
                    '.' + reqClass + ':not(.customValidation, .selectorGroup) input[type="tel"]',
                    $.proxy(Events.tel, $form)
                )
                .on(
                    '_validate change blur',
                    '.' + reqClass + ':not(.customValidation, .selectorGroup) input[type="number"]',
                    $.proxy(Events.number, $form)
                )
                .on(
                    'keydown',
                    '.' + reqClass + ':not(.customValidation, .selectorGroup) input[type="number"]',
                    $.proxy(Events.numberKeyDown, $form)
                )
                .on(
                    '_validate change blur',
                    '.' + reqClass + ':not(.customValidation, .selectorGroup) input[type="file"]',
                    $.proxy(Events.file, $form)
                )
                .on(
                    '_validate change blur',
                    '.' + reqClass + ':not(.customValidation, .selectorGroup) select',
                    $.proxy(Events.select, $form)
                )
                .on(
                    '_validate change blur click',
                    '.' + reqClass + ':not(.customValidation) input[type="checkbox"]',
                    $.proxy(Events.checkbox, $form)
                )
                .on(
                    '_validate change blur click',
                    '.' + reqClass + ':not(.customValidation) input[type="radio"]',
                    $.proxy(Events.radio, $form)
                )
                .on(
                    '_validate change blur',
                    '.' + reqClass + ':not(.customValidation) [contenteditable="true"]',
                    $.proxy(Events.contentEditable, $form)
                )
                .on('submit', $.proxy(Events.submit, $form));
        }

        /**
         *
         * @param validExpression
         * @param {boolean} $parent
         * @returns {boolean}
         */
        function setStatus(validExpression, $parent) {
            if ($parent.parent().hasClass(config.Classes.required)) {
                $parent = $parent.parent();
            }

            if (validExpression) {
                $parent.removeClass(config.Classes.invalid).addClass(config.Classes.valid);
                return config.Const.VALID;
            } else {
                $parent.removeClass(config.Classes.valid).addClass(config.Classes.invalid);
                return config.Const.INVALID;
            }
        }

        /**
         * Set default error text if none is set
         * @param $element
         */
        function setErrorText($element) {
            var errorText = $element.attr('data-errortext'),
                defaultErrorText = config.defaultErrorText;

            if (!config.useErrorText) {
                return;
            }

            if (!errorText) {
                $element.attr('data-errortext', defaultErrorText);
            }
        }

        /**
         * @param returnValue
         * @param isValid
         */
        function setValidationReturnValue(returnValue, isValid) {
            var isValid = isValid || false;

            if (returnValue) {
                if (returnValue.isValid === true && !isValid) {
                    returnValue.isValid = false;
                }
            }
        }


        return {
            init: function(cfg, $form) {
                config = $.extend(true, {}, config, cfg);

                bindEvents($form);
            },

            Validator: Validator,

            setValidationReturnValue: setValidationReturnValue,
            setErrorText: setErrorText,
            setStatus: setStatus
        };

    }
);
