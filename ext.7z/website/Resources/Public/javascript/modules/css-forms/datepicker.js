define(function(require) {

    var $ = require('jquery');

    var defaultConfig = {
        'type' : 'datetime'
    };

    var Datepicker = function(config) {
        var oDate;
        var oNode;
        var that;
        var oTarget;
        var oSelected;
        var sDateString;
        var sTimeString;
        var sHour;
        var sMinute;
        var sAmPm;
        var dateFormat = '#d.#m.#y';


        config = config || {};

        config = $.extend(true, {}, defaultConfig, config);

        var iX,
            iY;

        function Datepicker() {
            oNode = document.createElement('div');
            oNode.className = "cssfPicker";
            oDate = new Date();

            sTimeString = "09:30 AM";
            sHour = "09";
            sMinute = "30";
            sAmPm = "AM";

            if (config.type == 'time') {
                oNode.appendChild(generateTimeContent());
            } else {
                oNode.appendChild(generateContent());
            }
            that = this;
        }

        function generateContent() {
            var oTbl    = document.createElement('table');
            var oThead  = document.createElement('thead');
            var oBody1  = document.createElement('tbody');
            var oBody2  = document.createElement('tbody');
            var oPrev   = document.createElement('a');
            var oNext   = document.createElement('a');
            var aDays   = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];

            oPrev.href = "#";
            oPrev.title= "Show previous month";
            //oPrev.innerHTML = '\ue93b';
            oPrev.className = 'prevMonth';
            oNext.href = "#";
            oNext.title= "Show next month";
            //oNext.innerHTML = '\ue93c';
            oNext.className = 'nextMonth';

            oThead.appendChild(document.createElement('tr'));
            oThead.querySelector('tr').appendChild(document.createElement('th'));
            oThead.querySelector('tr').appendChild(document.createElement('th'));
            oThead.querySelector('tr').appendChild(document.createElement('th'));

            oThead.querySelectorAll('tr th')[0].appendChild(oPrev);
            oThead.querySelectorAll('tr th')[0].className = "prevMonth";
            oThead.querySelectorAll('tr th')[1].setAttribute('colspan', 5);
            oThead.querySelectorAll('tr th')[1].innerHTML = oDate.getMonthString() + " " + oDate.getFullYear();
            oThead.querySelectorAll('tr th')[2].appendChild(oNext);
            oThead.querySelectorAll('tr th')[2].className = "nextMonth";
            oBody1.appendChild(document.createElement('tr'));

            for(var i=0;i<7;i++) {
                oBody1.querySelector('tr').appendChild(document.createElement('th'));
                oBody1.querySelectorAll('tr th')[i].appendChild(document.createElement('span'));
                oBody1.querySelectorAll('tr th')[i].querySelector('span').innerHTML = aDays[i];
            }

            var oTmp = oDate.getDatepickerStart();
            var oRow = document.createElement('tr');

            while(true) {
                var oCol = document.createElement('td');
                oCol.appendChild(document.createElement('a'));
                oCol.querySelector('a').setAttribute('href', '#');
                oCol.querySelector('a').setAttribute('target','_self');
                oCol.querySelector('a').className = "pickDate";

                if( oTmp.isOldMonth() )
                    oCol.className = "cssfPickerOldMonth";

                if( oTmp.isNewMonth() )
                    oCol.className = "cssfPickerNewMonth";

                if( oTmp.isToday() )
                    oCol.className = "cssfPickerToday";

                if( oTmp.isSelected() )
                    oCol.className = "cssfPickerSelected";

                oCol.querySelector('a').innerHTML = oTmp.getDate();

                oRow.appendChild(oCol);

                if( oTmp.getDay() == 6 ) {
                    oBody2.appendChild(oRow);
                    oRow = document.createElement('tr');
                }

                if( oTmp.isNewMonth() && oTmp.getDay() == 6 )
                    break;

                oTmp.setDate(oTmp.getDate()+1);

                if( oTmp.isNewMonth() && oTmp.getDay() == 0 )
                    break;
            }

            oTbl.appendChild(oThead);
            oTbl.appendChild(oBody1);
            oTbl.appendChild(oBody2);
            return oTbl;
        }

        function generateTimeContent() {
            var oTbl    = document.createElement('table');
            var oThead  = document.createElement('thead');
            var oTbody  = document.createElement('tbody');
            var oRow1   = document.createElement('tr');
            var oRow2   = document.createElement('tr');
            var oRow3   = document.createElement('tr');
            var oRow4   = document.createElement('tr');

            if (config.type == 'datetime') {
                oThead.appendChild(document.createElement('tr'));
                oThead.querySelector('tr').appendChild(document.createElement('th'));
                oThead.querySelector('tr th').setAttribute('colspan', 3);
                oThead.querySelector('tr th').innerHTML = sDateString;
            }

            var aClass  = ['hours','minutes','am_pm'];
            var aTitle  = ['Increase hours', 'Increase Minutes', 'Switch between AM and PM'];
            for(var i=0;i<3;i++) {
                oRow1.appendChild(document.createElement('th'));
                oRow1.querySelectorAll('th')[i].className = "upTime " + aClass[i];
                oRow1.querySelectorAll('th')[i].appendChild(document.createElement('a'));
                oRow1.querySelectorAll('th a')[i].href = '#';
                oRow1.querySelectorAll('th a')[i].setAttribute('title', aTitle[i]);
                oRow1.querySelectorAll('th a')[i].setAttribute('target', '_self');
            }

            var aVals   = [sHour,sMinute,sAmPm];
            for(var i=0;i<3;i++) {
                oRow2.appendChild(document.createElement('td'));
                oRow2.querySelectorAll('td')[i].appendChild(document.createElement('span'));
                oRow2.querySelectorAll('td span')[i].className = "time " + aClass[i];
                oRow2.querySelectorAll('td span')[i].innerHTML = aVals[i];
            }

            var aTitle  = ['Decrease hours', 'Decrease minutes', 'Switch between AM and PM'];
            for(var i=0;i<3;i++) {
                oRow3.appendChild(document.createElement('th'));
                oRow3.querySelectorAll('th')[i].className = "downTime " + aClass[i];
                oRow3.querySelectorAll('th')[i].appendChild(document.createElement('a'));
                oRow3.querySelectorAll('th a')[i].href = '#';
                oRow3.querySelectorAll('th a')[i].setAttribute('title', aTitle[i]);
                oRow3.querySelectorAll('th a')[i].setAttribute('target', '_self');
            }

            oRow4.appendChild(document.createElement('th'));
            oRow4.querySelector('th').setAttribute('colspan',3);
            oRow4.querySelector('th').appendChild(document.createElement('a'));
            oRow4.querySelector('th a').setAttribute('href','#');
            oRow4.querySelector('th a').setAttribute('target','_self');
            oRow4.querySelector('th a').setAttribute('title','Apply');
            oRow4.querySelector('th a').innerHTML = "Done";
            oRow4.querySelector('th a').className = "mainLink applyTime";

            oTbody.appendChild(oRow1);
            oTbody.appendChild(oRow2);
            oTbody.appendChild(oRow3);
            oTbody.appendChild(oRow4);

            oTbl.appendChild(oThead);
            oTbl.appendChild(oTbody);
            return oTbl;
        }

        function attachEvents() {
            var aNodes = oNode.querySelectorAll('a.pickDate');
            for(var i=0;i<aNodes.length;i++) {
                aNodes[i].addEventListener('click', function (e) {
                    e.stopImmediatePropagation();
                    e.preventDefault();

                    oDate.setDate(this.innerHTML);

                    oTarget.focus();
                    sDateString = dateFormat;
                    sDateString = sDateString.replace('#d', oDate.twoDigitDate()).replace('#m',oDate.twoDigitMonth()).replace('#y',oDate.getFullYear());

                    if (config.type == 'date' || oTarget.className.indexOf('dateOnly') > -1) {
                        oTarget.value = sDateString;
                        that.close();
                    }
                    else {
                        oTarget.focus();

                        if( oNode.querySelectorAll('table').length > 0 ) {
                            oNode.removeChild(oNode.querySelector('table'));
                        }

                        oNode.appendChild(generateTimeContent());
                        attachEvents();
                    }
                }, false);
            }

            if( oNode.querySelector('a.prevMonth') != null ) {
                oNode.querySelector('a.prevMonth').addEventListener('click', function (e) {
                    e.preventDefault();
                    e.stopImmediatePropagation();

                    if (oNode.querySelectorAll('table').length > 0) {
                        oNode.removeChild(oNode.querySelector('table'));
                    }

                    oDate = oDate.getPreviousMonth();
                    oNode.appendChild(generateContent());
                    attachEvents();
                }, false);
            }

            if( oNode.querySelector('a.nextMonth') != null ) {
                oNode.querySelector('a.nextMonth').addEventListener('click', function (e) {
                    e.preventDefault();
                    e.stopImmediatePropagation();

                    if (oNode.querySelectorAll('table').length > 0) {
                        oNode.removeChild(oNode.querySelector('table'));
                    }

                    oDate = oDate.getNextMonth();
                    oNode.appendChild(generateContent());
                    attachEvents();
                }, false);
            }

            if( oNode.querySelector('th.upTime.hours a') != null ) {
                oNode.querySelector('th.upTime.hours a').addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopImmediatePropagation();

                    var iCurrent = parseInt( oNode.querySelector('span.time.hours').innerHTML );
                    var iNew     = iCurrent==12 ? 1 : iCurrent+1;

                    oNode.querySelector('span.time.hours').innerHTML = iNew < 10 ? '0' + iNew : iNew;
                },false);
            }

            if( oNode.querySelector('th.upTime.minutes a') != null ) {
                oNode.querySelector('th.upTime.minutes a').addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopImmediatePropagation();

                    var iCurrent = parseInt( oNode.querySelector('span.time.minutes').innerHTML );
                    var iNew     = iCurrent==45 ? 0 : iCurrent+15;

                    oNode.querySelector('span.time.minutes').innerHTML = iNew < 10 ? '0' + iNew : iNew;
                },false);
            }

            if( oNode.querySelector('th.upTime.am_pm a') != null ) {
                oNode.querySelector('th.upTime.am_pm a').addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopImmediatePropagation();

                    var sCurrent = oNode.querySelector('span.time.am_pm').innerHTML;

                    oNode.querySelector('span.time.am_pm').innerHTML = sCurrent == "AM" ? "PM" : "AM";
                },false);
            }

            if( oNode.querySelector('th.downTime.hours a') != null ) {
                oNode.querySelector('th.downTime.hours a').addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopImmediatePropagation();

                    var iCurrent = parseInt( oNode.querySelector('span.time.hours').innerHTML );
                    var iNew     = iCurrent==1 ? 12 : iCurrent-1;

                    oNode.querySelector('span.time.hours').innerHTML = iNew < 10 ? '0' + iNew : iNew;
                },false);
            }

            if( oNode.querySelector('th.downTime.minutes a') != null ) {
                oNode.querySelector('th.downTime.minutes a').addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopImmediatePropagation();

                    var iCurrent = parseInt( oNode.querySelector('span.time.minutes').innerHTML );
                    var iNew     = iCurrent==0 ? 45 : iCurrent-15;

                    oNode.querySelector('span.time.minutes').innerHTML = iNew < 10 ? '0' + iNew : iNew;
                },false);
            }

            if( oNode.querySelector('th.downTime.am_pm a') != null ) {
                oNode.querySelector('th.downTime.am_pm a').addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopImmediatePropagation();

                    var sCurrent = oNode.querySelector('span.time.am_pm').innerHTML;

                    oNode.querySelector('span.time.am_pm').innerHTML = sCurrent == "AM" ? "PM" : "AM";
                },false);
            }

            if( oNode.querySelector('a.mainLink') != null ) {
                oNode.querySelector('a.mainLink').addEventListener('click', function(e) {
                    var timeValue = '',
                        dateValue = '';
                    e.preventDefault();
                    e.stopImmediatePropagation();

                    timeValue = oNode.querySelector('span.time.hours').innerHTML + ":" + oNode.querySelector('span.time.minutes').innerHTML + " " + oNode.querySelector('span.time.am_pm').innerHTML;
                    dateValue = sDateString;


                    if (config.type == 'time') {
                        oTarget.value = timeValue;
                    } else if (config.tpye == 'date') {
                        oTarget.value = dateValue;
                    } else if (config.type == 'datetime') {
                        oTarget.value = dateValue + ' ' + timeValue;
                    }

                    that.close();
                    $(document).off('click');
                },false);
            }
        }

        Datepicker.prototype.clearSelected = function() {
            oSelected = null;
        };

        Datepicker.prototype.setDate = function(s) {
            if( oDate == null )
                oDate = new Date();

            var a = s.split(".");

            if(a.length != 3) {
                oDate = new Date();

                if( oNode.querySelectorAll('table').length > 0 ) {
                    oNode.removeChild(oNode.querySelector('table'));
                }

                if (config.type != 'time') {
                    oNode.appendChild(generateContent());
                } else {
                    oNode.appendChild(generateTimeContent());
                }
                return false;
            }

            oDate.setDate(parseInt(a[0]));
            oDate.setMonth(parseInt(a[1])-1);
            oDate.setFullYear(parseInt(a[2]));

            oSelected = new Date();
            oSelected.applyFromDate(oDate);

            if( oNode.querySelectorAll('table').length > 0 ) {
                oNode.removeChild(oNode.querySelector('table'));
            }

            if (config.type != 'time') {
                oNode.appendChild(generateContent());
            } else {
                oNode.appendChild(generateTimeContent());
            }
            //oNode.appendChild(generateContent());
        };

        Datepicker.prototype.setTime = function(s) {
            if(typeof s == "undefined" || s == "")
                return;

            var aData = s.split(" ");
            var aTime = aData[0].split(":");

            sHour       = typeof aTime[0] != "undefined" ? aTime[0] : "09";
            sMinute     = typeof aTime[1] != "undefined" ? aTime[1] : "30";
            sAmPm       = typeof aData[1] != "undefined" ? aData[1] : "AM";
            sDateString = s;
        };

        Datepicker.prototype.getDate = function() {
            return oDate;
        };

        Datepicker.prototype.getDateString = function() {

        };

        Datepicker.prototype.getTime = function() {

        };

        Datepicker.prototype.getTimestamp = function() {

        };

        Datepicker.prototype.setTarget = function(t) {
            oTarget = t;
        };

        Datepicker.prototype.open = function() {
            document.body.appendChild(oNode);

            oNode.style.zIndex = 1000000;
            oNode.style.top = iY + 'px';
            oNode.style.left = iX + 'px';

            attachEvents();
        };

        Datepicker.prototype.getTarget = function() {
            return oTarget;
        };

        Datepicker.prototype.close = function() {
            oTarget = null;
            oDate = null;

            sTimeString = "09:30 AM";
            sHour = "09";
            sMinute = "30";
            sAmPm = "AM";

            document.body.removeChild(oNode);
        };

        Datepicker.prototype.setPositionX = function(x) {
            iX = x;
        };

        Datepicker.prototype.setPositionY = function(y) {
            iY = y;
        };

        Datepicker.prototype.attachCloseEvent = function() {
            var that = this;

            setTimeout(function() {
                $(document).one('click', function(e) {
                    if(e.target != that.getTarget() && $(e.target).parents('.cssfPicker').length == 0 && !$(e.target).hasClass('cssfPicker'))
                        that.close();
                    else
                        that.attachCloseEvent();
                });
            },100);
        };

        Datepicker.prototype.setDateFormat = function(s) {
            dateFormat = s;
        };

        Date.prototype.getPreviousMonth = function() {
            var oTmp = new Date();
            oTmp.applyFromDate(oDate);
            oTmp.setMonth(oTmp.getMonth()-1);
            return oTmp;
        };

        Date.prototype.getNextMonth = function() {
            var oTmp = new Date();
            oTmp.applyFromDate(oDate);
            oTmp.setMonth(oTmp.getMonth()+1);
            return oTmp;
        };

        Date.prototype.getMonthString = function() {
            var aMonths = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
            return aMonths[this.getMonth()];
        };

        Date.prototype.applyFromDate = function(oTmp) {
            this.setMonth(oTmp.getMonth());
            this.setFullYear(oTmp.getFullYear());
            this.setDate(oTmp.getDate());
            this.setHours(oTmp.getHours());
            this.setMinutes(oTmp.getMinutes());
            this.setSeconds(oTmp.getSeconds());
            return this;
        };

        Date.prototype.getFirstDay = function() {
            if( this.getDate() == 1 ) {
                return this;
            }

            var oTmp = new Date();
            oTmp.applyFromDate(this);
            oTmp.setDate(1);
            return oTmp;
        };

        Date.prototype.isOldMonth = function() {
            return this.getMonth() == oDate.getMonth() - 1 || (this.getMonth() == 11 && oDate.getMonth() == 0);
        };

        Date.prototype.isNewMonth = function() {
            return this.getMonth() == oDate.getMonth() + 1 || (this.getMonth() == 0 && oDate.getMonth() == 11);
        };

        Date.prototype.isToday = function() {
            var oTmp = new Date();
            return oTmp.getDate() == this.getDate() && oTmp.getMonth() == this.getMonth() && oTmp.getFullYear() == this.getFullYear();
        };

        Date.prototype.getDatepickerStart = function() {
            if( oDate.getFirstDay().getDay() == 0 )
                return oDate.getFirstDay();

            var oTmp = new Date();
            oTmp.applyFromDate(oDate.getFirstDay());
            oTmp.setDate(-(oTmp.getDay()-1));

            return oTmp;
        };

        Date.prototype.twoDigitDate = function() {
            if( this.getDate() < 10 )
                return "0" + this.getDate();

            return this.getDate();
        };

        Date.prototype.twoDigitMonth = function() {
            if( this.getMonth() + 1 < 10 )
                return "0" + (this.getMonth() + 1);

            return this.getMonth() + 1;
        };

        Date.prototype.isSelected = function() {
            if( oSelected == null )
                return false;

            return oSelected.getDate() == this.getDate() && oSelected.getMonth() == this.getMonth() && oSelected.getFullYear() == this.getFullYear();
        };

        return new Datepicker();
    };

    $(document).ready(function() {
        //var oPickr  = null;
        var tout    = null;

        $('body').on({
            focus: function(e) {
                e.preventDefault();

                var oPickr = $(this).data('oPickr');

                if( oPickr == null || typeof oPickr == 'undefined' ) {
                    oPickr = new Datepicker({
                        type: 'date'
                    });
                }
                else if( oPickr.getTarget() == this ) {
                    oPickr.open();
                    oPickr.attachCloseEvent();
                    return;
                }

                var iTop = $(this).offset().top + $(this).height();
                var iLeft = $(this).offset().left;

                var aVal    = this.value.split(" ");

                oPickr.setPositionX(iLeft);
                oPickr.setPositionY(iTop);
                oPickr.setTarget(this);

                if( typeof $(this).data('format') != "undefined" )
                    oPickr.setDateFormat($(this).data('format'));
                else
                    oPickr.setDateFormat("#d.#m.#y");

                if( $(this).val() == "" )
                    oPickr.clearSelected();

                oPickr.setDate(aVal[0]);
                oPickr.setTime(typeof aVal[1] != "undefined" ? aVal[1] + " " + aVal[2] : "");
                oPickr.attachCloseEvent();
                oPickr.open();

                $(this).data('oPickr', oPickr);
            }
        }, 'input[type=date]');

        $('body').on({
            focus: function(e) {
                e.preventDefault();

                var oPickr = $(this).data('oPickr');

                if( oPickr == null || typeof oPickr == 'undefined' ) {
                    oPickr = new Datepicker({
                        type: 'time'
                    });
                }
                else if( oPickr.getTarget() == this ) {
                    oPickr.open();
                    oPickr.attachCloseEvent();
                    return;
                }

                var iTop = $(this).offset().top + $(this).height();
                var iLeft = $(this).offset().left;

                var aVal    = this.value.split(" ");

                oPickr.setPositionX(iLeft);
                oPickr.setPositionY(iTop);
                oPickr.setTarget(this);

                if( typeof $(this).data('format') != "undefined" )
                    oPickr.setDateFormat($(this).data('format'));
                else
                    oPickr.setDateFormat("#d.#m.#y");

                if( $(this).val() == "" )
                    oPickr.clearSelected();

                oPickr.setDate(aVal[0]);
                oPickr.setTime(typeof aVal[1] != "undefined" ? aVal[1] + " " + aVal[2] : "");
                oPickr.attachCloseEvent();
                oPickr.open();

                $(this).data('oPickr', oPickr);
            }
        }, 'input[type=time]');

        $('body').on({
            focus: function(e) {
                e.preventDefault();

                var oPickr = $(this).data('oPickr');

                if( oPickr == null || typeof oPickr == 'undefined' ) {
                    oPickr = new Datepicker({
                        type: 'datetime'
                    });
                }
                else if( oPickr.getTarget() == this ) {
                    oPickr.open();
                    oPickr.attachCloseEvent();
                    return;
                }

                var iTop = $(this).offset().top + $(this).height();
                var iLeft = $(this).offset().left;

                var aVal    = this.value.split(" ");

                oPickr.setPositionX(iLeft);
                oPickr.setPositionY(iTop);
                oPickr.setTarget(this);

                if( typeof $(this).data('format') != "undefined" )
                    oPickr.setDateFormat($(this).data('format'));
                else
                    oPickr.setDateFormat("#d.#m.#y");

                if( $(this).val() == "" )
                    oPickr.clearSelected();

                oPickr.setDate(aVal[0]);
                oPickr.setTime(typeof aVal[1] != "undefined" ? aVal[1] + " " + aVal[2] : "");
                oPickr.attachCloseEvent();
                oPickr.open();

                $(this).data('oPickr', oPickr);
            }
        }, 'input[type=datetime]');
    });

    return Datepicker;
});