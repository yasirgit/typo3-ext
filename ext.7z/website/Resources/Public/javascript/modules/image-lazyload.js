define(
    ['jquery'],
    function ($) {

        function reveal() {

            $('picture:not([data-loaded])').each(function (i, el) {
                var $el = $(el),
                    $sourceElements = $el.find('source');

                if ($el.visible(true, 0.7) && $el.attr('data-loaded') !== 'true') {
                    $sourceElements.each (function(i, source) {
                        var $source = $(source);
                        $source.attr('srcset', $source.attr('data-srcset'));
                        $source.removeAttr('data-srcset');
                    });

                    $el.attr('data-loaded', 'true');
                }
            });

            $('img:not([data-loaded])').each(function (i, el) {
                var $el = $(el);

                if ($el.visible(true, 0.7) && $el.attr('data-loaded') !== 'true') {
                    $el.attr('src', $el.attr('data-src'));
                    $el.removeAttr('data-src');
                    $el.attr('data-loaded', 'true');
                }
            });
        }

        function detectImages() {
            $('img:not([data-loaded])').each(function (i, el) {
                var $el = $(el);

                if ($el.parents('.slider').length > 0) {
                    return;
                }

                if (!el.hasAttribute('data-src')) {
                    $el.attr('data-src', $el.attr('src'));
                }
                $el.attr('src', '');//data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7');
            });
        }

        return {
            init: function () {
                detectImages();

                $(window).on('resize scroll', reveal);
                reveal();

                $('#detail').on('scroll resize', reveal);
            },
            detectImages: detectImages,
            reveal: reveal
        }

    }
);