/**
 * @author Stefan Glotzbach <s.glotzbach@orangehive.de>
 */

/*
 // Check for required objects/functions. If not existent: mock them up and leave a message on console!
 if (!window.Modernizr) {
 console.log('* could not init cssFormsV5 correctly - Modernizr has been undefined');

 window.Modernizr = {
 load : function(){},
 input : {}
 };
 console.log('  - created Modernizr mockup of used functionality, possibly some functions do not work like expected');
 }
 if (!$.fn.datepicker) {
 console.log('* could not init cssFormsV5 correctly - $.fn.datepicker has been undefined');

 $.fn.datepicker = function(){};
 console.log('  - created datepicker mockup of used functionality, possibly some functions do not work like expected');
 }

 */
;
(function ($, window, undefined) {

    var pluginName = 'cssFormsV5',
        defaults = {
            addRequiredIndicator : true,
            selectors : {
                validateTrigger : '.required input, .required textarea, .required select, .required [contenteditable="true"]'
            },
            useErrorText : true,
            useErrorTextViaCss : true,
            defaultErrorText : "Bitte füllen Sie dieses Feld korrekt aus."
        },
        self,
        Regex = {
            email:/^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/,
            url:/\b(((\S+)?)(@|mailto\:|(news|(ht|f)tp(s?))\:\/\/)\S+)\b/i,
            number:/[0-9]+/
        },
        Classes = {
            cssForm:'cssForm',
            required:'cssfRequired',
            valid:'cssfValid',
            invalid:'cssfError',
            selectorGroup:'selectorGroup'
        },
        Const = {
            VALID:true,
            INVALID:false
        };


    function Plugin(element, options) {
        self = this;

        this.element = element;
        this.$element = $(element);

        this.options = $.extend({}, defaults, options);

        this._defaults = defaults;
        this._name = pluginName;

        this.status = Const.VALID;

        this.init();
    }

    Plugin.prototype.init = function () {
        $('html').addClass('js');

        this.$element.addClass(Classes.cssForm);

        this.Styles.init(this);
        this.Placeholder.init(this);
        //this.DatePicker.init(this);
        this.FileStyle.init(this);
        this.Validation.init(this);
        this.Foldable.init(this);
        this.Autogrow.init(this);
    };

    Plugin.prototype.Styles = {

        controls: 'input:not([type=radio]):not([type=checkbox]), .inputStyle, textarea, select',

        init:function (plugin) {
            this.plugin = plugin;

            this.plugin.$element.find('fieldset:not(.rows):not(.cols) label')
                .has(this.controls)
                .has('.lbl')
                .children(this.controls)
                .addClass('readyForMoving')
                .prev('.lbl').each( function(i, el){
                    var $el = $(el), $control = $el.next();

                    $el
                        .addClass('moving')
                        .detach()
                        .insertAfter($control);

                });

            this.plugin.$element.find('select')
                .closest('label')
                .addClass('styledSelect');
				
            this.plugin.$element.find('fieldset[data-errortext]')
                .attr('data-errortext', '')
                .children('legend')
                .attr('data-errortext', 'DEV: Should be fieldset[data-errortext]'); //@todo

            this.plugin.$element.find('[required]')
                .closest('label')
                .addClass('cssfRequired');

            this.plugin.$element.find('input[type=checkbox], input[type=radio]')
                .after('<span class="styled">')
                .closest('label')
                .attr('data-errortext', '')
                .addClass('styledSelector')
                .children('.lbl')
                .attr('data-errortext', 'DEV: Should be label[data-errortext]'); //@todo


            this.plugin.$element.on('focus', this.controls, function(){
                $(this).addClass('seen');  // browsernative validierung wird erst nach "sehen" eines controls angezeigt
            });
        },
        attachEvents: function() {

        }
    },

    // Emulate placeholders in older browsers
    Plugin.prototype.Placeholder = {
        init:function (plugin) {
            this.plugin = plugin;
/*
            Modernizr.load({
                test:Modernizr.input.placeholder,
                nope:[
                    'css/placeholder_polyfill.min.css',
                    'js/placeholder_polyfill.jquery.min.combo.js'
                ]
            });*/
        }
    };
    // end of Placeholder

    // DatePicker
    Plugin.prototype.DatePicker = {
        init:function (plugin) {
            this.plugin = plugin;

            var T = top.Translation;


            $('input.datePicker, input.datepicker').each(function(i, el) {
                var $el = $(el),
                    properties = {
                        firstDay: 1,
                        dateFormat: 'dd.mm.yy',
                        monthNames: [
                            T.get('etc', 'datePicker.month.january'),
                            T.get('etc', 'datePicker.month.february'),
                            T.get('etc', 'datePicker.month.march'),
                            T.get('etc', 'datePicker.month.april'),
                            T.get('etc', 'datePicker.month.may'),
                            T.get('etc', 'datePicker.month.june'),
                            T.get('etc', 'datePicker.month.july'),
                            T.get('etc', 'datePicker.month.august'),
                            T.get('etc', 'datePicker.month.september'),
                            T.get('etc', 'datePicker.month.october'),
                            T.get('etc', 'datePicker.month.november'),
                            T.get('etc', 'datePicker.month.december')
                        ],
                        dayNames: [
                            T.get('etc', 'datePicker.day.sunday'),
                            T.get('etc', 'datePicker.day.monday'),
                            T.get('etc', 'datePicker.day.tuesday'),
                            T.get('etc', 'datePicker.day.wednesday'),
                            T.get('etc', 'datePicker.day.thursday'),
                            T.get('etc', 'datePicker.day.friday'),
                            T.get('etc', 'datePicker.day.saturday')
                        ],
                        dayNamesMin: [
                            T.get('etc', 'datePicker.day.sunday.short'),
                            T.get('etc', 'datePicker.day.monday.short'),
                            T.get('etc', 'datePicker.day.tuesday.short'),
                            T.get('etc', 'datePicker.day.wednesday.short'),
                            T.get('etc', 'datePicker.day.thursday.short'),
                            T.get('etc', 'datePicker.day.friday.short'),
                            T.get('etc', 'datePicker.day.saturday.short')
                        ]
                    },
                    minDate = $el.attr('data-min-date');

                if (minDate) {
                    properties['minDate'] = minDate;
                }

                $el.datepicker(properties);
            });

            //prefill Datepicker if empty
            var $datePickerElementReduced = $('.datePicker:not([data-prefill=false])'),
                datePickerFormat = $datePickerElementReduced.datepicker('option', 'dateFormat'),
                datePickerToday = $.datepicker.formatDate(datePickerFormat, new Date());

            if($datePickerElementReduced.val() == "") { $datePickerElementReduced.val(datePickerToday) };
        }
    };
    // end of DatePicker

    // FileUpload styling
    Plugin.prototype.FileStyle = {

        init:function (plugin) {
            var that = this;

            this.plugin = plugin;
            this.$element = plugin.$element;

            this.$element.find('input[type="file"]').each(function (i, el) {
                var $el = $(el);
                if ($el.hasClass('fileStyle')) {
                    that.wrapFileInput($el);
                }
            });
        },

        wrapFileInput:function ($fileInput) {
            var $element = $fileInput.clone(true),
                $parent = $fileInput.parent(),
                parentWidth = $parent.width(),
                prefillText = $element.attr('data-prefill') || '',
                buttonText = $element.attr('data-buttontext') || top.Translation.get('etc', 'fileUpload.search'),
                $wrapper = $('<div class="fileInputWrapper" />'),
                $inputField = $('<input type="text" value="" class="selectedFile" readonly="readonly" />'),
                $button = $('<a href="#" class="selectFile button"></a>');


            $button
                .text(buttonText)
                .css({
                    width : '120px',
                    lineHeight : '24px'
                })
                .on('click', false);
            $inputField
                .val(prefillText)
                .css('width', /*parentWidth - 124*/ 224 + 'px');
            $element
                .on('change', function (e) {
                    var $this = $(this),
                        fileInputVal = $this.val(),
                        fileName = fileInputVal.match(/([^\\/]*)$/i);

                    $this.parent().find('input.selectedFile').val(fileName[1]);
                })
                .css({
                    zIndex : 1000,
                    fontSize: '200px',
                    opacity : 0,
                    //left: '-200px',
                    top: '-100px',
                    position: 'absolute'
                })
                .attr('tabindex', '-1');

            $wrapper
                .css({
                    overflow: 'hidden',
                    position : 'relative'
                });

            $fileInput.replaceWith(
                $wrapper
                    .append($element)
                    .append($inputField)
                    .append($button)
            );
        }

    };
    // end of FileStyle

    // Folding sets
    Plugin.prototype.Foldable = {

        init:function (plugin) {
            this.plugin = plugin;
            this.$element = plugin.$element;

            plugin.$element
                .on('click', '.cssfFoldable .cssfFoldNote a', $.proxy(this.events.openOrClose, this));
        },

        events:{
            openOrClose:function (e) {
                var $target = $(e.target),
                    $foldableWrapper = $target.parents('.cssfFoldable');

                e.preventDefault();

                if ($foldableWrapper.hasClass('cssfOpen')) {
                    this.close($foldableWrapper, $target);
                } else {
                    this.open($foldableWrapper, $target);
                }
            }
        },

        open:function ($foldableWrapper, $element) {
            var $innerFoldable = $foldableWrapper.find('.cssfInnerFoldable');

            $innerFoldable.css('display', 'block');
            $foldableWrapper.addClass('cssfOpen');
        },

        close:function ($foldableWrapper, $element) {
            var $innerFoldable = $foldableWrapper.find('.cssfInnerFoldable');

            $innerFoldable.css('display', 'none');
            $foldableWrapper.removeClass('cssfOpen');
        }
    };
    // end of Foldable

    // Autogrow
    Plugin.prototype.Autogrow = {

        init:function (plugin) {
            this.plugin = plugin;
            this.$element = plugin.$element;

            plugin.$element
                .on('keyup', 'textarea[data-autogrow=true]', $.proxy(this.events.doResize, this));
        },

        events:{
            doResize:function (e) {
                var target = e.target,
                    $target = $(target);

                e.preventDefault();

                var $n = $target.next();
                if ($n.length > 0 && $n.hasClass('dummyText')) {
                    // do nothing
                } else {
                    $('<span class="info dummyText">Not yet implemented!</span>')
                        .css({
                            backgroundColor:'#C3C3C3',
                            color:'#FF0000',
                            display:'inline-block',
                            fontStyle:'italic',
                            textAlign:'center',
                            width:'100%'
                        })
                        .insertAfter($target);
                }
                // for autogrowing plugin
            }
        }
    };
    // end of Autogrow

    // Validation
    Plugin.prototype.Validation = {
        init:function (plugin) {
            var $element = plugin.$element,
                events = this.events;

            console.log('init validation');

            this.plugin = plugin;
            this.$element = $element;
            this.options = plugin.options;

            if (this.options.addRequiredIndicator) {
                this.setRequiredIndicators();
            }

            // if novalidate has been set initially before plugin has been applied do not validate the fields
            if ($element.attr('novalidate')) {
                return;
            }

            // needed to prevent html5-browser-validations
            $element.attr('novalidate', 'novalidate');

            $element
                .on('validate', $.proxy(events.validate, this))
                .on('_validate change blur', ':not(.customValidation, .selectorGroup) input[type="email"]', $.proxy(events.email, this))
                .on('_validate change blur', '.required:not(.customValidation, .selectorGroup) input[type="url"]', $.proxy(events.url, this))
                .on('_validate change blur', '.required:not(.customValidation, .selectorGroup) input[type="password"]', $.proxy(events.text, this))
                .on('_validate change blur', '.required:not(.customValidation, .selectorGroup) input[type="text"], .required:not(.selectorGroup) textarea', $.proxy(events.text, this))
                .on('_validate change blur', '.required:not(.customValidation, .selectorGroup) input[type="number"]', $.proxy(events.number, this))
                .on('keydown', '.required:not(.customValidation, .selectorGroup) input[type="number"]', $.proxy(events.numberKeyDown, this))
                .on('_validate change blur', '.required:not(.customValidation, .selectorGroup) input[type="file"]', $.proxy(events.file, this))
                .on('_validate change blur', '.required:not(.customValidation, .selectorGroup) select', $.proxy(events.select, this))
                .on('_validate change blur click', '.required:not(.customValidation) input[type="checkbox"]', $.proxy(events.checkbox, this))
                .on('_validate change blur click', '.required:not(.customValidation) input[type="radio"]', $.proxy(events.radio, this))
                .on('_validate change blur', '.required:not(.customValidation) [contenteditable="true"]', $.proxy(events.contentEditable, this))
                .on('submit', $.proxy(events.submit, this));

        },

        setRequiredIndicators : function() {
            var $requiredElements = this.$element.find('.' + Classes.required),
                mand = '<span class="mand">*</span>';

            $requiredElements.each(function(i, el) {
                var $el = $(el),
                    $placeholderElement = $el.find('[placeholder]');

                if ($el.find('span.mand').length > 0) {
                    return;
                }

                $el.find('.lbl').append(mand);
                $placeholderElement.attr('placeholder', $placeholderElement.attr('placeholder') + '*');
            });
        },

        events:{
            validate:function (e, returnValue) {
                returnValue = returnValue || {};

                // assume that the form is valid
                returnValue.isValid = true;

                this.$element.find(
                    this.options.selectors.validateTrigger
                ).trigger('_validate', [returnValue]);


                if (!returnValue.isValid) {
                    // scroll to first invalid field
                    this.$element.find('.' + Const.INVALID).first();
                }


                returnValue.preventSubmit = !returnValue.isValid;
            },
            email:function (e, returnValue) {
                var isValid = this.email(e.target);

                this.setErrorText($(e.target).parents('label').first(), isValid);
                this.setValidationReturnValue(returnValue, isValid);
            },
            url:function (e, returnValue) {
                var isValid = this.url(e.target);

                this.setErrorText($(e.target).parents('label').first(), isValid);
                this.setValidationReturnValue(returnValue, isValid);
            },
            text:function (e, returnValue) {
                var isValid = this.text(e.target);

                this.setErrorText($(e.target).parents('label').first(), isValid);
                this.setValidationReturnValue(returnValue, isValid);
            },
            number:function (e, returnValue) {
                var isValid = this.number(e.target);

                this.setErrorText($(e.target).parents('label').first(), isValid);
                this.setValidationReturnValue(returnValue, isValid);
            },
            numberKeyDown:function (e, returnValue) {
                var keyCode = e.keyCode;

                if (!( (keyCode == 8) || (keyCode == 46)
                    || (keyCode >= 48 && keyCode <= 57) || (keyCode >= 96 && keyCode <= 105)
                    || (keyCode >= 37 && keyCode <= 40)
                    || keyCode == 9 // tab
                    || keyCode == 173 || keyCode == 109 // minus
                    )) {
                    e.preventDefault();
                }
            },
            file:function (e, returnValue) {
                var isValid = this.file(e.target);

                this.setErrorText($(e.target).parents('label').first(), isValid);
                this.setValidationReturnValue(returnValue, isValid);
            },
            select:function (e, returnValue) {
                var isValid = this.select(e.target);

                this.setErrorText($(e.target).parents('label').first(), isValid);
                this.setValidationReturnValue(returnValue, isValid);
            },
            checkbox:function (e, returnValue) {
                var isValid = this.checkbox(e.target);

                this.setErrorText($(e.target).parents('label').first(), isValid);
                this.setValidationReturnValue(returnValue, isValid);
            },
            radio:function (e, returnValue) {
                var selectNeighbourInput = (e.type != '_validate'),
                    isValid = this.radio(e.target, selectNeighbourInput);

                this.setErrorText($(e.target).parents('label').first(), isValid);
                this.setValidationReturnValue(returnValue, isValid);
            },
            contentEditable:function (e, returnValue) {
                var isValid = this.contentEditable(e.target);

                this.setErrorText($(e.target).parents('label').first(), isValid);
                this.setValidationReturnValue(returnValue, isValid);
            },
            submit:function (e) {
                var $element = self.$element,
                    returnValue = {
                        preventSubmit : false,
                        isValid : true
                    },
                    exp;

                $element.trigger('beforeValidate.submit', [returnValue]);
                console.log(returnValue, $element, $element.attr('data-preventsubmitvalidation'));
                if (returnValue.preventValidation !== true && $element.attr('data-preventsubmitvalidation') !== 'true') {
                    $element.trigger('validate', [returnValue]);
                }
                $element.trigger('afterValidate.submit', [returnValue]);

                exp = (returnValue.preventSubmit !== true && returnValue.isValid);

                if (!exp) {
                    e.preventDefault();
                }

                return exp;
            }
        },

        /**
         * Actually setting the valid/invalid class to $parent.
         * @param validExpression | boolean expression
         * @param $parent
         */
        setStatus:function (validExpression, $parent) {
            if (validExpression) {
                $parent.removeClass(Classes.invalid).addClass(Classes.valid);
                return Const.VALID;
            } else {
                $parent.removeClass(Classes.valid).addClass(Classes.invalid);
                return Const.INVALID;
            }
        },

        /**
         * Display errortext if field is invalid. Used errortext is data-attribute errortext of $element.
         * @param $element
         * @param isValid
         */
        setErrorText:function ($element, isValid) {
            var options = this.options,
                errorText = $element.attr('data-errortext'),
                defaultErrorText = options.defaultErrorText,
                $next = $element.next();

            if (!options.useErrorText) {
                return;
            }

            if (options.useErrorTextViaCss) {
                if (!errorText) {
                    $element.attr('data-errortext', defaultErrorText);
                }
                return;
            }

            if (isValid) {
                if ($next && $next.hasClass('errorText')) {
                    $next.remove();
                }
            } else {
                errorText = errorText || defaultErrorText;

                if (errorText.length > 0 && !$next.hasClass('errorText')) {
                    $('<span class="errorText">' + errorText + '</span>').insertAfter($element);
                }
            }
        },

        /**
         * Set correct isValid on returnValue. returnValue.isValid can override isValid if it has been false!
         * @param returnValue
         * @param isValid
         */
        setValidationReturnValue:function (returnValue, isValid) {
            var isValid = isValid || false;

            if (returnValue) {
                if (returnValue.isValid === true && !isValid) {
                    returnValue.isValid = false;
                }
            }
        },

        email:function (element) {
            var $this = $(element),
                $parent = $this.parent(),
                val = $this.val(),
                pattern = $this.attr('pattern'),
                modifier = $this.attr('data-modifier') || '',
                regEx,
                exp;
			

			if (!$parent.hasClass(Classes.required) && val == '') {
				return this.setStatus(true, $parent);
			}
				
            if (pattern) {
                regEx = new RegExp(pattern, modifier);
                exp = regEx.test(val);
            } else {
                exp = Regex.email.test(val);
            }

            return this.setStatus(exp, $parent);
        },

        url:function (element) {
            var $this = $(element),
                $parent = $this.parent(),
                val = $this.val(),
                pattern = $this.attr('pattern'),
                modifier = $this.attr('data-modifier') || '',
                regEx,
                exp;

            if (pattern) {
                regEx = new RegExp(pattern, modifier);
                exp = regEx.test(val);
            } else {
                exp = Regex.url.test(val);
            }

            return this.setStatus(exp, $parent);
        },

        text:function (element) {
            var $this = $(element),
                $parent = $this.parent(),
                val = $.trim($this.val()),
                pattern = $this.attr('pattern'),
                modifier = $this.attr('data-modifier') || '',
                regEx,
                exp = (val.length > 1);

            if (pattern) {
                regEx = new RegExp(pattern, modifier);
                exp = regEx.test(val);
            }

            return this.setStatus(exp, $parent);
        },

        number:function (element) {
            var $this = $(element),
                $parent = $this.parent(),
                val = $.trim($this.val()),
                intVal = parseInt(val, 10),
                min = parseInt($this.attr('min'), 10),
                max = parseInt($this.attr('max'), 10),
                expr = Regex.number.test(val);

            if (min) {
                expr = expr && !(intVal < min);
            }

            if (max) {
                expr = expr && !(intVal > max);
            }

            return this.setStatus(expr, $parent);
        },

        file:function (element) {
            var $this = $(element),
                $parent = $this.parent(),
                val = $.trim($this.val());

            return this.setStatus(val.length > 1, $parent);
        },

        select:function (element) {
            var $this = $(element),
                $parent = $this.parent(),
                val = $.trim($this.val());

            return this.setStatus(val != '', $parent);
        },

        checkbox:function (element) {
            var $this = $(element),
                $parent = $this.parent();

            return this.setStatus($this.attr('checked'), $parent);
        },

        radio:function (element, selectNeighbourInput) {
            var $this = $(element),
                selectNeighbourInput = selectNeighbourInput || false,
                $next = $this.next(),
                $parent = $this.parent(),
                $selectorGroup = $this.parents('.' + Classes.selectorGroup),
                val = $.trim($this.val());

            if ($selectorGroup.length > 0) {
                $parent = $selectorGroup;
            }

            if (selectNeighbourInput && $next.length > 0 && $next.prop('tagName').toLowerCase() == 'input') {
                $next.focus();
            }

            return this.setStatus(val != '', $parent);
        },

        contentEditable:function (element) {
            var $this = $(element),
                $parent = $this.parent(),
                val = $.trim($this.text());

            return this.setStatus(val.length > 1, $parent);
        }
    };
    // end of Validation

    $.fn[pluginName] = function (options) {
        this.each(function () {
            if (!$.data(this, 'plugin_' + pluginName)) {
                $.data(this, 'plugin_' + pluginName, new Plugin(this, options));
            }
        });

        if (this.first().length > 0) {
            return this.first().data('plugin_' + pluginName);
        } else {
            return new Plugin(this, options);
        }
    };

    // set a global reference on $[pluginName] to get access to Validation easily
    $[pluginName] = new Plugin(this, {});


    $('.cssForm:not([data-init="custom"])').each(function(i, el) {
        $(el).cssFormsV5();
    });

}(jQuery, window));
