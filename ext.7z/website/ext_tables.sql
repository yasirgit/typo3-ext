#
# Modifying pages table
#
CREATE TABLE tt_content (
    tx_icon varchar(255) DEFAULT '' NOT NULL,
    tx_style varchar(255) DEFAULT '' NOT NULL,
);