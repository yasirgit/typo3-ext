<?php

use Standardlife\SlDownload\Domain\Model\Download;

use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Object\ObjectManager;
use TYPO3\CMS\Frontend\Controller\TypoScriptFrontendController;
use TYPO3\CMS\Frontend\Utility\EidUtility;

// init environment
$GLOBALS['TSFE'] = GeneralUtility::makeInstance(
    TypoScriptFrontendController::class,
    $GLOBALS['TYPO3_CONF_VARS'],
    null,
    0
);

EidUtility::initLanguage();
$GLOBALS['TSFE']->connectToDB();
$GLOBALS['TSFE']->initFEuser();
$GLOBALS['TSFE']->initUserGroups();
EidUtility::initTCA();
$GLOBALS['TSFE']->clear_preview();
$GLOBALS['TSFE']->determineId();
$GLOBALS['TSFE']->settingLanguage();
$GLOBALS['TSFE']->settingLocale();



// handling
$shortUrl = GeneralUtility::_GET('shortUrl');

/** @var \TYPO3\CMS\Extbase\Object\ObjectManager $objectManager */
$objectManager = GeneralUtility::makeInstance(ObjectManager::class);
/** @var \Standardlife\SlDownload\Domain\Repository\DownloadRepository $downloadRepository */
$downloadRepository = $objectManager->get(\Standardlife\SlDownload\Domain\Repository\DownloadRepository::class);


/** @var Download $download */
$download = $downloadRepository->findByShortUrl($shortUrl);


if ($download == null) {
    header('HTTP/1.0 404 Not Found');
    echo '404';
    exit(0);
}

$filePath = $download->getFile()->getOriginalResource()->getOriginalFile()->getForLocalProcessing();

if (strpos(__DIR__, realpath($filePath)) !== false) {
    $protocol = (isset($_SERVER['SERVER_PROTOCOL']) ? $_SERVER['SERVER_PROTOCOL'] : 'HTTP/1.0');

    header($protocol . ' 403 Forbidden');
    die('403 | Forbidden');
}
$ext = pathinfo($filePath, PATHINFO_EXTENSION);


header('Cache-Control: no-store, no-cache, must-revalidate');
header('Cache-Control: post-check=0, pre-check=0', false);
header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT');
header('Content-type: application/' . $ext);
header('Content-Disposition: inline; filename="' . $download->getName() . '.pdf"');
fpassthru(fopen($filePath, 'r'));


exit(0);