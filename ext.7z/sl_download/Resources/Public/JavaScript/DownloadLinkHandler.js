
define(['jquery', 'TYPO3/CMS/Recordlist/LinkBrowser'], function($, LinkBrowser) {
    'use strict';

    /**
     *
     * @type {{currentLink: string}}
     * @exports TYPO3/CMS/SlDownload/DownloadLinkHandler
     */
    var DownloadLinkHandler = {
        currentLink: ''
    };

    /**
     *
     * @param {Event} event
     */
    DownloadLinkHandler.linkPage = function(event) {
        event.preventDefault();

        var id = $(this).attr('data-id');
        var download = $(this).attr('data-download');

        LinkBrowser.finalizeFunction('page:' + id + (download ? '&tx_sldownload_downloadprovider[shortUrl]=' + download: ''));
    };

    /**
     *
     * @param {Event} event
     */
    DownloadLinkHandler.linkPageByTextfield = function(event) {
        event.preventDefault();

        var value = $('#luid').val();
        if (!value) {
            return;
        }

        LinkBrowser.finalizeFunction('page:' + value);
    };

    /**
     *
     * @param {Event} event
     */
    DownloadLinkHandler.linkCurrent = function(event) {
        event.preventDefault();

        LinkBrowser.finalizeFunction('page:' + DownloadLinkHandler.currentLink);
    };

    $(function() {
        DownloadLinkHandler.currentLink = $('body').data('currentLink');

        $('a.t3js-pageLink').on('click', DownloadLinkHandler.linkPage);
        $('input.t3js-linkCurrent').on('click', DownloadLinkHandler.linkCurrent);
        $('input.t3js-pageLink').on('click', DownloadLinkHandler.linkPageByTextfield);
    });

    return DownloadLinkHandler;
});
