<?php

namespace Standardlife\SlDownload\Slots;

use TYPO3\CMS\Frontend\Controller\TypoScriptFrontendController;

/**
 * Class UrlEncoder
 * @package Standardlife\SlDownload\Slots
 */
class UrlEncoder extends \DmitryDulepov\Realurl\Encoder\UrlEncoder
{

    /** @var TypoScriptFrontendController */
    protected $caller;

    /**
     * @var \Standardlife\SlDownload\Domain\Repository\DownloadRepository
     * @inject
     */
    protected $downloadRepository;

    /**
     * Encode download to nice url
     * @param array $params
     * @signalClass \OH\Ohmex\Url\UrlHandler
     * @signalName encodeUrl
     * @return array
     */
    public function encodeUrl(array &$params)
    {
        if ($params['args']['page']['uid'] == 111) {
            $shortUrl = null;

            $this->urlToEncode = $params['LD']['totalURL'];

            $addParams = $params['args']['addParams'];
            $paramElements = explode('&', $addParams);

            $paramSet = array();
            foreach ($paramElements as $element) {
                if ($element == '') {
                    continue;
                }

                $tmp = explode('=', $element);

                $paramSet[$tmp[0]] = $tmp[1];
            }

            if (array_key_exists('tx_sldownload_downloadprovider[shortUrl]', $paramSet)) {
                $shortUrl = $paramSet['tx_sldownload_downloadprovider[shortUrl]'];

                $this->parseUrlParameters();
                $this->setLanguage();

                $this->prepareUrlPrepend();

                $params['LD']['totalURL'] = '/dl-' . $shortUrl;


                return array(
                    'value' => true,
                );
            }
        }

        return array(
            'value' => $params,
        );
    }


}