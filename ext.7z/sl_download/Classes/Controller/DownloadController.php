<?php

namespace Standardlife\SlDownload\Controller;

use OH\Ohmex\Utility\GaUtil;
use Standardlife\SlDownload\Domain\Model\Download;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Mvc\Controller\ActionController;
use TYPO3\CMS\Extbase\Utility\DebuggerUtility;


/**
 * Class DownloadController
 * @package Standardlife\SlDownload\Controller
 */
class DownloadController extends ActionController
{

    /**
     * @var \Standardlife\SlDownload\Domain\Repository\DownloadRepository
     * @inject
     */
    protected $downloadRepository;

    public function initializeAction()
    {
        $this->contentObj = $this->configurationManager->getContentObject();
        $this->data = $this->contentObj->data;
    }

    /**
     * Provide download given by shortUrl query parameter
     * @plugin DownloadProvider
     * @noCache
     * @return string
     */
    public function indexAction()
    {
        $shortUrl = GeneralUtility::_GET('shortUrl');

        /** @var Download $download */
        $download = $this->downloadRepository->findByShortUrl($shortUrl);

        if ($download == null) {
            header('HTTP/1.0 404 Not Found');
            echo '404';
            exit(0);
        }

        $filePath = $download->getFile()->getOriginalResource()->getOriginalFile()->getForLocalProcessing();

        if (strpos(__DIR__, realpath($filePath)) !== false) {
            $protocol = (isset($_SERVER['SERVER_PROTOCOL']) ? $_SERVER['SERVER_PROTOCOL'] : 'HTTP/1.0');

            header($protocol . ' 403 Forbidden');
            die('403 | Forbidden');
        }
        $ext = pathinfo($filePath, PATHINFO_EXTENSION);


        // send google analytics pageview of file
        $googleAnalyticsId = $this->getGoogleAnalyticsId();
        if (!empty($googleAnalyticsId)) {
            $gaUtil = new GaUtil($googleAnalyticsId);
            $gaUtil->sendPageView('/dl-' . $download->getShortUrl(), $download->getName());
        }


        header('Cache-Control: no-store, no-cache, must-revalidate');
        header('Cache-Control: post-check=0, pre-check=0', false);
        header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT');
        header('Content-type: application/' . $ext);
        header('Content-Disposition: inline; filename="' . $download->getName() . '.pdf"');
        fpassthru(fopen($filePath, 'r'));


        exit(0);
    }

    /**
     * @plugin Downloads
     * @noCache
     */
    public function listAction()
    {
        $contentObj = $this->contentObj->data;

        /** @var Download[] $downloads */
        $downloads = [];
        if ($contentObj['pi_flexform'] !== null) {
            $dom = new \DOMDocument();
            $dom->loadXML($contentObj['pi_flexform']);
            $xpath = new \DOMXPath($dom);
            $idsString = $xpath->evaluate("string(//T3FlexForms/data/sheet/language/field[@index='settings.downloads']/value)");

            if ($idsString !== false && !empty($idsString)) {

                $ids = explode(',', $idsString);

                foreach ($ids as $id) {
                    /** @var Download $download */
                    $download = $this->downloadRepository->findByUid($id);
                    if ($download !== null) {
                        $downloads[] = $download;
                    }
                }
            }
        }

        $this->view->assignMultiple([
            'downloads' =>  $downloads,
            'data' => $contentObj,
        ]);
    }

    /**
     * retrieve google analytics id from website configuration
     * @return string
     */
    protected function getGoogleAnalyticsId()
    {
        $extensionConfiguration = unserialize($GLOBALS['TYPO3_CONF_VARS']['EXT']['extConf']['website']);

        $googleAnalyticsId = '';
        if (array_key_exists('googleAnalyticsId', $extensionConfiguration)) {
            $googleAnalyticsId = trim($extensionConfiguration['googleAnalyticsId']);
        }

        return $googleAnalyticsId;
    }


}