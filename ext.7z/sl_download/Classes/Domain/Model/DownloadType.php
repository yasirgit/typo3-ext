<?php

namespace Standardlife\SlDownload\Domain\Model;

use TYPO3\CMS\Extbase\DomainObject\AbstractEntity;

/**
 * Class DownloadType
 * @package Standardlife\SlDownload\Domain\Model
 *
 * @db
 */
class DownloadType extends AbstractEntity
{

    /**
     * @var string
     * @db
     */
    protected $name;

    /**
     * @return string
     */
    public function getName(): string
    {
        return $this->name;
    }

    /**
     * @param string $name
     */
    public function setName(string $name)
    {
        $this->name = $name;
    }

}