<?php

namespace Standardlife\SlDownload\Domain\Model;

use TYPO3\CMS\Extbase\DomainObject\AbstractEntity;

/**
 * Class Download
 * @package Standardlife\SlDownload\Domain\Model
 *
 * @db
 */
class Download extends AbstractEntity
{
    /**
     * @var int
     */
    protected $pid;

    /**
     * @var string
     * @db
     */
    protected $name;

    /**
     * @var string
     * @db
     */
    protected $scope;

    /**
     * @var \TYPO3\CMS\Extbase\Domain\Model\FileReference
     * @db
     */
    protected $file;

    /**
     * @var \Standardlife\SlDownload\Domain\Model\DownloadType
     * @db
     */
    protected $type;

    /**
     * @var string
     * @db
     */
    protected $shortUrl;

    /**
     * @var string
     * @db
     */
    protected $description;

    /**
     * @var \DateTime
     * @db
     */
    protected $stand;

    /**
     * @var string
     * @db
     */
    protected $druckstuecknummer;

    /**
     * @var \Standardlife\SlCrd\Domain\Model\Crd
     * @db
     */
    protected $crd;

    /**
     * @return int
     */
    public function getPid()
    {
        return $this->pid;
    }

    /**
     * @param int $pid
     */
    public function setPid($pid)
    {
        $this->pid = $pid;
    }

    /**
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * @param string $name
     */
    public function setName($name)
    {
        $this->name = $name;
    }

    /**
     * @return string
     */
    public function getScope()
    {
        return $this->scope;
    }

    /**
     * @param string $scope
     */
    public function setScope(string $scope)
    {
        $this->scope = $scope;
    }

    /**
     * @return \TYPO3\CMS\Extbase\Domain\Model\FileReference
     */
    public function getFile()
    {
        return $this->file;
    }

    /**
     * @param \TYPO3\CMS\Extbase\Domain\Model\FileReference $file
     */
    public function setFile($file)
    {
        $this->file = $file;
    }

    /**
     * @return DownloadType
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     * @param DownloadType $type
     */
    public function setType(DownloadType $type)
    {
        $this->type = $type;
    }

    /**
     * @return string
     */
    public function getShortUrl()
    {
        return $this->shortUrl;
    }

    /**
     * @param string $shortUrl
     */
    public function setShortUrl($shortUrl)
    {
        $this->shortUrl = $shortUrl;
    }

    /**
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * @param string $description
     */
    public function setDescription(string $description)
    {
        $this->description = $description;
    }

    /**
     * @return \DateTime
     */
    public function getStand()
    {
        return $this->stand;
    }

    /**
     * @param \DateTime $stand
     */
    public function setStand(\DateTime $stand)
    {
        $this->stand = $stand;
    }

    /**
     * @return string
     */
    public function getDruckstuecknummer()
    {
        return $this->druckstuecknummer;
    }

    /**
     * @param string $druckstuecknummer
     */
    public function setDruckstuecknummer(string $druckstuecknummer)
    {
        $this->druckstuecknummer = $druckstuecknummer;
    }

    /**
     * @return \Standardlife\SlCrd\Domain\Model\Crd
     */
    public function getCrd()
    {
        return $this->crd;
    }

    /**
     * @param \Standardlife\SlCrd\Domain\Model\Crd $crd
     */
    public function setCrd(\Standardlife\SlCrd\Domain\Model\Crd $crd)
    {
        $this->crd = $crd;
    }

}