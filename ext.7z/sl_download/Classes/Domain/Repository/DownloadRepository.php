<?php

namespace Standardlife\SlDownload\Domain\Repository;

use TYPO3\CMS\Extbase\Persistence\Generic\Query;
use TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings;
use TYPO3\CMS\Extbase\Persistence\Repository;

/**
 * Class DownloadRepository
 * @package Standardlife\SlDownload\Domain\Repository
 */
class DownloadRepository extends Repository
{

    public function initializeObject()
    {
        /* @var $querySettings Typo3QuerySettings */
        $querySettings = $this->objectManager->get(Typo3QuerySettings::class);
        $querySettings->setRespectStoragePage(false);

        $this->setDefaultQuerySettings($querySettings);
    }

    /**
     * @return array
     */
    public function findAll()
    {
        $query = $this->createQuery();
        $query->getQuerySettings()->setRespectStoragePage(false);

        // check SL scope
        $constraint = $q->logicalOr(
            $q->equals('scope', ''),
            $q->equals('scope', strtoupper((string)GeneralUtility::_GET('slScope')))
        );

        $q->matching($constraint);

        $result = $query->execute();

        return $result->toArray();
    }

    /**
     * Find download by parent page id
     * @param $pid
     * @return array
     */
    public function findByPid($pid)
    {
        $slScope = strtoupper((string)GeneralUtility::_GET('slScope'));

        /** @var Query $query */
        $query = $this->createQuery();
        $query->getQuerySettings()->setRespectStoragePage(false);


        $statement = 'SELECT DISTINCT dl.*
                       FROM tx_sldownload_domain_model_download dl';

        $where = 'dl.deleted = 0 AND dl.hidden = 0 AND dl.pid = ' . (int)$pid . ' AND (scope = \'\' OR scope = \'' . $slScope . '\')';

        $statement .= ' WHERE ' . $where;

        $query->statement($statement);

        $result = $query->execute()->toArray();

        return $result;
    }

    /**
     * Find download by short url
     * @param $shortUrl
     * @return object
     */
    public function findByShortUrl($shortUrl)
    {
        $query = $this->createQuery();
        $query->getQuerySettings()->setRespectStoragePage(false);


        $statement = 'SELECT DISTINCT dl.*
                       FROM tx_sldownload_domain_model_download dl';

        $where = 'dl.deleted = 0 AND dl.hidden = 0 AND dl.short_url = ' . $GLOBALS['TYPO3_DB']->fullQuoteStr($shortUrl, 'tx_sldownload_domain_model_download');

        $statement .= ' WHERE ' . $where;

        $query->statement($statement);

        $result = $query->execute()->getFirst();

        return $result;
    }

}