<?php

namespace Standardlife\SlDownload\Hooks;


use Standardlife\SlDownload\Utility\DownloadUtil;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Object\ObjectManager;


/**
 * Class DataHandlerHook
 * @package Standardlife\SlDownload\Hooks
 *
 * @hook TYPO3_CONF_VARS|SC_OPTIONS|t3lib/class.t3lib_tcemain.php|processDatamapClass
 */
class DataHandlerHook
{
    /**
     * @param $incomingFieldArray
     * @param $table
     * @param $id
     * @param $instance
     */
    public function processDatamap_preProcessFieldArray(&$incomingFieldArray, $table, $id, $instance)
    {
        /*if ($table == 'tx_sldownload_domain_model_download'){
            DebuggerUtility::var_dump($id);
            die();
        }*/

        if ($table == 'tx_sldownload_domain_model_download' && empty($incomingFieldArray['short_url']) && stripos($id, 'NEW') === 0) {

            /** @var ObjectManager $objectManager */
            $objectManager = GeneralUtility::makeInstance(ObjectManager::class);

            /** @var DownloadUtil $downloadUtil */
            $downloadUtil = $objectManager->get(DownloadUtil::class);

            $shortUrl = $downloadUtil->generateShortUrl();
            $incomingFieldArray['short_url'] = $shortUrl;
        }

    }

}