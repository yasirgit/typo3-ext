<?php

namespace Standardlife\SlDownload\Hooks;


use OH\Ohmex\Renderer\FluidTemplateRenderer;
use Standardlife\SlDownload\Domain\Repository\DownloadRepository;
use TYPO3\CMS\Backend\View\PageLayoutView;
use TYPO3\CMS\Backend\View\PageLayoutViewDrawItemHookInterface;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Object\ObjectManager;

/**
 * Class QuickAccessBackendPreview
 * @package Standardlife\SlTeaser\Hooks
 * @hook TYPO3_CONF_VARS|SC_OPTIONS|cms/layout/class.tx_cms_layout.php|tt_content_drawItem
 */
class DownloadBackendPreview implements PageLayoutViewDrawItemHookInterface
{

    protected $extensionKey = 'sl_download';

    protected $listType = 'sldownload_downloads';

    protected $backendTemplate = 'Download/ListBackend';

    protected $fileSuffix = '.html';

    protected $modelClass = QuickAccessEntry::class;

    protected $templatePath = __DIR__ . '/../../Resources/Private/Templates/';

    protected $partialPath = __DIR__ . '/../../Resources/Private/Templates/';

    protected $typeName = 'Plugin: Downloads';

    /**
     * @param PageLayoutView $parentObject
     * @param bool $drawItem
     * @param string $headerContent
     * @param string $itemContent
     * @param array $row
     */
    public function preProcess(PageLayoutView &$parentObject, &$drawItem, &$headerContent, &$itemContent, array &$row)
    {
        if ($row['CType'] == 'list' && $row['list_type'] == $this->listType) {
            $backendPreview = $this->getBackendPreview($row);

            if ($backendPreview !== null) {
                $itemContent = $backendPreview;
                $drawItem = false;
            }
        }
    }

    /**
     * @param $row
     * @return null|string
     */
    protected function getBackendPreview($row)
    {
        $path = $this->templatePath . $this->backendTemplate . $this->fileSuffix;

        if (!file_exists($path)) {
            return null;
        }

        $items = $this->getItems($row['pi_flexform']);

        $fluidTemplateRenderer = new FluidTemplateRenderer(
            realpath($this->templatePath) . '/',
            realpath($this->partialPath) . '/'
        );

        $html = $fluidTemplateRenderer->render($this->backendTemplate, [
            'data' => $row,
            'downloads' => $items,
        ]);

        return $this->getTypeHtml() . $html;
    }

    /**
     * @return string
     */
    protected function getTypeHtml()
    {
        return '<strong>' . $this->typeName . '</strong><br />';
    }

    /**
     * @param string $piFlexform
     * @return null|array
     */
    protected function getItems($piFlexform)
    {
        $dom = new \DOMDocument();
        $dom->loadXML($piFlexform);
        $xpath = new \DOMXPath($dom);
        $downloadIds = $xpath->evaluate("string(//T3FlexForms/data/sheet/language/field[@index='settings.downloads']/value)");

        $downloadIds = explode(',', $downloadIds);

        /** @var DownloadRepository $downloadRepository */
        $downloadRepository = GeneralUtility::makeInstance(ObjectManager::class)->get(DownloadRepository::class);

        $items = [];
        foreach ($downloadIds as $downloadId) {
            $download = $downloadRepository->findByUid($downloadId);
            if ($download !== null) {
                $items[] = $download;
            }
        }

        return $items;
    }

}