<?php

namespace Standardlife\SlDownload\ViewHelpers\Download;

use Standardlife\SlDownload\Domain\Model\Download;
use TYPO3\CMS\Fluid\Core\ViewHelper\AbstractViewHelper;


/**
 * Class UriViewHelper
 * @package Standardlife\SlDownload\ViewHelpers\Download
 */
class UriViewHelper extends AbstractViewHelper
{
    /**
     * Initialize arguments
     */
    public function initializeArguments()
    {
        parent::initializeArguments();

        $this->registerArgument('download', 'object', 'Download', true);
    }

    /**
     * @return string
     */
    public function render()
    {
        $download = $this->arguments['download'];

        if (!$download instanceof Download || !$download->getShortUrl()) {
            return '';
        }

        return '/dl-' . $download->getShortUrl();
    }

}
