<?php

namespace Standardlife\SlDownload\Userfunc;

/**
 * Class Tca
 * @package Standardlife\SlDownload\Userfunc
 */
class Tca
{

    /**
     * @param $table
     * @param $uid
     * @param $name
     * @param $value
     * @return string
     */
    public function renderScope($table, $uid, $name, $value)
    {
        $record = \TYPO3\CMS\Backend\Utility\BackendUtility::getRecord($table, $uid);
        $newTitle = (empty($record['scope']) ? 'DE & AT' : $record['scope']);

        return $newTitle;
    }

    /**
     * @param $table
     * @param $uid
     * @param $name
     * @param $value
     * @return string
     */
    public function renderShortUrl($table, $uid, $name, $value)
    {
        $record = \TYPO3\CMS\Backend\Utility\BackendUtility::getRecord($table, $uid);

        return '/dl-' . $record['short_url'];
    }
}