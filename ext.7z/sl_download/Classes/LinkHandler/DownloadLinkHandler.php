<?php

namespace Standardlife\SlDownload\LinkHandler;

use OH\Ohmex\LinkHandler\AbstractExtensionLinkHandler;
use Standardlife\SlDownload\Domain\Model\Download;
use Standardlife\SlDownload\Domain\Repository\DownloadRepository;
use TYPO3\CMS\Backend\Utility\BackendUtility;
use TYPO3\CMS\Core\Imaging\Icon;
use TYPO3\CMS\Core\Page\PageRenderer;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Core\Utility\MathUtility;
use TYPO3\CMS\Extbase\Utility\DebuggerUtility;

/**
 * Class DownloadLinkHandler
 * @package Standardlife\SlDownload\LinkHandler
 */
class DownloadLinkHandler extends AbstractExtensionLinkHandler
{

    /**
     * @var \Standardlife\SlDownload\Domain\Repository\DownloadRepository
     */
    protected $downloadRepository;

    /**
     * Constructor
     */
    public function __construct()
    {
        GeneralUtility::makeInstance(PageRenderer::class)->loadRequireJsModule('TYPO3/CMS/SlDownload/DownloadLinkHandler');
        parent::__construct();//'SlDownload/DownloadLinkHandler');

        $this->downloadRepository = $this->objectManager->get(DownloadRepository::class);
    }

    /**
     * Checks if this is the handler for the given link
     *
     * The handler may store this information locally for later usage.
     *
     * @param array $linkParts Link parts as returned from TypoLinkCodecService
     *
     * @return bool
     */
    public function canHandleLink(array $linkParts)
    {
        $id = $linkParts['url'];
        $params = $linkParts['params'];
        $paramElements = explode('&', $params);

        $paramSet = array();
        foreach ($paramElements as $element) {
            if ($element == '') {
                continue;
            }

            $tmp = explode('=', $element);

            $paramSet[$tmp[0]] = $tmp[1];
        }


        if (array_key_exists('tx_sldownload_downloadprovider[shortUrl]', $paramSet)) {
            $shortUrl = $paramSet['tx_sldownload_downloadprovider[shortUrl]'];

            $download = $this->downloadRepository->findByShortUrl($shortUrl);

            if ($download != null) {
                $expPageId = $download->getPid();
            } else {
                // Set to the current link page id.
                $expPageId = $id;
            }
            $this->linkParts = $linkParts;
            $this->linkParts['expPageId'] = $expPageId;
            $this->linkParts['pageid'] = $id;
            $this->linkParts['download'] = $shortUrl;
            return true;
        }

        return false;
    }

    /**
     * Format the current link for HTML output
     *
     * @return string
     */
    public function formatCurrentUrl()
    {
        $lang = $this->getLanguageService();
        $titleLen = (int)$this->getBackendUser()->uc['titleLen'];

        $id = $this->linkParts['pageid'];

        $shortUrl = $this->linkParts['download'];
        $download = $this->downloadRepository->findByShortUrl($shortUrl);

        if ($download !== null) {
            return 'Download '
            . ' \'' . htmlspecialchars(substr($download->getName(), 0, $titleLen)) . '\''
            . ' (Page-ID:' . $id . ($this->linkParts['download'] ? ', ShortUrl: ' . $shortUrl : '') . ')';
        }

        return 'Download not found';
    }


    /**
     * This displays all content elements on a page and lets you create a link to the element.
     *
     * @param int $expPageId Page uid to expand
     *
     * @return string HTML output. Returns content only if the ->expandPage value is set (pointing to a page uid to show tt_content records from ...)
     */
    public function expandPage($expPageId)
    {
        // If there is an download value (content element reference) in the element reference, then force an ID to expand:
        if (!$expPageId && isset($this->linkParts['download'])) {
            $download = $this->downloadRepository->findByShortUrl($this->linkParts['download']);

            if ($download != null) {
                $expPageId = $download->getPid();
            } else {
                // Set to the current link page id.
                $expPageId = $this->linkParts['expPageId'];
            }
        }
        // Draw the record list IF there is a page id to expand:
        if (!$expPageId || !MathUtility::canBeInterpretedAsInteger($expPageId) || !$this->getBackendUser()->isInWebMount($expPageId)) {
            return '';
        }

        // Set header:
        $out = '<h3>' . $this->getLanguageService()->getLL('contentElements') . ':</h3>';
        // Create header for listing, showing the page title/icon:
        $mainPageRec = BackendUtility::getRecordWSOL('pages', $expPageId);

        $out .= '
			<ul class="list-tree list-tree-root list-tree-root-clean">
				<li class="list-tree-control-open">
					<span class="list-tree-group">
						<span class="list-tree-icon">' . $this->iconFactory->getIconForRecord('pages', $mainPageRec, Icon::SIZE_SMALL)->render() . '</span>
						<span class="list-tree-title">' . htmlspecialchars(BackendUtility::getRecordTitle('pages', $mainPageRec, true)) . '</span>
					</span>
					<ul>
			';

        DebuggerUtility::var_dump($expPageId);

        foreach ($this->downloadRepository->findByPid($expPageId) as $download) {
            /** @var $download Download */

            $icon = ''; //$this->iconFactory->getIconForRecord('tt_content', $row, Icon::SIZE_SMALL)->render();
            $selected = '';
            if (!empty($this->linkParts) && (int)$this->linkParts['download'] === (int)$download->getShortUrl()) {
                $selected = ' class="active"';
            }

            /* download page id - plugin */
            $downloadPageId = 113;

            $out .= '
				<li' . $selected . '>
					<span class="list-tree-group">
						<span class="list-tree-icon">
							' . $icon . '
						</span>
						<span class="list-tree-title">
							<a href="#" class="t3js-pageLink" data-id="' . (int)$downloadPageId . '" data-download="' . $download->getShortUrl() . '">
								' . htmlspecialchars($download->getName()) . '
							</a>
						</span>
					</span>
				</li>
				';
        }


        $out .= '
					</ul>
				</li>
			</ul>
			';

        return $out;
    }

    /**
     * @return string[] Array of body-tag attributes
     */
    public function getBodyTagAttributes()
    {
        if (empty($this->linkParts)) {
            return [];
        }
        return [
            'data-current-link' => 'dl-' . $this->linkParts['download'],
        ];
    }

    /**
     * @param array $values Values to be checked
     *
     * @return bool Returns TRUE if the given values match the currently selected item
     */
    public function isCurrentlySelectedItem(array $values)
    {
        return !empty($this->linkParts) && (int)$this->linkParts['expPageId'] === (int)$values['pid'];
    }

}