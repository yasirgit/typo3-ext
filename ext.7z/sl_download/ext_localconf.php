<?php

if (!defined('TYPO3_MODE')) {
    die('Access denied.');
}

\HDNET\Autoloader\Loader::extLocalconf('Standardlife', $_EXTKEY);

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addPageTSConfig('<INCLUDE_TYPOSCRIPT: source="FILE:EXT:sl_download/Configuration/PageTSConfig/page.txt">');

$GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['LinkBrowser']['hooks'][] = [
'handler' => \Standardlife\SlDownload\LinkHandler\DownloadLinkHandler::class,
'before' => [], // optional
'after' => [] // optional
];


/*if (TYPO3_MODE == 'FE') {
    //$GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['tslib/class.tslib_fe.php']['checkAlternativeIdMethods-PostProc']['download'] = 'SL\\Download\\Decoder\\UrlDecoder->decodeUrl';
    //$GLOBALS['TYPO3_CONF_VARS']['EXTCONF']['realurl']['decodeSpURL_preProc'][] = 'SL\\Download\\Decoder\\UrlDecoder->decodeUrl';
}*/
