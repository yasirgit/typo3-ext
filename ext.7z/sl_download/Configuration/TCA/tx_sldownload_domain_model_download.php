<?php

use HDNET\Autoloader\Utility\ArrayUtility;
use HDNET\Autoloader\Utility\ModelUtility;

/**
 * Base TCA generation for the model SL\\Download\\Domain\\Model\\Download
 */

$base = \HDNET\Autoloader\Utility\ModelUtility::getTcaInformation(\Standardlife\SlDownload\Domain\Model\Download::class);

$custom = [
    'columns' => [
        'short_url' => [
            'config' => [
                'readOnly' => 1,
            ],
        ],

        'stand' => [
            'config' => [
                'eval' => 'date',
            ],
        ],

        'description' => [
            'config' => [
                'type' => 'text',
            ],
        ],
        
        'type' => [
            'config' => [
                'type' => 'select',
                'foreign_table' => 'tx_sldownload_domain_model_downloadtype',
                //'foreign_table_where'=>'AND tx_sldownload_domain_model_downloadtype.sys_language_uid IN (-1,0)',
                'items' => [
                    ['', 0],
                ],
            ],
        ],

        'scope' => [
            'config' => [
                'type' => 'select',
                'items' => \Standardlife\Website\Enumeration\ScopeEnum::getTcaItems(),
            ],
        ],
    ],
];

$tca = ArrayUtility::mergeRecursiveDistinct($base, $custom);

if (\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::isLoaded('sl_crd')) {
    $tca = \Standardlife\SlCrd\Utilities\CrdUtil::addTca($tca);
}

return $tca;