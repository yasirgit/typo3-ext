<?php

if (!defined('TYPO3_MODE')) {
    die('Access denied.');
}


$extPath = \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extPath($_EXTKEY);

\HDNET\Autoloader\Loader::extTables('Standardlife', $_EXTKEY);


if (TYPO3_MODE === 'BE') {
    \TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerModule(
        'Standardlife.' . $_EXTKEY,
        'tools',          // Main area
        'sl_dev',         // Name of the module
        '',             // Position of the module
        array(          // Allowed controller action combinations
            'ImportBackend' => 'index',
            'MaklernewsImport' => 'run',
        ),
        array(          // Additional configuration
            'access' => 'admin',
            'icon' => 'EXT:sl_dev/ext_icon.svg',
            'labels' => 'DEV-Import',//LLL:EXT:' . $_EXTKEY . '/Resources/Private/Language/locallang_mod.xml',
        )
    );
}