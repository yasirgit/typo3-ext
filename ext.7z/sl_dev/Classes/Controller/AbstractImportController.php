<?php

namespace Standardlife\SlDev\Controller;


use Doctrine\DBAL\Connection;
use TYPO3\CMS\Core\Database\ConnectionPool;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Mvc\Controller\ActionController;

/**
 * Class AbstractImportController
 * @package Standardlife\SlDev\Controller
 */
abstract class AbstractImportController extends ActionController
{

    /**
     * @return mixed
     */
    public abstract function runAction();

    /**
     * @return Connection
     */
    protected function getDefaultConnection()
    {
        /** @var ConnectionPool $connectionPool */
        $connectionPool = GeneralUtility::makeInstance(ConnectionPool::class);
        /** @var Connection $connection */
        $connection = $connectionPool->getConnectionByName(ConnectionPool::DEFAULT_CONNECTION_NAME);

        return $connection;
    }

    /**
     * @return Connection
     */
    protected function getDevConnection()
    {

        /** @var ConnectionPool $connectionPool */
        $connectionPool = GeneralUtility::makeInstance(ConnectionPool::class);
        /** @var Connection $connection */
        $connection = $connectionPool->getConnectionByName('Dev');

        return $connection;
    }

}