<?php

namespace Standardlife\SlDev\Controller;

use Standardlife\SlCrd\Domain\Model\Crd;
use TYPO3\CMS\Extbase\Mvc\Controller\ActionController;


/**
 * Class ImportBackendController
 * @package Standardlife\SlDev\Controller
 */
class ImportBackendController extends ActionController
{

    public function indexAction()
    {

        $importControllers = $this->getImportControllers();

        $this->view->assignMultiple([
            'importControllers' => $importControllers,
        ]);
    }

    protected function getImportControllers()
    {
        $files = scandir(__DIR__);

        $importControllers = [];

        foreach ($files as $file) {
            if (stripos($file, 'ImportController.php') !== false && $file !== 'AbstractImportController.php') {
                $importControllers[] = str_replace('Controller', '', substr($file, 0, strlen($file) - 4));
            }
        }

        return $importControllers;
    }
}