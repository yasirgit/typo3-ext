<?php

namespace Standardlife\SlDev\Controller;


use Standardlife\SlDev\Utility\StorageUtil;
use Standardlife\SlNews\Domain\Model\News;
use Standardlife\Website\Enumeration\ScopeEnum;
use TYPO3\CMS\Core\Resource\Index\FileIndexRepository;
use TYPO3\CMS\Core\Resource\ResourceFactory;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Object\ObjectManager;
use TYPO3\CMS\Extbase\Utility\DebuggerUtility;

/**
 * Class MaklernewsImportController
 * @package Standardlife\SlDev\Controller
 */
class MaklernewsImportController extends AbstractImportController
{

    const CATEGORY_STORAGE_PID = 110;
    const NEWS_STORAGE_PID = 114;
    const AUTHOR_STORAGE_PID = 115;

    const IMPORT_SOURCE_TYPE = 'maklernews';

    /**
     * @var \Standardlife\SlNews\Domain\Repository\NewsRepository
     * @inject
     */
    protected $newsRepository;

    /**
     * @var \Standardlife\SlNews\Domain\Repository\AuthorRepository
     * @inject
     */
    protected $authorRepository;

    /**
     * @var \Standardlife\Website\Domain\Repository\SysCategoryRepository
     * @inject
     */
    protected $sysCategoryRepository;

    /**
     * @var \TYPO3\CMS\Extbase\Persistence\Generic\PersistenceManager
     * @inject
     */
    protected $persistenceManager;

    /**
     * @return mixed
     */
    public function runAction()
    {
        set_time_limit(0);

        $conn = $this->getDevConnection();

        $maklerNews = $conn->fetchAll('
          SELECT m.*, cMK.kategorie, cMK.custMaklernewsKategorieID as kategorieID
          FROM custMaklernews m
          LEFT JOIN custMaklernews2Kategorie cM2K ON (cM2K.custMaklernewsID = m.custMaklernewsID)
          LEFT JOIN custMaklernewsKategorie cMK ON (cMK.custMaklernewsKategorieID = cM2K.custMaklernewsKategorieID)
          WHERE m.deleteflag = 0 AND cMK.deleteflag = 0');



        //$skip = 150;
        //$limit = 1;
        $log = [];
        foreach ($maklerNews as $singleNews) {
            /*$skip--;
            if ($skip > 0) {
                continue;
            }*/
            $existentNewsUid = $this->getUidByRow($singleNews);

            if ($existentNewsUid === false) {
                $news = $this->createNewsEntry($singleNews);
                $status = 'created';
            } else {
                $news = $this->newsRepository->findByUid($existentNewsUid);
                $status = 'existent';
            }

            if ($news !== null) {
                $log[] = [
                    'originalUid' => $row['custMaklerNewsID'],
                    'newUid' => $news->getUid(),
                    'status' => $status,
                    'title' => $news->getTitle(),
                ];
            } else {
                $log[] = [
                    'originalUid' => $row['custMaklerNewsID'],
                    'newUid' => '',
                    'status' => 'error',
                    'title' => '-- news has been null --',
                ];

            }

            /*$limit--;
            if ($limit < 1) {
                break;
            }*/
        }

        DebuggerUtility::var_dump($log);
        die();

        $this->view->assignMultiple([
            'log' => $log,
        ]);
    }

    /**
     * @param array $row
     * @return bool
     */
    protected function isExistent($row)
    {
        $conn = $this->getDefaultConnection();

        $uid = $conn->fetchColumn(
            'SELECT uid FROM tx_slnews_domain_model_news WHERE import_source_type = ? AND import_id = ?',
            [self::IMPORT_SOURCE_TYPE, $row['custMaklernewsID']],
            0
        );

        if ($uid === null) {
            return false;
        }

        return true;
    }

    /**
     * @param array $row
     * @return int|bool
     */
    protected function getUidByRow($row)
    {
        $conn = $this->getDefaultConnection();

        $uid = $conn->fetchColumn(
            'SELECT uid FROM tx_slnews_domain_model_news WHERE import_source_type = ? AND import_id = ?',
            [self::IMPORT_SOURCE_TYPE, $row['custMaklernewsID']],
            0
        );

        return $uid;
    }


    /**
     * @param array $row
     * @return News
     */
    protected function createNewsEntry($row)
    {
        /** @var ObjectManager $objectManager */
        $objectManager = GeneralUtility::makeInstance(ObjectManager::class);
        /** @var ResourceFactory $resourceFactory */
        $resourceFactory = \TYPO3\CMS\Core\Resource\ResourceFactory::getInstance();

        $defaultConnection = $this->getDefaultConnection();



        $title = $row['headline'];
        if (trim($row['subheadline']) != '') {
            $title .= ' &mdash; ' . trim($row['subheadline']);
        }

        $date = \DateTime::createFromFormat('Y.m.d', $row['datum']);


        $news = new News();
        $news->setPid(self::NEWS_STORAGE_PID);
        $news->setTitle($title);
        $news->setBodytext($row['text']);
        $news->setTeaserText($row['teasertext']);
        $news->setDate($date);
        $news->setNewsType('news');

        $showflagDE = boolval($row['showflagDE']);
        $showflagAT = boolval($row['showflagAT']);
        if ($showflagDE && !$showflagAT) {
            $scope = ScopeEnum::DE;
            $hidden = false;
        } else if ($showflagAT && !$showflagDE) {
            $scope = ScopeEnum::AT;
            $hidden = false;
        } else if ($showflagDE && $showflagAT) {
            $scope = ScopeEnum::DE_AND_AT;
            $hidden = false;
        } else {
            $scope = ScopeEnum::DE_AND_AT;
            $hidden = true;
        }
        $news->setScope($scope);
        $news->setHidden($hidden);


        // check existence of author. if not existent create an entry. set author on news.
        /*$authorName = trim($row['author']);
        $author = null;
        if (!empty($authorName)) {
            $author = $this->authorRepository->findByName($authorName);
            if ($author === false) {
                $author = new Author();
                $author->setPid(self::AUTHOR_STORAGE_PID);
                $author->setName($authorName);

                $this->authorRepository->add($author);
                $this->persistenceManager->persistAll();
            }
            $news->setAuthor($author);
        }
*/



        $havingHeadVisualImage = false;
        if (!empty(trim($row['headVisual']))) {
            $havingHeadVisualImage = true;
            $imageDir = StorageUtil::getImagesDirectory();
            $headVisualPath = $imageDir . '/maklernews/' . $row['headVisual'];

            if (file_exists($headVisualPath)) {
                $tmpHeadVisualPath = $imageDir . '/maklernews/tmp_' . $row['headVisual'];
                copy($headVisualPath, $tmpHeadVisualPath);

                $imageFile = $this->createImageFile($tmpHeadVisualPath, $row['headVisual']);

                /** @var FileIndexRepository $fileIndexRepository */
                $fileIndexRepository = $objectManager->get(FileIndexRepository::class);

                $storage = $resourceFactory->getDefaultStorage();
                $fileReference = $fileIndexRepository->findOneByStorageUidAndIdentifier($storage->getUid(), $imageFile->getIdentifier());
                $file = $resourceFactory->getFileObject($fileReference['uid']);

                /** @var \Standardlife\Website\Domain\Model\FileReference $fileRef */
                $fileRef = $objectManager->get(\Standardlife\Website\Domain\Model\FileReference::class);
                $fileRef->setFile($file);

                $news->setImage($fileRef);
            }
        }



        $havingThumbImage = false;
        if (!empty(trim($row['thumb']))) {
            $havingThumbImage = true;
            $imageDir = StorageUtil::getImagesDirectory();
            $thumbPath = $imageDir . '/maklernews/' . $row['thumb'];

            if (file_exists($thumbPath)) {
                $tmpThumbPath = $imageDir . '/maklernews/tmp_' . $row['thumb'];
                copy($thumbPath, $tmpThumbPath);

                $imageFile = $this->createImageFile($tmpThumbPath, $row['thumb']);

                /** @var FileIndexRepository $fileIndexRepository */
                $fileIndexRepository = $objectManager->get(FileIndexRepository::class);

                $storage = $resourceFactory->getDefaultStorage();
                $thumbFileReference = $fileIndexRepository->findOneByStorageUidAndIdentifier($storage->getUid(), $imageFile->getIdentifier());
                $file = $resourceFactory->getFileObject($thumbFileReference['uid']);

                /** @var \Standardlife\Website\Domain\Model\FileReference $fileRef */
                $fileRef = $objectManager->get(\Standardlife\Website\Domain\Model\FileReference::class);
                $fileRef->setFile($file);

                $news->setTileImage($fileRef);
            }
        }



        // set import information data
        $news->setImportData(json_encode($row));
        $news->setImportSourceType(self::IMPORT_SOURCE_TYPE);
        $news->setImportId($row['custMaklernewsID']);



        $this->newsRepository->add($news);
        $this->persistenceManager->persistAll();


        // update sys_file_reference because tablename is missing
        if ($havingHeadVisualImage) {
            $defaultConnection->executeUpdate(
                'UPDATE sys_file_reference 
                        SET tablenames = "tx_slnews_domain_model_news" 
                        WHERE uid_local = ? AND uid_foreign = ? AND fieldname = "image" AND cruser_id = 0 AND title IS NULL AND description IS NULL AND alternative IS NULL',
                [$fileReference['uid'], $news->getUid()]
            );
        }
        if ($havingThumbImage) {
             $defaultConnection->executeUpdate(
                'UPDATE sys_file_reference 
                        SET tablenames = "tx_slnews_domain_model_news" 
                        WHERE uid_local = ? AND uid_foreign = ? AND fieldname = "tile_image" AND cruser_id = 0 AND title IS NULL AND description IS NULL AND alternative IS NULL',
                [$thumbFileReference['uid'], $news->getUid()]
            );
        }




        // check existence of category. if not existent create category. set category on news.
        $categoryName = $row['kategorie'];
        $category = null;
        if (!empty($categoryName)) {
            $category = $this->sysCategoryRepository->findByName($categoryName);
            if ($category === false) {
                $category = $this->createCategory($categoryName);
            }

            $defaultConnection->update(
                'tx_slnews_domain_model_news',
                [
                    'category' => $category->getUid(),
                ],
                [
                    'uid' => $news->getUid(),
                ]
            );
        }



        return $news;

    }

    /**
     * @param string $path
     * @param string $fileName
     * @param bool $isThumb
     * @return \TYPO3\CMS\Core\Resource\FileInterface
     */
    protected function createImageFile($path, $fileName, $isThumb = false)
    {
        $resourceFactory = \TYPO3\CMS\Core\Resource\ResourceFactory::getInstance();
        $storage = $resourceFactory->getDefaultStorage();

        // determine storage folder
        $folder = $storage->getRootLevelFolder();
        if (!$folder->hasFolder('user_upload')) {
            $folder->createFolder('user_upload');
        }
        $folder = $folder->getSubfolder('user_upload');

        if (!$folder->hasFolder('news')) {
            $folder->createFolder('news');
        }
        $folder = $folder->getSubfolder('news');

        if (!$folder->hasFolder('maklernews')) {
            $folder->createFolder('maklernews');
        }
        $folder = $folder->getSubfolder('maklernews');

        if ($isThumb) {
            if (!$folder->hasFolder('thumb')) {
                $folder->createFolder('thumb');
            }
            $folder = $folder->getSubfolder('thumb');
        } else {
            if (!$folder->hasFolder('visual')) {
                $folder->createFolder('visual');
            }
            $folder = $folder->getSubfolder('visual');
        }

        $newFile = $storage->addFile(
            $path,
            $folder,
            $fileName
        );

        return $newFile;
    }


    /**
     * @param $categoryName
     * @return object
     */
    protected function createCategory($categoryName)
    {
        $conn = $this->getDefaultConnection();
        $result = $conn->insert(
            'sys_category',
            [
                'pid' => self::CATEGORY_STORAGE_PID,
                'tstamp' => time(),
                'crdate' => time(),
                'title' => $categoryName,
                'parent' => 0
            ]
        );
        $id = $conn->lastInsertId();

        DebuggerUtility::var_dump($id);
        $category = $this->sysCategoryRepository->findByUid($id);

        DebuggerUtility::var_dump($category);

        return $category;
    }

}