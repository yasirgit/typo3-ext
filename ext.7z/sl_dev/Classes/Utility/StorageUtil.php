<?php

namespace Standardlife\SlDev\Utility;

/**
 * Class StorageUtil
 * @package Standardlife\SlDev\Utility
 */
class StorageUtil
{

    protected static $directory = __DIR__ . '/../../data';

    /**
     * @return bool|string
     */
    public static function getFilesDirectory()
    {
        return realpath(self::$directory . '/files');
    }

    /**
     * @return bool|string
     */
    public static function getImagesDirectory()
    {
        return realpath(self::$directory . '/images');
    }

}