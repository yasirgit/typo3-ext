<?php

use HDNET\Autoloader\Utility\ArrayUtility;
use HDNET\Autoloader\Utility\ModelUtility;
use Standardlife\SlCrd\Domain\Model\Crd;

// return (function () {

    $base = ModelUtility::getTcaInformation(Crd::class);
    
    $custom = [
        'columns' => [
            'crd_type' => [
                'config' => [
                    'type' => 'select',
                    'foreign_table' => 'tx_slcrd_domain_model_crdtype',
                    'foreign_table_where'=>'AND tx_slcrd_domain_model_crdtype.sys_language_uid IN (-1,0)',
                    'items' => [
                        ['', -1],
                    ],
                    'eval' => 'required'
                ],
            ],

            'owner' => [
                'config' => [
                    'type' => 'select',
                    'foreign_table' => 'be_users',
                    'items' => [
                        ['', -1],
                    ],
                    'eval' => 'required'
                ],
            ],

            'last_check' => [
                'config' => [
                    'eval' => 'date,required',
                ],
            ],
        ],
    
        'palettes' => [
            'crd' => [
                'crd_type, owner, last_check, comment, mar_comms',
            ],
        ],
    ];
    
    return ArrayUtility::mergeRecursiveDistinct($base, $custom);

// })();