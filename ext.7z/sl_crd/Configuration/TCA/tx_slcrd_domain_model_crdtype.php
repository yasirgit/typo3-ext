<?php

use HDNET\Autoloader\Utility\ArrayUtility;
use HDNET\Autoloader\Utility\ModelUtility;
use Standardlife\SlCrd\Domain\Model\CrdType;

// return (function () {

    $base = ModelUtility::getTcaInformation(CrdType::class);

    $custom = array();

    return ArrayUtility::mergeRecursiveDistinct($base, $custom);

// })();