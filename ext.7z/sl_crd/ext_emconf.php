<?php
/**
 * $EM_CONF
 *
 * @category Extension
 * @package  Ohmex
 * @author   Tito Duarte
 */

/** @var $_EXTKEY string */
$EM_CONF[$_EXTKEY] = [
    'title'       => 'Standardlife CRD',
    'description' => '',
    'constraints' => [
        'depends' => [
            'typo3' => '8.0.0-8.99.99',
            'autoloader' => '1.11.1-9.9.9',
            'fluid_styled_content' => ''
        ],
    ],
    'clearCacheOnLoad' => true
];