<?php

if (!defined('TYPO3_MODE')) {
    die('Access denied.');
}

\HDNET\Autoloader\Loader::extTables('Standardlife', $_EXTKEY);

if (TYPO3_MODE === 'BE') {
    \TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerModule(
        'Standardlife.' . $_EXTKEY,
        'tools',          // Main area
        'crd',         // Name of the module
        '',             // Position of the module
        array(          // Allowed controller action combinations
            'CrdBackend' => 'index,dip',
            'DipBackend' => 'index,create,getFile',
        ),
        array(          // Additional configuration
            'access' => 'user,group',
            'icon' => 'EXT:sl_crd/ext_icon.svg',
            'labels' => 'CRD',//LLL:EXT:' . $_EXTKEY . '/Resources/Private/Language/locallang_mod.xml',
        )
    );
}