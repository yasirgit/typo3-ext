<?php

namespace Standardlife\SlCrd\Controller;

use Standardlife\SlCrd\Domain\Model\Crd;
use TYPO3\CMS\Extbase\Mvc\Controller\ActionController;


/**
 * Class CrdBackendController
 * @package Standardlife\SlCrd\Controller
 */
class CrdBackendController extends ActionController
{

    /**
     * @var \Standardlife\SlCrd\Domain\Repository\CrdRepository
     * @inject
     */
    protected $crdRepository;

    /**
     * List all CRD entries
     */
    public function indexAction()
    {
        /** @var Crd[] $items */
        $items = $this->crdRepository->findAllOrdered();

        foreach ($items as &$crd) {
            try {
                $crd->setItem($this->crdRepository->findEntry($crd->getForeignTableName(), $crd->getForeignUid()));
            } catch (\Exception $ex) {

            }
        }

        //DebuggerUtility::var_dump($items);die();

        $this->view->assignMultiple([
            'items' => $items,
            'menu' => $this->createMenu('index'),
        ]);
    }

    /**
     * Show DIP screen
     */
    public function dipAction()
    {
        $this->view->assignMultiple([
            'menu' => $this->createMenu('dip'),
        ]);
    }

    /**
     * Create values for dropdown menu
     * @param $action
     * @return array
     */
    protected function createMenu($action)
    {
        $uriBuilder = $this->controllerContext->getUriBuilder();

        $pagesUrl = $uriBuilder->reset()->uriFor(
            'index',
            ['extension' => ['key' => 'sl_crd']],
            'CrdBackend'
        );
        $dipUrl = $uriBuilder->reset()->uriFor(
            'dip',
            ['extension' => ['key' => 'sl_crd']],
            'CrdBackend'
        );

        $menu = [
            'label' => '',
            'identifier' => 'crd_menu',
            'menuItems' => [
                [
                    'title' => 'Seiten',
                    'href' => $pagesUrl,
                    'active' => ($action === 'index'),
                ],
                [
                    'title' => 'Digital Inventory Process (DIP)',
                    'href' => $dipUrl,
                    'active' => ($action === 'dip'),
                ],
            ],
        ];

        return $menu;
    }

}