<?php

namespace Standardlife\SlCrd\Controller;


use Standardlife\SlCrd\Generator\DipGenerator;
use TYPO3\CMS\Core\Core\Bootstrap;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Mvc\Controller\ActionController;

use TYPO3\CMS\Frontend\ContentObject\ContentObjectRenderer;
use TYPO3\CMS\Frontend\Controller\TypoScriptFrontendController;
use TYPO3\CMS\Frontend\Utility\EidUtility;

/**
 * Class DipBackendController
 * @package Standardlife\SlCrd\Controller
 */
class DipBackendController extends ActionController
{

    /**
     * Create new DIP
     */
    public function createAction()
    {
        $this->initTsfe();

        $dipGenerator = new DipGenerator($this->uriBuilder);
        $filename = $dipGenerator->createDip();

        $this->view->assignMultiple([
            'filename' => $filename,
            'menu' => $this->createMenu('dip'),
        ]);
    }

    /**
     * Deliver requested DIP file
     */
    public function getFileAction()
    {
        $this->initTsfe();

        $filename = $this->request->getArgument('filename');

        $dipGenerator = new DipGenerator($this->uriBuilder);

        if (!file_exists($dipGenerator->getDirectory() . $filename)) {
            return;
        }

        // Redirect output to a client’s web browser (Excel2007)
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="' . $filename . '"');
        header('Cache-Control: max-age=0');
        // If you're serving to IE 9, then the following may be needed
        //header('Cache-Control: max-age=1');
        // If you're serving to IE over SSL, then the following may be needed
        header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
        header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
        header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
        header ('Pragma: public'); // HTTP/1.0


        $fh = fopen($dipGenerator->getDirectory() . $filename, 'rb');
        fpassthru($fh);
        exit;
    }

    /**
     * initialize TSFE in backend for realurl nice url generation
     */
    protected function initTsfe()
    {
        // init environment
        $GLOBALS['TSFE'] = GeneralUtility::makeInstance(
            TypoScriptFrontendController::class,
            $GLOBALS['TYPO3_CONF_VARS'],
            null,
            0
        );
        EidUtility::initLanguage();
        $GLOBALS['TSFE']->initFEuser();
        $GLOBALS['TSFE']->initUserGroups();
        EidUtility::initTCA();
        $GLOBALS['TSFE']->determineId();
        Bootstrap::getInstance()->loadBaseTca();
        $GLOBALS['TSFE']->initTemplate();
        $GLOBALS['TSFE']->getConfigArray();
        $GLOBALS['TSFE']->cObj = GeneralUtility::makeInstance(ContentObjectRenderer::class);
        $GLOBALS['TSFE']->settingLanguage();
        $GLOBALS['TSFE']->settingLocale();

        $GLOBALS['TSFE']->config['tx_realurl_enable'] = true;
        if (stripos($GLOBALS['TSFE']->config['mainScript'], '/') !== 0) {
            $GLOBALS['TSFE']->config['mainScript'] = '/' . $GLOBALS['TSFE']->config['mainScript'];
        }
    }

    /**
     * Create values for dropdown menu
     * @param string $action
     * @return array
     */
    protected function createMenu($action)
    {
        $uriBuilder = $this->controllerContext->getUriBuilder();

        $pagesUrl = $uriBuilder->reset()->uriFor(
            'index',
            ['extension' => ['key' => 'sl_crd']],
            'CrdBackend'
        );
        $dipUrl = $uriBuilder->reset()->uriFor(
            'dip',
            ['extension' => ['key' => 'sl_crd']],
            'CrdBackend'
        );

        $menu = [
            'label' => '',
            'identifier' => 'crd_menu',
            'menuItems' => [
                [
                    'title' => 'Seiten',
                    'href' => $pagesUrl,
                    'active' => ($action === 'index'),
                ],
                [
                    'title' => 'Digital Inventory Process (DIP)',
                    'href' => $dipUrl,
                    'active' => ($action === 'dip'),
                ],
            ],
        ];

        return $menu;
    }
}