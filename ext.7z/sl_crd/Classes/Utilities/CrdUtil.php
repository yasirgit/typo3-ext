<?php

namespace Standardlife\SlCrd\Utilities;


use HDNET\Autoloader\Utility\ArrayUtility;

/**
 * Class CrdUtil
 * @package Standardlife\SlCrd\Utilities
 */
class CrdUtil
{

    /**
     * @param $customTca
     * @return mixed
     */
    public static function addTca($customTca)
    {
        $crdTypeColumnConfig = [
            'config' => [
                'type' => 'inline',
                'foreign_table' => 'tx_slcrd_domain_model_crd',
                'foreign_types' => array(
                    '1' => array(
                        'showitem' => 'crd_type, owner, last_check, extended_until, comment, mar_comms'
                    ),
                ),
                'foreign_field' => 'foreign_uid',
                'foreign_table_field' => 'foreign_table_name',
                'minitems' => 0, // for go live: 1,
                'maxitems' => 1,
                'appearance' => [
                    'collapseAll' => 0,
                    'expandSingle' => 1,
                    'levelLinksPosition' => 'top',
                    'showSynchronizationLink' => 0,
                    'showPossibleLocalizationRecords' => 0,
                    'showAllLocalizationLink' => 0,
                    'useSortable' => 0,

                    'enabledControls' => [
                        'info' => 0,
                        'new' => 1,
                        'dragdrop' => 0,
                        'sort' => 0,
                        'hide' => 0,
                        'delete' => 0,
                        'localize' => 0,
                    ],
                ],
                'behaviour' => [
                    'localizeChildrenAtParentLocalization' => 1,
                ],
            ],
        ];

        $customTca['columns']['crd'] = ArrayUtility::mergeRecursiveDistinct($customTca['columns']['crd'], $crdTypeColumnConfig);

        $customTca['types']['1']['showitem'] = str_replace(',crd', '', $customTca['types']['1']['showitem']);
        $customTca['types']['1']['showitem'] = '--div--;General;general,' . $customTca['types']['1']['showitem'];
        $customTca['types']['1']['showitem'] .= ',--div--;CRD;crd-tab,crd';

        return $customTca;
    }

}