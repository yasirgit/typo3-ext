<?php

namespace Standardlife\SlCrd\Generator;

use PHPExcel_IOFactory;
use PHPExcel_Style_Border;
use PHPExcel_Style_Fill;
use Standardlife\Website\Domain\Model\Pages;
use Standardlife\Website\Domain\Repository\PagesRepository;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Mvc\Web\Routing\UriBuilder;
use TYPO3\CMS\Extbase\Object\ObjectManager;
use TYPO3\CMS\Frontend\Page\PageRepository;

/**
 * Class DipGenerator
 * @package Standardlife\SlCrd\Generator
 */
class DipGenerator
{

    /** @var \PHPExcel */
    protected $excel;

    /** @var PagesRepository */
    protected $pagesRepository;

    /** @var int */
    protected $level = 0;
    /** @var int */
    protected $rowNr = 0;

    /** @var Pages[] */
    protected $pagesTree;

    /** @var UriBuilder */
    protected $uriBuilder;

    /** @var string */
    protected $directory;

    /**
     * DipGenerator constructor.
     * @param UriBuilder $uriBuilder
     */
    public function __construct(UriBuilder $uriBuilder)
    {
        $this->uriBuilder = $uriBuilder;

        $objectManager = GeneralUtility::makeInstance(ObjectManager::class);
        $this->pagesRepository = $objectManager->get(PagesRepository::class);

        $this->directory = __DIR__ . '/../../Resources/Private/reports/';

        $this->cleanUpDirectory();
    }

    /**
     * Generate report file
     * @return string
     */
    public function createDip()
    {
        $this->pagesTree = $this->createPagesTree();

        $this->excel = new \PHPExcel();
        $this->setProperties();
        $this->createSheets();
        $this->setExcelData();

        $filename = 'sl_dip_' . date('Y-m-d_H-i-s') . '.xlsx';
        $this->writeExcel($filename);

        return $filename;
    }

    /**
     * write out excel to report directory
     * @param $filename
     */
    protected function writeExcel($filename)
    {
        // Set active sheet index to the first sheet, so Excel opens this as the first sheet
        $this->excel->setActiveSheetIndex(0);
        $objWriter = PHPExcel_IOFactory::createWriter($this->excel, 'Excel2007');
        $objWriter->save($this->directory . $filename);
    }

    /**
     * set excel file properties
     */
    protected function setProperties()
    {
        $this->excel->getProperties()
            ->setTitle('Digital Inventory Process')
            ->setSubject('Digital Inventory Process')
            ->setDescription('Digital Inventory Process')
            ->setKeywords('')
            ->setCategory('');
    }

    /**
     * create excel sheets
     */
    protected function createSheets()
    {
        /*$this->excel->setActiveSheetIndex(0)->setTitle('Page Breakdown');
        $this->excel->getActiveSheet()->setShowGridlines(false);
        $this->excel->createSheet(NULL);*/
        $this->excel->setActiveSheetIndex(0)->setTitle('Page Inventory');
        $this->excel->getActiveSheet()->setShowGridlines(false);
        $this->excel->createSheet(NULL);
        $this->excel->setActiveSheetIndex(1)->setTitle('Downloads');
        $this->excel->getActiveSheet()->setShowGridlines(false);
    }

    /**
     * set report data into excel
     */
    protected function setExcelData()
    {
        //$this->setExcelPageBreakdown();
        $this->setExcelPageInventory();
        //$this->setExcelDownloads();
    }

    /**
     * Set page breakdown headers
     * @return bool
     */
    protected function setExcelPageBreakdown()
    {
        //sheet 0: page breakdown
        $this->level = 0;

        $this->excel->setActiveSheetIndex(0);

        $headerArr = [
            'A' => 'Nr.',
            'B' => 'Headline',
            'H' => 'Type',
            'I' => 'CRD-Owner',
            'J' => 'MarComms',
            'K' => 'CRD-Kategorie',
            'L' => utf8_decode('Letzte Prüfung'),
            'M' => utf8_decode('Tage b. Prüfung'),
            'N' => utf8_decode('verlängert bis'),
            'O' => 'Kommentar',
            'P' => 'Page-ID',
            'Q' => 'URL',
            'R' => 'URL Weiterleitung',
        ];

        $this->setExcelHeaderLineContents($headerArr);
        $this->setContentExcelRec($this->pagesTree);

        foreach (range('H', 'N') as $columnID) {
            $this->excel->getActiveSheet()->getColumnDimension($columnID)
                ->setAutoSize(true);
        }

        foreach (range('P', 'R') as $columnID) {
            $this->excel->getActiveSheet()->getColumnDimension($columnID)
                ->setAutoSize(true);
        }

        $this->excel->getActiveSheet()->freezePane('A2');
        return true;
    }

    /**
     * Fill excel sheet
     *
     * @param Pages[] $pagesTreeArr
     * @param string $nrStr
     */
    public function setContentExcelRec($pagesTreeArr = [], $nrStr = '')
    {
        $this->level++;

        if ($this->level > 100) {
            die('Too much recursion!');
        }
        $i = 0;
        foreach ($pagesTreeArr as $leaf) {

            $i++;
            $this->rowNr++;
            $startRow = $this->rowNr;
            $page_id = $leaf->getUid();
            //chr(160) -
            $nrStrNew = $nrStr . str_pad($i, 2, '0', STR_PAD_LEFT) . '.';
            $this->setExcelCellValue('A' . $this->rowNr, $nrStrNew . chr(160));

            //1.ebene B, 2.C etc.
            $letter = chr(65 + $this->level);
            $page = $leaf;//$this->contentObj->pagesDataArr[$page_id];
            $this->setExcelCellValue($letter . $this->rowNr, utf8_decode((trim($page->getNavTitle()) !== '' ? $page->getNavTitle() : $page->getTitle())));

            //setAutoSize(true);
            //if ($leaf['show']) {
            $uri = $this->uriBuilder
                ->reset()
                ->setCreateAbsoluteUri(true)
                ->setTargetPageUid($page->getUid())
                ->buildFrontendUri();

                $this->setExcelCellValue('Q' . $this->rowNr, $uri);
                $type = 'Page';
            /*} elseif ($page['url']) {
                $type = $page['showflag'] ? 'Weiterleitung' : 'Ausgeblendet (Weiterleitung)';
                $this->setExcelCellValue('R' . $this->rowNr, $page['url']);
            } else {
                $type = 'Webseite ausgeblendet';
            }*/

            //$this->setCrdExcel($page, $this->rowNr);

            $this->setExcelCellValue('H' . $this->rowNr, $type);

            $this->setExcelCellValue('P' . $this->rowNr, $page_id);

            //$this->setSliderExcel($page_id);

            //$this->setH3Excel($page_id);
            //$this->setH3Excel($page_id, true);

            $this->setExcelBorderForRange('A' . $startRow . ':R' . $this->rowNr, 'outline', '', '#000000');

            if (count($page->getSubPages()) > 0) {
                $this->setContentExcelRec($page->getSubPages(), $nrStrNew);
            }
        }

        $this->level--;
    }

    /**
     * Set page inventory headers
     * @return bool
     */
    protected function setExcelPageInventory()
    {
        //sheet 0: page breakdown
        $this->level = 0;

        $this->excel->setActiveSheetIndex(0);

        $headerArr = [
            'A' => 'Nr.',
            'B' => 'Headline',
            'H' => 'Type',
            'I' => 'CRD-Owner',
            'J' => 'MarComms',
            'K' => 'CRD-Kategorie',
            'L' => utf8_decode('Letzte Prüfung'),
            'M' => utf8_decode('Tage b. Prüfung'),
            'N' => utf8_decode('verlängert bis'),
            'O' => 'Kommentar',
            'P' => 'Page-ID',
            'Q' => 'URL',
            'R' => 'URL Weiterleitung',
            'S' => 'ETracker Hits 11/12.15',
            'T' => 'ETracker Hits 15',
            'U' => 'Schlagworte'
        ];

        $this->setExcelHeaderLineContents($headerArr);
        $this->setSitemapExcelRec($this->pagesTree);

        //$this->setBorderForRange('A'.$startRow.':H'.$this->rowNr, 'outline', '', '#000000');


        foreach (range('H', 'N') as $columnID) {
            $this->excel->getActiveSheet()->getColumnDimension($columnID)
                ->setAutoSize(true);
        }

        foreach (range('P', 'R') as $columnID) {
            $this->excel->getActiveSheet()->getColumnDimension($columnID)
                ->setAutoSize(true);
        }
        $this->excel->getActiveSheet()->freezePane('A2');
        return true;
    }

    /**
     * Fill excel sheet with sitemap data
     *
     * @param Pages[] $pagesTreeArr
     * @param string $nrStr
     */
    public function setSitemapExcelRec($pagesTreeArr = [], $nrStr = ''){
        $this->level++;

        if($this->level > 100){
            die('Too much recursion!');
        }
        $i = 0;
        foreach($pagesTreeArr as $leaf){
            $i++;
            $this->rowNr++;
            $page_id = $leaf->getUid();

            $this->setExcelBorderForRange('A'.$this->rowNr.':R'.$this->rowNr, 'outline', '', '#000000');
            //chr(160) -
            $nrStrNew = $nrStr.str_pad($i,2,'0',STR_PAD_LEFT).'.';
            $this->setExcelCellValue('A'.$this->rowNr, $nrStrNew.chr(160));

            //1.ebene B, 2.C etc.
            $letter = chr(65+$this->level);
            $page       = $leaf;

            $this->setExcelCellValue($letter.$this->rowNr, utf8_decode((trim($page->getNavTitle()) !== '' ? $page->getNavTitle() : $page->getTitle())));

            $uri = $this->uriBuilder
                ->reset()
                ->setCreateAbsoluteUri(true)
                ->setTargetPageUid($page->getUid())
                ->buildFrontendUri();

            //if($leaf['show']){
                $this->setExcelCellValue('Q'.$this->rowNr, $uri);
                $type = 'Page';
            /*}elseif($page['url']){
                $type = $page['showflag'] ? 'Weiterleitung' : 'Ausgeblendet (Weiterleitung)';
                $this->setExcelCellValue('R'.$this->rowNr, $page['url']);
            }
            else{
                $type = 'Webseite ausgeblendet';
            }*/

            //$pageWordsStr = pageWordsExtractor::getPageWordsStr($page_id);
            $this->setExcelCellValue('H'.$this->rowNr, $type);
            $this->setExcelCellValue('P'.$this->rowNr, $page_id);
            //$this->setExcelCellValue('S'.$this->rowNr, $page['callsPeriodShort']);
            //$this->setExcelCellValue('T'.$this->rowNr, $page['callsPeriodLong']);
            //$this->setExcelCellValue('U'.$this->rowNr, $pageWordsStr);
            //$this->setCrdExcel($page, $this->rowNr);

            if(count($page->getSubPages()) > 0){
                $this->setSitemapExcelRec($page->getSubPages(), $nrStrNew);
            }

        }

        $this->level--;
    }


    /**
     * @param $headerArr
     * @return bool
     */
    protected function setExcelHeaderLineContents($headerArr)
    {
        $this->rowNr = 1;

        $letter = 'A';
        foreach ($headerArr as $letter => $title) {

            //getRGB('00FF00');
            $this->setExcelCellValue($letter . '1', $title);
            $this->excel->getActiveSheet()->getStyle($letter . '1')->getFont()->setBold(true);
            //getStartColor()->setRGB('FFFF00');

        }
        foreach (range('A', $letter) as $fillLetter) {
            $this->setExcelBgColor($fillLetter . '1', 'FFFF00');
        }

        return true;
    }

    /**
     * @param $cell
     * @param $value
     */
    protected function setExcelCellValue($cell, $value)
    {
        $value = utf8_encode($value);
        $this->excel->getActiveSheet()
            ->setCellValue($cell, $value);
    }

    /**
     * @param $range range-example: 'A1:B2'
     * @param string $border
     * @param string $borderStyle
     * @param string $color
     * @return bool
     */
    protected function setExcelBorderForRange($range, $border = 'allborders', $borderStyle = '', $color = '')
    {

        $borderStyle = $borderStyle == '' ? PHPExcel_Style_Border::BORDER_THIN : $borderStyle;
        $styleArray = [
            'borders' => [
                $border => [
                    'style' => $borderStyle,
                    'color' => [$color],
                ],
            ],
        ];

        $this->excel->getActiveSheet()->getStyle($range)->applyFromArray($styleArray);
        return true;
    }

    /**
     * @param $field
     * @param $rgb
     * @return bool
     */
    protected function setExcelBgColor($field, $rgb)
    {
        $this->excel->getActiveSheet()->getStyle($field)->getFill()
            ->applyFromArray([
                'type' => PHPExcel_Style_Fill::FILL_SOLID,
                'startcolor' => ['rgb' => $rgb],
            ]);
        return true;
    }

    /**
     * Recursively create page tree
     * @param int $pid
     * @param array $pagesTreeArr
     * @return array
     */
    protected function createPagesTree($pid = 0, $pagesTreeArr = [])
    {
        $pages = $this->pagesRepository->getSubPages($pid);
        foreach ($pages as $page) {
            $page->setSubPages($this->createPagesTree($page->getUid()));
            $pagesTreeArr[] = $page;
        }

        return $pagesTreeArr;
    }

    /**
     * remove old report files
     */
    protected function cleanUpDirectory()
    {
        $files = glob($this->directory . '*');
        $now   = time();

        foreach ($files as $file) {
            if (is_file($file)) {
                if ($now - filemtime($file) >= 60 * 60 * 24 * 2) { // 2 days
                    unlink($file);
                }
            }
        }
    }

    /**
     * @return string
     */
    public function getDirectory(): string
    {
        return $this->directory;
    }

    /**
     * @param string $directory
     */
    public function setDirectory(string $directory)
    {
        $this->directory = $directory;
    }

    /**
     * Retrieve typo3 page repository
     * @return PageRepository
     */
    protected function getPageRepository()
    {
        /** @var PageRepository $pageRepo */
        $pageRepo = $GLOBALS['TSFE']->sys_page;
        $pageRepo->init(false);

        return $pageRepo;
    }

}