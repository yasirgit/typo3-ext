<?php

namespace Standardlife\SlCrd\Domain\Repository;

use Doctrine\DBAL\Query\QueryBuilder;
use TYPO3\CMS\Core\Database\ConnectionPool;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings;
use TYPO3\CMS\Extbase\Persistence\QueryInterface;
use TYPO3\CMS\Extbase\Persistence\Repository;

/**
 * Class CrdRepository
 * @package Standardlife\Domain\Repository
 */
class CrdRepository extends Repository
{

    public function initializeObject()
    {
        /** @var $defaultQuerySettings Typo3QuerySettings */
        $defaultQuerySettings = $this->objectManager->get(Typo3QuerySettings::class);
        $defaultQuerySettings->setRespectSysLanguage(true);
        $defaultQuerySettings->setRespectStoragePage(false);
        $this->setDefaultQuerySettings($defaultQuerySettings);
    }

    /**
     * @param $foreignTableName
     * @param $foreignUid
     * @return object
     */
    public function findByForeignTableNameAndUid($foreignTableName, $foreignUid)
    {
        $q = $this->createQuery();
        $q->matching($q->logicalAnd(
            $q->equals('foreignTableName', (string)$foreignTableName),
            $q->equals('foreignUid', (int)$foreignUid)
        ));
        $q->setLimit(1);

        $result = $q->execute();

        return $result->getFirst();
    }

    /**
     * @param string $order
     * @return array
     */
    public function findAllOrdered($order = QueryInterface::ORDER_DESCENDING)
    {
        $q = $this->createQuery();

        $constraint = $q->equals('hidden', false);
        $q->matching($constraint);
        $q->setOrderings([
            'tstamp' => $order,
            'crdate' => $order,
        ]);

        $result = $q->execute();

        return $result->toArray();
    }

    /**
     * @param $tableName
     * @param $uid
     * @return null|object
     */
    public function findEntry($tableName, $uid)
    {
        if (!is_numeric($uid) || empty($tableName)) {
            return null;
        }

        try {
            /** @var QueryBuilder $q */
            $q = GeneralUtility::makeInstance(ConnectionPool::class)
                ->getQueryBuilderForTable($tableName);

            $result = $q->select('*')
                ->from($tableName)
                ->where(
                    $q->expr()->eq('uid', $q->createNamedParameter($uid, \PDO::PARAM_INT))
                )
                ->execute()
                ->fetch();

            //$q->statement('SELECT * FROM ' . $tableName . ' WHERE uid = ' . $uid);

            //$result = $q->execute()->getFirst();
        } catch (\Exception $ex) {
            return null;
        }
        return $result;
    }


}