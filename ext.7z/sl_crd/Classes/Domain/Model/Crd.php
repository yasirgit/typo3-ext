<?php

namespace Standardlife\SlCrd\Domain\Model;

use TYPO3\CMS\Extbase\DomainObject\AbstractEntity;

/**
 * Class Crd
 * @package Standardlife\SlCrd\Domain\Model
 *
 * @db
 */
class Crd extends AbstractEntity
{
    /**
     * @var \Standardlife\SlCrd\Domain\Model\CrdType
     * @db
     */
    protected $crdType;

    /**
     * @var \TYPO3\CMS\Beuser\Domain\Model\BackendUser
     * @db
     */
    protected $owner;

    /**
     * @var \DateTime
     * @db
     */
    protected $lastCheck;
    /**
     * @var int
     */
    protected $daysUntilCheck;
    /**
     * @var \DateTime
     */
    protected $extendedUntil;
    /**
     * @var string
     * @db
     */
    protected $comment;
    /**
     * @var boolean
     */
    protected $checked;
    /**
     * @var boolean
     * @db
     */
    protected $marComms;

    /**
     * @var string
     * @db
     */
    protected $foreignTableName;

    /**
     * @var string
     * @db
     */
    protected $foreignUid;

    /**
     * @var Object
     */
    protected $item;

    /**
     * @return CrdType
     */
    public function getCrdType()
    {
        return $this->crdType;
    }

    /**
     * @param CrdType $crdType
     */
    public function setCrdType($crdType)
    {
        $this->crdType = $crdType;
    }

    /**
     * @return \TYPO3\CMS\Beuser\Domain\Model\BackendUser
     */
    public function getOwner()
    {
        return $this->owner;
    }

    /**
     * @param \TYPO3\CMS\Beuser\Domain\Model\BackendUser $owner
     */
    public function setOwner($owner)
    {
        $this->owner = $owner;
    }

    /**
     * @return \DateTime
     */
    public function getLastCheck()
    {
        return $this->lastCheck;
    }

    /**
     * @param \DateTime $lastCheck
     */
    public function setLastCheck($lastCheck)
    {
        $this->lastCheck = $lastCheck;
    }

    /**
     * @return int
     */
    public function getDaysUntilCheck()
    {
        return $this->daysUntilCheck;
    }

    /**
     * @param int $daysUntilCheck
     */
    public function setDaysUntilCheck($daysUntilCheck)
    {
        $this->daysUntilCheck = $daysUntilCheck;
    }

    /**
     * @return \DateTime
     */
    public function getExtendedUntil()
    {
        return $this->extendedUntil;
    }

    /**
     * @param \DateTime $extendedUntil
     */
    public function setExtendedUntil($extendedUntil)
    {
        $this->extendedUntil = $extendedUntil;
    }

    /**
     * @return string
     */
    public function getComment()
    {
        return $this->comment;
    }

    /**
     * @param string $comment
     */
    public function setComment($comment)
    {
        $this->comment = $comment;
    }

    /**
     * @return boolean
     */
    public function isChecked()
    {
        return $this->checked;
    }

    /**
     * @param boolean $checked
     */
    public function setChecked($checked)
    {
        $this->checked = $checked;
    }

    /**
     * @return boolean
     */
    public function isMarComms()
    {
        return $this->marComms;
    }

    /**
     * @param boolean $marComms
     */
    public function setMarComms($marComms)
    {
        $this->marComms = $marComms;
    }

    /**
     * @return string
     */
    public function getForeignTableName()
    {
        return $this->foreignTableName;
    }

    /**
     * @param string $foreignTableName
     */
    public function setForeignTableName($foreignTableName)
    {
        $this->foreignTableName = $foreignTableName;
    }

    /**
     * @return string
     */
    public function getForeignUid()
    {
        return $this->foreignUid;
    }

    /**
     * @param string $foreignUid
     */
    public function setForeignUid($foreignUid)
    {
        $this->foreignUid = $foreignUid;
    }

    /**
     * @return Object
     */
    public function getItem()
    {
        return $this->item;
    }

    /**
     * @param Object $item
     */
    public function setItem($item)
    {
        $this->item = $item;
    }

}