<?php

namespace Standardlife\SlCrd\Domain\Model;

use TYPO3\CMS\Extbase\DomainObject\AbstractEntity;

/**
 * Class Crd
 * @package Standardlife\SlCrd\Domain\Model
 *
 * @db
 */
class CrdType extends AbstractEntity
{
    /**
     * @var string
     * @db
     */
    protected $name;
    /**
     * @var int
     * @db
     */
    protected $checkDays;

    /**
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * @param string $name
     */
    public function setName($name)
    {
        $this->name = $name;
    }

    /**
     * @return int
     */
    public function getCheckDays()
    {
        return $this->checkDays;
    }

    /**
     * @param int $checkDays
     */
    public function setCheckDays($checkDays)
    {
        $this->checkDays = $checkDays;
    }

}