<?php

namespace Standardlife\SlBeraterfinder\Domain\Repository;

use Doctrine\DBAL\Connection;
use Standardlife\SlBeraterfinder\Domain\Model\Berater;
use Standardlife\SlBeraterfinder\Domain\Model\GeoCacheEntry;
use TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings;
use TYPO3\CMS\Extbase\Persistence\Repository;
use TYPO3\CMS\Core\Database\ConnectionPool;
use TYPO3\CMS\Core\Utility\GeneralUtility;

/**
 * Class GeoCacheEntryRepository
 * @package Standardlife\SlBeraterfinder\Domain\Repository
 */
class GeoCacheEntryRepository extends Repository
{

    public function initializeObject()
    {
        /* @var $querySettings Typo3QuerySettings */
        $querySettings = $this->objectManager->get(Typo3QuerySettings::class);

        // don't add the pid constraint
        $querySettings->setRespectStoragePage(false);
        $querySettings->setRespectSysLanguage(false);

        $this->setDefaultQuerySettings($querySettings);
    }

    /**
     * @param $term
     * @param $country
     * @return GeoCacheEntry|null
     */
    public function findByTerm($term, $country)
    {
        $q = $this->createQuery();

        $constraints = $q->equals('term', $term);

        $q->matching($constraints);
        $q->setLimit(1);

        $result = $q->execute();

        return $result->getFirst();
    }
}