<?php

namespace Standardlife\SlBeraterfinder\Domain\Repository;

use Doctrine\DBAL\Connection;
use Standardlife\SlBeraterfinder\Domain\Model\Berater;
use TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings;
use TYPO3\CMS\Extbase\Persistence\Repository;
use TYPO3\CMS\Core\Database\ConnectionPool;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Object\ObjectManager;
use TYPO3\CMS\Extbase\Utility\DebuggerUtility;

/**
 * Class BeraterRepository
 * @package Standardlife\SlBeraterfinder\Domain\Repository
 */
class BeraterRepository extends Repository
{

    public function initializeObject()
    {
        /* @var $querySettings Typo3QuerySettings */
        $querySettings = $this->objectManager->get(Typo3QuerySettings::class);

        // don't add the pid constraint
        $querySettings->setRespectStoragePage(false);

        $this->setDefaultQuerySettings($querySettings);
    }

    /**
     * @param string $lat
     * @param string $lng
     * @param int|null $limit
     */
    public function findByLatLngRadius($lat, $lng, $limit = null)
    {
        if ($lat === null || $lng === null) {
            return [];
        }

        $cols = 'uid, COALESCE((ACOS((SIN(RADIANS(' . $lat . '))*SIN(RADIANS(latitude))) + (COS(RADIANS(' . $lat . '))*COS(RADIANS(latitude))*COS(RADIANS(longitude-(' . $lng . '))))) * 6371.0), 0) as distance';
        $table = 'tx_slberaterfinder_domain_model_berater';
        $where = 'latitude IS NOT NULL AND longitude IS NOT NULL AND hidden=0';
        $where .= ' ORDER BY distance';

        if ($limit !== null && is_int($limit)) {
            $where .= ' LIMIT ' . $limit;
        }

        /** @var ConnectionPool $connectionPool */
        $connectionPool = GeneralUtility::makeInstance(ConnectionPool::class);
        /** @var Connection $connection */
        $connection = $connectionPool->getConnectionByName(ConnectionPool::DEFAULT_CONNECTION_NAME);

        $result = $connection->fetchAll('SELECT ' . $cols . ' FROM ' . $table . ' WHERE ' . $where);


        $items = [];
        foreach ($result as $entry) {
            /** @var Berater $item */
            $item = $this->findByUid($entry['uid']);
            $item->setDistance($entry['distance']);
            $items[] = $item;
        }

        return $items;
    }

}