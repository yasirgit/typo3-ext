<?php

namespace Standardlife\SlBeraterfinder\Domain\Model;

use TYPO3\CMS\Extbase\DomainObject\AbstractEntity;

/**
 * Class GeoCacheEntry
 * @package Standardlife\SlBeraterfinder\Domain\Model
 * @db
 */
class GeoCacheEntry extends AbstractEntity
{

    /**
     * @var string
     * @db
     */
    protected $term;

    /**
     * @var string
     * @db
     */
    protected $country;

    /**
     * @var string
     * @db
     */
    protected $latitude;

    /**
     * @var string
     * @db
     */
    protected $longitude;

    /**
     * @return string
     */
    public function getTerm()
    {
        return $this->term;
    }

    /**
     * @param string $term
     */
    public function setTerm(string $term)
    {
        $this->term = $term;
    }

    /**
     * @return string
     */
    public function getCountry()
    {
        return $this->country;
    }

    /**
     * @param string $country
     */
    public function setCountry(string $country)
    {
        $this->country = $country;
    }

    /**
     * @return string
     */
    public function getLatitude()
    {
        return $this->latitude;
    }

    /**
     * @param string $latitude
     */
    public function setLatitude(string $latitude)
    {
        $this->latitude = $latitude;
    }

    /**
     * @return string
     */
    public function getLongitude()
    {
        return $this->longitude;
    }

    /**
     * @param string $longitude
     */
    public function setLongitude(string $longitude)
    {
        $this->longitude = $longitude;
    }

}