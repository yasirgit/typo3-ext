<?php

namespace Standardlife\SlBeraterfinder\Domain\Model;

use TYPO3\CMS\Extbase\DomainObject\AbstractEntity;

/**
 * Class Berater
 * @package Standardlife\SlBeraterfinder\Domain\Model
 * @db
 */
class Berater extends AbstractEntity
{
    /**
     * @var string
     * @db
     */
    protected $salutation;

    /**
     * @var string
     * @db
     */
    protected $firstname;

    /**
     * @var string
     * @db
     */
    protected $lastname;

    /**
     * @var string
     * @db
     */
    protected $scope;

    /**
     * @var string
     * @db
     */
    protected $company;

    /**
     * @var string
     * @db
     */
    protected $street;

    /**
     * @var string
     * @db
     */
    protected $zip;

    /**
     * @var string
     * @db
     */
    protected $city;

    /**
     * @var string
     * @db
     */
    protected $country;

    /**
     * @var string
     * @db
     */
    protected $phone;

    /**
     * @var string
     * @db
     */
    protected $url;

    /**
     * @var string
     * @db
     */
    protected $vermittlernummer;

    /**
     * @var string
     * @db
     */
    protected $email;

    /**
     * @var \TYPO3\CMS\Extbase\Domain\Model\FileReference
     * @db
     */
    protected $image;

    /**
     * @var string
     * @db
     */
    protected $latitude;

    /**
     * @var string
     * @db
     */
    protected $longitude;

    /**
     * @var double
     */
    protected $distance;

    /**
     * @var string
     * @db
     */
    protected $addressHash;

    /**
     * @var \Standardlife\SlCrd\Domain\Model\Crd
     * @db
     */
    protected $crd;

    /**
     * @var bool
     */
    protected $hidden = false;

    /**
     * @return string
     */
    public function getSalutation()
    {
        return $this->salutation;
    }

    /**
     * @param string $salutation
     */
    public function setSalutation($salutation)
    {
        $this->salutation = $salutation;
    }

    /**
     * @return string
     */
    public function getFirstname()
    {
        return $this->firstname;
    }

    /**
     * @param string $firstname
     */
    public function setFirstname($firstname)
    {
        $this->firstname = $firstname;
    }

    /**
     * @return string
     */
    public function getLastname()
    {
        return $this->lastname;
    }

    /**
     * @param string $lastname
     */
    public function setLastname($lastname)
    {
        $this->lastname = $lastname;
    }

    /**
     * @return string
     */
    public function getScope()
    {
        return $this->scope;
    }

    /**
     * @param string $scope
     */
    public function setScope(string $scope)
    {
        $this->scope = $scope;
    }

    /**
     * @return string
     */
    public function getCompany()
    {
        return $this->company;
    }

    /**
     * @param string $company
     */
    public function setCompany($company)
    {
        $this->company = $company;
    }

    /**
     * @return string
     */
    public function getStreet()
    {
        return $this->street;
    }

    /**
     * @param string $street
     */
    public function setStreet($street)
    {
        $this->street = $street;
    }

    /**
     * @return string
     */
    public function getZip()
    {
        return $this->zip;
    }

    /**
     * @param string $zip
     */
    public function setZip($zip)
    {
        $this->zip = $zip;
    }

    /**
     * @return string
     */
    public function getCity()
    {
        return $this->city;
    }

    /**
     * @param string $city
     */
    public function setCity($city)
    {
        $this->city = $city;
    }

    /**
     * @return string
     */
    public function getCountry(): string
    {
        return $this->country;
    }

    /**
     * @param string $country
     */
    public function setCountry(string $country)
    {
        $this->country = $country;
    }

    /**
     * @return string
     */
    public function getPhone()
    {
        return $this->phone;
    }

    /**
     * @param string $phone
     */
    public function setPhone($phone)
    {
        $this->phone = $phone;
    }

    /**
     * @return string
     */
    public function getUrl()
    {
        return $this->url;
    }

    /**
     * @param string $url
     */
    public function setUrl($url)
    {
        $this->url = $url;
    }

    /**
     * @return string
     */
    public function getVermittlernummer()
    {
        return $this->vermittlernummer;
    }

    /**
     * @param string $vermittlernummer
     */
    public function setVermittlernummer($vermittlernummer)
    {
        $this->vermittlernummer = $vermittlernummer;
    }

    /**
     * @return string
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * @param string $email
     */
    public function setEmail($email)
    {
        $this->email = $email;
    }

    /**
     * @return string
     */
    public function getLatitude()
    {
        return $this->latitude;
    }

    /**
     * @param string $latitude
     */
    public function setLatitude($latitude)
    {
        $this->latitude = $latitude;
    }

    /**
     * @return string
     */
    public function getLongitude()
    {
        return $this->longitude;
    }

    /**
     * @param string $longitude
     */
    public function setLongitude($longitude)
    {
        $this->longitude = $longitude;
    }

    /**
     * @return float
     */
    public function getDistance()
    {
        return $this->distance;
    }

    /**
     * @param float $distance
     */
    public function setDistance(float $distance)
    {
        $this->distance = $distance;
    }

    /**
     * @return \TYPO3\CMS\Extbase\Domain\Model\FileReference
     */
    public function getImage()
    {
        return $this->image;
    }

    /**
     * @param \TYPO3\CMS\Extbase\Domain\Model\FileReference $image
     */
    public function setImage($image)
    {
        $this->image = $image;
    }


    /**
     * @return \Standardlife\SlCrd\Domain\Model\Crd
     */
    public function getCrd()
    {
        return $this->crd;
    }

    /**
     * @param \Standardlife\SlCrd\Domain\Model\Crd $crd
     */
    public function setCrd($crd)
    {
        $this->crd = $crd;
    }

    /**
     * @return string
     */
    public function getAddress() {
        return $this->getStreet() . ', ' . $this->getZip() . ' ' . $this->getCity() . ', ' . $this->getCountry();
    }

    /**
     * @return string
     */
    public function getAddressHash(): string
    {
        return $this->addressHash;
    }

    /**
     * @param string $addressHash
     */
    public function setAddressHash(string $addressHash)
    {
        $this->addressHash = $addressHash;
    }

    /**
     * @return bool
     */
    public function isHidden()
    {
        return $this->hidden;
    }

    /**
     * @param bool $hidden
     */
    public function setHidden(bool $hidden)
    {
        $this->hidden = $hidden;
    }

}