<?php

namespace Standardlife\SlBeraterfinder\Controller;


use TYPO3\CMS\Extbase\Mvc\Controller\ActionController;
use Standardlife\SlBeraterfinder\Domain\Repository\BeraterRepository;
use Standardlife\SlBeraterfinder\Service\GoogleMapsGeoDataService;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Object\ObjectManager;
use TYPO3\CMS\Extbase\Utility\DebuggerUtility;

/**
 * Class BeraterfinderTileController
 * @package Standardlife\SlBeraterfinder\Controller
 */
class BeraterfinderTileController extends ActionController
{

    /**
     * @plugin BeraterfinderTile
     * @noCache
     */
    public function indexAction()
    {
        $searchTerm = GeneralUtility::_GET('q');

        $beraterfinderPageUid = $this->getBereaterfinderPageUid();


        $this->view->assignMultiple([
            'searchTerm' => $searchTerm,
            'beraterfinderPageUid' => $beraterfinderPageUid,
        ]);
    }


    /**
     * Retrieve page uid of beraterfinder search result page
     * @return int
     */
    protected function getBereaterfinderPageUid()
    {
        $extensionConfiguration = unserialize($GLOBALS['TYPO3_CONF_VARS']['EXT']['extConf']['sl_beraterfinder']);

        $pageUid = null;
        if (array_key_exists('pageUid', $extensionConfiguration)) {
            $pageUid = $extensionConfiguration['pageUid'];
        }

        return $pageUid;
    }

}