<?php

namespace Standardlife\SlBeraterfinder\Controller;


use TYPO3\CMS\Extbase\Mvc\Controller\ActionController;
use Standardlife\SlBeraterfinder\Domain\Repository\BeraterRepository;
use Standardlife\SlBeraterfinder\Service\GoogleMapsGeoDataService;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Object\ObjectManager;
use TYPO3\CMS\Extbase\Utility\DebuggerUtility;

/**
 * Class BeraterfinderController
 * @package Standardlife\SlBeraterfinder\Controller
 */
class BeraterfinderController extends ActionController
{

    /**
     * @plugin Beraterfinder
     * @noCache
     */
    public function indexAction()
    {
        $searchTerm = GeneralUtility::_GET('q');

        $this->view->assign('searchTerm', $searchTerm);
    }

}