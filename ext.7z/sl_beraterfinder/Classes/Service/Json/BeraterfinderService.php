<?php

namespace Standardlife\SlBeraterfinder\Service\Json;

use OH\Ohmex\Renderer\FluidTemplateRenderer;
use Standardlife\SlBeraterfinder\Domain\Model\Berater;
use Standardlife\SlBeraterfinder\Domain\Model\GeoCacheEntry;
use Standardlife\SlBeraterfinder\Domain\Repository\BeraterRepository;
use Standardlife\SlBeraterfinder\Domain\Repository\GeoCacheEntryRepository;
use Standardlife\SlBeraterfinder\Service\GoogleMapsGeoDataService;
use TYPO3\CMS\Core\SingletonInterface;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Object\ObjectManager;
use TYPO3\CMS\Extbase\Persistence\Generic\PersistenceManager;
use TYPO3\CMS\Extbase\Utility\DebuggerUtility;

/**
 * Class BeraterfinderService
 * @package Standardlife\SlBeraterfinder\Service\Json
 */
class BeraterfinderService implements SingletonInterface
{

    /** @var FluidTemplateRenderer */
    protected $fluidTemplateRenderer;

    /**
     * List rendered berater
     * @param string $searchTerm
     * @return array
     */
    public function list($searchTerm = '')
    {
        $beraterHtml = '';
        $locationsArray = [];
        $latitude = null;
        $longitude = null;

        if (!empty($searchTerm)) {
            $searchTerm = trim($searchTerm);

            $geoDataService = new GoogleMapsGeoDataService('de');

            if (is_numeric($searchTerm)) {
                $geoDataService->setZip($searchTerm);
            } else {
                $geoDataService->setCity($searchTerm);
            }

            $slScope = GeneralUtility::_GET('slScope');
            if ($slScope === 'AT') {
                $country = 'Österreich';
            } else {
                $country = 'Deutschland';
            }

            $geoDataService->setCountry($country);

            $geoCacheEntry = $this->getGeoCacheEntryRepository()->findByTerm($searchTerm, $country);
            if ($geoCacheEntry !== null) {
                $latitude = $geoCacheEntry->getLatitude();
                $longitude = $geoCacheEntry->getLongitude();
            } else {
                $hasGeoCoordinates = $geoDataService->getCoordinates() && $geoDataService->getLongitude() > 0;
                if ($hasGeoCoordinates && $geoDataService->getLongitude() === null) {
                    sleep(1);
                    $hasGeoCoordinates = $geoDataService->getCoordinates() && $geoDataService->getLongitude() > 0;
                }

                $latitude = $geoDataService->getLatitude();
                $longitude = $geoDataService->getLongitude();

                if ($hasGeoCoordinates) {
                    $geoCacheEntry = new GeoCacheEntry();
                    $geoCacheEntry->setTerm($searchTerm);
                    $geoCacheEntry->setLatitude($latitude);
                    $geoCacheEntry->setLongitude($longitude);
                    $geoCacheEntry->setCountry($country);

                    $this->getGeoCacheEntryRepository()->add($geoCacheEntry);
                    $this->getPersistenceManager()->persistAll();
                }
            }

            $beraterList = $this->getBeraterfinderRepository()->findByLatLngRadius($latitude, $longitude, 10);
            $count = 0;
            foreach ($beraterList as $berater) {
                /** @var Berater $berater */
                $beraterHtml .= $this->getFluidTemplateRenderer()->render(
                    'Berater',
                    [
                        'berater' => $berater,
                        'count' => $count,
                    ]
                );

                $routeUrl = 'https://www.google.de/maps/dir//' . str_replace(' ', '+', $berater->getStreet() . ', ' . $berater->getZip() . ' ' . $berater->getCity() . ', ' . $country);

                $locationsArray[] = [
                    '<span class="name">' . $berater->getFirstname() . ' ' . $berater->getLastname() . '</span>' . $berater->getCompany(),
                    $berater->getLatitude(),
                    $berater->getLongitude(),
                    ' <p> ' . $berater->getStreet() . '<br />' . $berater->getZip() . ' ' . $berater->getCity() . '</p> <p>' .
                    (!empty(trim($berater->getPhone())) ? ' Tel. ' . $berater->getPhone() . '<br />' : '') . '<a href="' . $routeUrl . '" target="_blank">Route planen</a></p>'
                ];

                $count++;
            }
        }

        return [
            'success' => true,
            'html' => $beraterHtml,
            'locations' => $locationsArray,
            'location' => [
                'latitude' => $latitude,
                'longitude' => $longitude,
            ],
        ];
    }

    /**
     * @return BeraterRepository
     */
    protected function getBeraterfinderRepository()
    {
        /** @var ObjectManager $objectManager */
        $objectManager = GeneralUtility::makeInstance(ObjectManager::class);
        /** @var BeraterRepository $beraterfinderRepository */
        $beraterfinderRepository = $objectManager->get(BeraterRepository::class);

        return $beraterfinderRepository;
    }

    /**
     * @return GeoCacheEntryRepository
     */
    protected function getGeoCacheEntryRepository()
    {
        /** @var ObjectManager $objectManager */
        $objectManager = GeneralUtility::makeInstance(ObjectManager::class);
        /** @var GeoCacheEntryRepository $geoCacheEntryRepository */
        $geoCacheEntryRepository = $objectManager->get(GeoCacheEntryRepository::class);

        return $geoCacheEntryRepository;
    }

    /**
     * @return PersistenceManager
     */
    protected function getPersistenceManager()
    {
        /** @var ObjectManager $objectManager */
        $objectManager = GeneralUtility::makeInstance(ObjectManager::class);
        /** @var PersistenceManager $persistenceManager */
        $persistenceManager = $objectManager->get(PersistenceManager::class);

        return $persistenceManager;
    }

    /**
     * @return FluidTemplateRenderer
     */
    protected function getFluidTemplateRenderer()
    {
        if ($this->fluidTemplateRenderer === null) {
            $this->fluidTemplateRenderer = new FluidTemplateRenderer(
                __DIR__ . '/../../../Resources/Private/Partials/Beraterfinder/'
            );
        }

        return $this->fluidTemplateRenderer;
    }


}