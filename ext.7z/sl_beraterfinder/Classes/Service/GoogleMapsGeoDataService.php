<?php

namespace Standardlife\SlBeraterfinder\Service;

/**
 * Class GoogleMapsGeoData
 * @package Standardlife\SlBeraterfinder\Service
 *
 * Ask the google API about the coordinated of an address
 * This class contains only the special google API functions.
 */
class GoogleMapsGeoDataService
{

    // Google maps data
    private $GOOGLE_MAPS_URL = '';

    // Address data
    private $street = '';
    private $streetNumber = '';
    private $zip = '';
    private $city = '';
    private $country = '';

    // MinAccuracy
    private $minAccuracy = null;

    // Returned coordinates
    private $longitude = null;
    private $latitude = null;

    // Error-Handling
    private $errorMessage = '';

    // Region where the geo-coding request comes from
    private $region = '';


    /**
     * Init the google Maps API
     *
     * @param string $region in tld notation (i.e. de=Germany) where the geo-coding request comes from
     */
    public function __construct($region = 'de')
    {
        $this->region = $region;

        // Set google maps account and url. May later come from an database
        $this->GOOGLE_MAPS_URL = 'http://maps.googleapis.com/maps/api/geocode/xml';

    }

    /**
     * Set the street name
     *
     * @param string $street
     */
    public function setStreet($street)
    {
        $this->street = trim($street);
    }


    /**
     * Get the street name
     *
     * @return string
     */
    public function getStreet()
    {
        return $this->street;
    }


    /**
     * Set the street number
     *
     * @param string $streetNumber
     */
    public function setStreetNumber($streetNumber)
    {
        $this->streetNumber = trim($streetNumber);
    }


    /**
     * Get the street number
     *
     * @return string
     */
    public function getStreetNumber()
    {
        return $this->streetNumber;
    }


    /**
     * Set the zip code
     *
     * @param string $zip
     */
    public function setZip($zip)
    {
        $this->zip = trim($zip);
    }


    /**
     * Get the zip code
     *
     * @return string
     */
    public function getZip()
    {
        return $this->zip;
    }


    /**
     * Set the city name
     *
     * @param string $city
     */
    public function setCity($city)
    {
        $this->city = trim($city);
    }


    /**
     * Get the city name
     *
     * @return string
     */
    public function getCity()
    {
        return $this->city;
    }


    /**
     * Set the country (full name i.e. Deutschland, Germany, Frankreich, France)
     *
     * @param string $country
     */
    public function setCountry($country)
    {
        $this->country = trim($country);
    }


    /**
     * Get the country
     *
     * @return string
     */
    public function getCountry()
    {
        return $this->country;
    }


    /**
     * Get the region from where the geo-coding request comes from
     *
     * @return string
     */
    public function getRegion()
    {
        return $this->region;
    }


    /**
     * Set the minimal accuracy for valid hits
     *
     * @param int $minAccuracy
     */
    public function setMinAccuracy($minAccuracy)
    {
        $this->minAccuracy = $minAccuracy;
    }


    /**
     * Get the minimal accuracy for valid hits
     *
     * @return int
     */
    public function getMinAccuracy()
    {
        return $this->minAccuracy;
    }


    /**
     * Set the longitude
     *
     * @param float $longitude
     */
    public function setLongitude($longitude)
    {
        $longitude = (float)$longitude;
        if (abs($longitude) > 0) {
            $this->longitude = $longitude;
        }
    }


    /**
     * Get the longitude
     *
     * @return float
     */
    public function getLongitude()
    {
        return $this->longitude;
    }


    /**
     * Set the latitude
     *
     * @param float $latitude
     */
    public function setLatitude($latitude)
    {
        $latitude = (float)$latitude;
        if (abs($latitude) > 0) {
            $this->latitude = $latitude;
        }
    }


    /**
     * Get the latitude
     *
     * @return float
     */
    public function getLatitude()
    {
        return $this->latitude;
    }


    /**
     * Do the geo encoding for the current address
     * The coordinates are returned in the object variables
     * Set the error msg if the request was not successful
     *
     * @return bool -> true, coordinated found, false, an error occurred
     */
    protected function getCoordinatesFromAPI()
    {
        // Build a german address string
        if ($this->getStreet()) {
        $address = $this->getStreet() . ' ' . $this->getStreetNumber() . ', ';
        } else {
            $address = '';
        }

        if ($this->getZip() != '' || $this->getCity() != '') {
            $address .= $this->getZip() . ' ' . $this->getCity();
        }

        if ($this->getCountry() != '') {
            $address .= $this->getCountry();
        }

        $address = trim($address);

        // Check the google API, returns true on success
        try {
            $this->doAddressRequest($address);

            return true;
        } catch (\Exception $ex) {
            // Set the internal error message
            $this->setErrorMsg($ex->getMessage());

            return false;
        }
    }


    /**
     * Use the address string to ask google about the coordinates
     *
     * @param string $address_string
     */
    private function doAddressRequest($address_string)
    {
        // Ask the google API
        $response = $this->processHttpRequest((string)$this->GOOGLE_MAPS_URL, array(
            'address' => $address_string,
            'sensor' => 'false',
            'output' => 'xml',
            'region' => $this->getRegion()
        ));

        // Extract the coordinates and address or an error code from the answer XML
        $this->extractCoordinates($response);
    }


    /**
     * Convenience method for issuing a GET Request
     *
     * @param string $url -> base url
     * @param array $parameters -> url parameters
     *
     * @return string -> buffer of response (up to 10000 bytes)
     */
    private function processHttpRequest($url, $parameters)
    {
        if (count($parameters) > 0) {

            $query = "";

            // Build the GET request string
            foreach ($parameters as $key => $val) {

                if (strlen($query) > 0) {
                    $query = $query . "&";
                } else {
                    $query = "?";
                }

                // The google API needs UTF-8 encoded characters
                $query = $query . $key . '=' . urlencode(utf8_encode($val));
            }

            $url = $url . $query;

        }

        $handle = fopen($url, "r");

        $source = fread($handle, 10000);

        fclose($handle);

        return $source;
    }


    /**
     * Search for the current address coordinates.
     *
     * @return array|bool -> keys = longitude and latitude
     * @throws \Exception
     */
    public function getCoordinates()
    {
        // Either ZIP or City must be provided!
        if ($this->getZip() == '' && $this->getCity() == '') {
            throw new \Exception('Bitte entweder die Postleitzahl oder einen Ort angeben!');
        }

        // Do a reset on the object data before checking a new address
        $this->clearCoordinates();
        $this->clearErrors();

        // Ask the API
        $this->getCoordinatesFromAPI();

        // No data found or the address is not unique
        if ($this->getLongitude() === null || $this->getLatitude() === null) {
            $this->setErrorMsg('Die Koordinaten konnten gar nicht oder nicht eindeutig ermittelt werden.');
        }

        // Everything is OK
        if ($this->hasError() == false) {

            // Return the coordinates
            $ret_arr['longitude'] = $this->getLongitude();
            $ret_arr['latitude'] = $this->getLatitude();

            return $ret_arr;
        }

        return false;
    }


    /**
     * Clear the coordination data
     */
    private function clearCoordinates()
    {
        $this->longitude = null;
        $this->latitude = null;
    }


    /**
     * Set the internal error message
     *
     * @param string $msg
     */
    protected function setErrorMsg($msg)
    {
        $this->errorMessage = $msg;
    }


    /**
     * Clear the internal error message
     */
    protected function clearErrors()
    {
        $this->errorMessage = '';
    }


    /**
     * Get the error message
     *
     * @return string
     */
    public function getErrorMsg()
    {
        return $this->errorMessage;
    }


    /**
     * Check, if the request for the coordinates was successful
     *
     * @return bool
     */
    public function hasError()
    {
        if ($this->errorMessage == '') {
            return false;
        }

        return true;
    }

    /**
     * Extracts the coordinates or error code from a kml response
     * Set the object coordinates or the error message
     *
     * @param string $xml from a kml request
     * @throws \Exception
     *
     */
    private function extractCoordinates($xml)
    {
        if ($xml != '') {
            $xmlObj = @simplexml_load_string($xml);
            if ($xmlObj->status == 'OK') {
                $location = $xmlObj->result->geometry->location;


                $this->setLatitude($location->lat);
                $this->setLongitude($location->lng);
            } else {
                throw new \Exception('XML ungueltig! Status:' . $xmlObj->status);
            }
        }
    }

    /**
     * @param $lat1
     * @param $lon1
     * @param $lat2
     * @param $lon2
     * @return float
     */
    public static function calcCoordinatesDistance($lat1, $lon1, $lat2, $lon2)
    {

        $theta = $lon1 - $lon2;
        $dist = sin(deg2rad($lat1)) * sin(deg2rad($lat2)) + cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * cos(deg2rad($theta));
        $dist = acos($dist);
        $dist = rad2deg($dist);

        $kilometers = $dist * 60 * 1.1515 * 1.609344;

        return $kilometers;
    }


}
