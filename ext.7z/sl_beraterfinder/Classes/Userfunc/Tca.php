<?php

namespace Standardlife\SlBeraterfinder\Userfunc;


use TYPO3\CMS\Extbase\Utility\DebuggerUtility;

/**
 * Class Tca
 * @package Standardlife\SlBeraterfinder\Userfunc
 */
class Tca
{

    /**
     * @param $parameters
     * @param $parentObject
     */
    public function beraterLabel(&$parameters, $parentObject)
    {
        $record = \TYPO3\CMS\Backend\Utility\BackendUtility::getRecord($parameters['table'], $parameters['row']['uid']);
        $newTitle = $record['lastname'] . ', ' . $record['firstname'];
        //$newTitle .= ' (' . substr(strip_tags($record['impressions']), 0, 10) . '...)';
        $parameters['title'] = $newTitle;
    }

    /**
     * @param $table
     * @param $uid
     * @param $name
     * @param $value
     * @return string
     */
    public function beraterTitle($table, $uid, $name, $value)
    {
        $record = \TYPO3\CMS\Backend\Utility\BackendUtility::getRecord($table, $uid);
        $newTitle = $record['lastname'] . ', ' . $record['firstname'];

        return $newTitle;
    }
}