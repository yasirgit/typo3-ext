<?php

namespace Standardlife\SlBeraterfinder\Hooks;


use OH\Ohmex\Renderer\FluidTemplateRenderer;
use TYPO3\CMS\Backend\View\PageLayoutView;
use TYPO3\CMS\Backend\View\PageLayoutViewDrawItemHookInterface;

/**
 * Class BeraterfinderTileBackendPreview
 * @package Standardlife\SlTeaser\Hooks
 * @hook TYPO3_CONF_VARS|SC_OPTIONS|cms/layout/class.tx_cms_layout.php|tt_content_drawItem
 */
class BeraterfinderTileBackendPreview implements PageLayoutViewDrawItemHookInterface
{

    protected $extensionKey = 'sl_beraterfinder';

    protected $listType = 'slberaterfinder_beraterfindertile';

    protected $backendTemplate = 'BeraterfinderTile/TileBackend';

    protected $fileSuffix = '.html';

    protected $templatePath = __DIR__ . '/../../Resources/Private/Templates/';

    protected $partialPath = __DIR__ . '/../../Resources/Private/Partials/';

    protected $typeName = 'Plugin: Beraterfinder-Tile';

    /**
     * @param PageLayoutView $parentObject
     * @param bool $drawItem
     * @param string $headerContent
     * @param string $itemContent
     * @param array $row
     */
    public function preProcess(PageLayoutView &$parentObject, &$drawItem, &$headerContent, &$itemContent, array &$row)
    {
        if ($row['CType'] == 'list' && $row['list_type'] == $this->listType) {
            $backendPreview = $this->getBackendPreview($row);

            if ($backendPreview !== null) {
                $itemContent = $backendPreview;
                $drawItem = false;
            }
        }
    }

    /**
     * @param $row
     * @return null|string
     */
    protected function getBackendPreview($row)
    {
        $path = $this->templatePath . $this->backendTemplate . $this->fileSuffix;

        if (!file_exists($path)) {
            return null;
        }

        $fluidTemplateRenderer = new FluidTemplateRenderer(
            realpath($this->templatePath) . '/',
            realpath($this->partialPath) . '/'
        );

        $html = $fluidTemplateRenderer->render($this->backendTemplate, [
            'data' => $row,
        ]);

        return $this->getTypeHtml() . $html;
    }

    /**
     * @return string
     */
    protected function getTypeHtml()
    {
        return '<strong>' . $this->typeName . '</strong><br />';
    }

}