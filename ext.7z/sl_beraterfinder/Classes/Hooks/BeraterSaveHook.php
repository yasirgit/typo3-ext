<?php
/**
 * Created by PhpStorm.
 * User: sglot
 * Date: 17.01.2018
 * Time: 09:34
 */

namespace Standardlife\SlBeraterfinder\Hooks;


use Standardlife\SlBeraterfinder\Domain\Model\Berater;
use Standardlife\SlBeraterfinder\Domain\Repository\BeraterRepository;
use Standardlife\SlBeraterfinder\Service\GoogleMapsGeoDataService;
use TYPO3\CMS\Core\DataHandling\DataHandler;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Object\ObjectManager;
use TYPO3\CMS\Extbase\Persistence\Generic\PersistenceManager;

/**
 * Class BeraterSaveHook
 * @package Standardlife\SlBeraterfinder\Hooks
 * @hook TYPO3_CONF_VARS|SC_OPTIONS|t3lib/class.t3lib_tcemain.php|processDatamapClass
 */
class BeraterSaveHook
{

    /**
     * @param DataHandler $dataHandler
     */
    public function processDatamap_afterAllOperations(DataHandler &$dataHandler) {

        foreach ($dataHandler->datamap as $table => $data) {
            foreach ($data as $id => $fields) {

                if (strpos($id, 'NEW')) {
                    $newUid = $dataHandler->substNEWwithIDs[$id];
                } else {
                    $newUid = $id;
                }

                $objectManager = GeneralUtility::makeInstance(ObjectManager::class);
                /** @var PersistenceManager $persistenceManager */
                $persistenceManager = $objectManager->get(PersistenceManager::class);
                /** @var BeraterRepository $beraterRepository */
                $beraterRepository = $objectManager->get(BeraterRepository::class);

                $berater = $beraterRepository->findByUid($newUid);

                if ($berater instanceof Berater) {
                    $addressHash = md5($berater->getAddress() && $addressHash != $berater->getAddressHash());

                    $geoDataService = new GoogleMapsGeoDataService();
                    $geoDataService->setZip($berater->getZip());
                    $geoDataService->setCity($berater->getCity());
                    $geoDataService->setCity($berater->getCity());
                    $geoDataService->setCountry($berater->getCountry());

                    $hasGeoCoordinates = $geoDataService->getCoordinates() && $geoDataService->getLongitude() > 0;

                    if ($hasGeoCoordinates && $geoDataService->getLongitude() === null) {
                        sleep(1);
                        $hasGeoCoordinates = $geoDataService->getCoordinates() && $geoDataService->getLongitude() > 0;
                    }

                    if ($hasGeoCoordinates) {
                        $berater->setLatitude($geoDataService->getLatitude());
                        $berater->setLongitude($geoDataService->getLongitude());

                        $berater->setAddressHash($addressHash);

                        $beraterRepository->update($berater);
                        $persistenceManager->persistAll();
                    }
                }
            }
        }

    }

}