<?php

namespace Standardlife\SlBeraterfinder\Hooks;


use TYPO3\CMS\Core\Utility\ExtensionManagementUtility;

/**
 * Class BeraterfinderTileWizardItem
 * @package Standardlife\SlBeraterfinder\Hooks
 */
class BeraterfinderTileWizardItem {

    const KEY = 'slberaterfinder_beraterfindertile';

    /**
     * Processing the wizard items array
     *
     * @param array $wizardItems The wizard items
     * @return array array with wizard items
     */
    public function proc($wizardItems) {
        $wizardItems['plugins_tx_' . self::KEY] = array(
            'icon'			=> ExtensionManagementUtility::extPath('sl_beraterfinder') . 'Resources/Public/Icons/ce_wiz.gif',
            'title'			=> 'Beraterfinder Tile', //$GLOBALS['LANG']->sL('LLL:EXT:news/Resources/Private/Language/locallang_be.xlf:pi1_title'),
            'description'	=> 'Teaser element. Search for Berater.', //$GLOBALS['LANG']->sL('LLL:EXT:news/Resources/Private/Language/locallang_be.xlf:pi1_plus_wiz_description'),
            'params'		=> '&defVals[tt_content][CType]=list&defVals[tt_content][list_type]=' . self::KEY
        );

        return $wizardItems;
    }

} 