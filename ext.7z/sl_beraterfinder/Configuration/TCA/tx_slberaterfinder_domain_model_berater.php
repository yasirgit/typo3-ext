<?php

use HDNET\Autoloader\Utility\ArrayUtility;
use HDNET\Autoloader\Utility\ModelUtility;

// return (function () {

$base = ModelUtility::getTcaInformation(\Standardlife\SlBeraterfinder\Domain\Model\Berater::class);

// custom manipulation calls here
$custom = [
    'interface' => array(
        'showRecordFieldList' => 'lastname, firstname, salutation, company, vermittlernummer',
    ),
    'ctrl' => [
        'label' => 'lastname',
        'label_alt' => 'firstname',
        'label_alt_force' => true,
    ],

    'columns' => [
        'salutation' => [
            'config' => [
                'type' => 'select',
                'items' => [
                    ['Herr', 'Herr'],
                    ['Frau', 'Frau'],
                ]
            ],
        ],

        'scope' => [
            'config' => [
                'type' => 'select',
                'items' => \Standardlife\Website\Enumeration\ScopeEnum::getTcaItems(),
            ],
        ],
    ],
];

$tca = ArrayUtility::mergeRecursiveDistinct($base, $custom);

if (\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::isLoaded('sl_crd')) {
    $tca = \Standardlife\SlCrd\Utilities\CrdUtil::addTca($tca);
}

return $tca;

// })();
