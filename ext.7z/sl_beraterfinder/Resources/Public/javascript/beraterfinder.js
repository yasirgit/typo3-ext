(function(window, $, undefined) {
    var geocoder,
        map,
        $window = $(window),
        $htmlBody = $('html, body');

    //function initialize() {

    var bounds = new google.maps.LatLngBounds(
        new google.maps.LatLng(50.1210209, 8.6858255),
        new google.maps.LatLng(50.1014124, 8.7558661),
        new google.maps.LatLng(50.1325472, 8.744848),
        new google.maps.LatLng(50.1127505, 8.6623345),
        new google.maps.LatLng(50.0972382, 8.6664838),
        new google.maps.LatLng(50.0972382, 8.6664838)
    );

    /*var zoomLevel = 13;
    window.currentBp = getBreakpoint();
    if ( window.currentBp == 'tablet' || window.currentBp == 'mobile')
        zoomLevel = 4;
    if( window.currentBp == 'fullMobile')
        zoomLevel = 3;*/

    var center =  bounds.getCenter();  //Mitte aller Punkte zusammen        //{lat: 50.1211909, lng: 8.5665248};  Feste Angabe
    var mapOptions = {
        //zoom: zoomLevel,
        scrollwheel: false,
        center: center,
        mapTypeId: google.maps.MapTypeId.ROADMAP,
        mapTypeControl: false,
        scaleControl: false,
        zoomControl: false,
        streetViewControl: false,
        fullScreenControl: false
    };

    //if( $('html').attr('lang') == 'de' ){
    //Marker Data Deutsch
    var locations = [
        ['<span class="name">Thomas Mehmel Kösters</span>VPM Consulting GmbH', 50.1210209, 8.6858255, " <p> Hebelstraße 11<br />60318 Frankfurt am Main</p> <p> Tel. 069-247 512 50<br /><a href='#'>Route planen</a></p>"],
        ['<span class="name">Matthias Eichhorn</span>Versicherungs­makler Eichhorn Inh.Matthias Eichhorn e.K.', 50.1014124, 8.7558661, "<p> Luisenstr.30<br /> 63067 Offenbach am Main</p> <p> Tel. 069-98194883<br /><a href='#'>Route planen</a></p>"],
        ['<span class="name">Thomas Osthoff</span>dbfp - Deutsche Beratungs­gesellschaft für Finanzplanung GmbH', 50.1325472, 8.744848, "<p> Wächtersbacherstr. 78<br />60386 Frankfurt</p> <p> Tel. 0151-14176336<br /><a href='#'>Route planen</a></p>"],
        ['<span class="name">Niels Sanders</span>Hoesch & Partner', 50.1127505, 8.6623345, "<p> Rüsterstraße 1<br />60325 Frankfurt am Main </p> <p> Tel. 069-71707238<br /><a href='#'>Route planen</a></p>"],
        ['<span class="name">Heiko Vollmer</span>FINGENIUM private finance AG', 50.0972382, 8.6664838, "<p> Paul-Ehrlich-Straße 15<br />60596 Frankfurt am Main </p> <p><a href='#'>Route planen</a></p>"],
        ['<span class="name">Stefan Müller</span>FINGENIUM private finance AG', 50.0972382, 8.6664838, "<p> Paul-Ehrlich-Straße 15<br />60596 Frankfurt am Main </p> <p> Tel. 069-98194883<br /><a href='#'>Route planen</a></p>"],
    ];
    //}
    /*else{
        //Marker Data Englisch
        var locations = [
            ['CORESTATE Capital Holding S.A.', 49.6333225, 6.1652267, " <p> 4, rue Jean Monnet<br /> 2180 Luxembourg<br /> Luxembourg</p> <p> Phone: +352 (26) 6372 20<br /> Fax: +352 (26) 6372 45 </p>"],
            ['CORESTATE Capital Advisors GmbH', 50.1104614, 8.6539433, "<p> Friedrich-Ebert-Anlage 35-37 | Tower 185<br /> 60327 Frankfurt am Main<br /> Germany </p> <p> Phone: +49 (69) 3535 6300<br /> Fax: +49 (69) 3535 630 29 </p>"],
            ['CORESTATE Capital AG', 47.1887054, 8.5135343, "<p> Oberneuhofstra&szlig;e 3<br /> 6340 Baar<br /> Switzerland </p> <p> Phone: +41 (41) 7278 630 </p>"],
            ['CORESTATE Capital Partners GmbH', 47.3690598, 8.5370333, "<p> Bahnhofstrasse 17<br /> 8001 Z&uuml;rich<br /> Switzerland<br /> </p> <p> Phone: +41 (21) 5607 285 </p>"],
            ['CORESTATE Capital Advisors (Singapore) Pte. Ltd.', 1.2855814, 103.8500403, "<p> 4 Battery Road<br />#25-01 Bank of China Building<br /> Singapore 049908<br /> Singapore<br /> </p>"],
            ['CORESTATE Capital Advisors GmbH Sucursal en Espa&ntilde;a', 40.4509709,-3.7755116, "<p> Spanish Branch<br >Capit&aacuten Haya, n&deg;1 Planta 15<br > 28020 Madrid<br /> Spain </p> <p> Phone: +34 (91) 4176 453 </p>"],
            ['CORESTATE Capital Partners (UK) Ltd.', 51.50852,-0.1456976, "<p> 16 Berkeley Street,<br >Suite 7.06<br > London W1J 8DZ <br /> UK </p>"],
        ];
    }*/

    function initGoogleMap(){

        var infowindow = new google.maps.InfoWindow(); /* SINGLE */
        var map = new google.maps.Map(document.getElementById('googleMap'), mapOptions);
        //svg icon
        var icon = {
            path: "M32,1C20.69,1,9,9.64,9,24.09,9,39.24,30.38,60.8,31.29,61.71a1,1,0,0,0,1.41,0C33.62,60.8,55,39.24,55,24.09,55,9.64,43.31,1,32,1Zm0,31a8,8,0,1,1,8-8A8,8,0,0,1,32,32Z",
            fillColor: '#007BC3',
            fillOpacity: 1,
            anchor: new google.maps.Point(0,80),
            strokeWeight: 1,
            strokeColor: '#ffffff',
            scale: 0.6
        }

        var markers  = []; //marker array for <a> click
        var labels = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';  // Create an array of alphabetical characters used to label the markers.

        function placeMarker( loc, i ) {

            var latLng = new google.maps.LatLng( loc[1], loc[2]);
            var marker = new google.maps.Marker({
                position : latLng,
                map      : map,
                icon     : icon,
                title    : loc[0],
                label    : labels[i % labels.length]
            });


            markers.push(marker); //add to marker array for <a> click

            google.maps.event.addListener(marker, 'click', function(){
                infowindow.close(); // Close previously opened infowindow
                infowindow.setContent( "<div class='infoWindow'><p>"+ loc[0] +"</p><p>" + loc[3] + "</p></div>");
                infowindow.open(map, marker);

                //removing google styling
                /*var iwOuter = $('.gm-style-iw');
                var iwBackground = iwOuter.prev();
                iwBackground.children(':nth-child(2)').css({'display' : 'none'});
                iwBackground.children(':nth-child(4)').css({'display' : 'none'});
                iwBackground.css({'top' : '-1px !important'});
                iwBackground.children().children().children().css({
                    'background-color' : 'rgba(45, 88, 127, 0.8)',
                    'box-shadow' : 'none'
                });*/

            });
        }

        // ITERATE ALL LOCATIONS
        for(var i=0; i<locations.length; i++) {
            placeMarker( locations[i], i );
        }

        var markerCluster = new MarkerClusterer(map, markers,
            {imagePath: 'https://developers.google.com/maps/documentation/javascript/examples/markerclusterer/m'});

        //close infoWindow and allow Scrolling
        google.maps.event.addListener(map, 'click', function(event){
            this.setOptions({scrollwheel:true});
            infowindow.close(); // Close previously opened infowindow
        });

        //center to location (from <a>}
        function newLocation(id) {
            var location = locations[id];
            map.setCenter({
                lat : location[1],
                lng : location[2]
            });

            return false;
        }

        //activate marker on <a> click
        $('.location').on('click', function(e){
            e.preventDefault();

            $htmlBody.animate({ //scroll to map
                scrollTop: $('#googleMap').offset().top -150
            }, 1000);

            newLocation($(this).attr('data-location')); //center map
            google.maps.event.trigger(markers[$(this).attr('data-location')], 'click'); //open marker
        });

        map.fitBounds(bounds);

    }
    google.maps.event.addDomListener(window, 'load', initGoogleMap);





    $window.on('resize', function() {
        setTimeout(function(){
            initGoogleMap();
        }, 500);
    });

})(window, jQuery);