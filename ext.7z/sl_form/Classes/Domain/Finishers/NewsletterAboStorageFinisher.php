<?php

namespace Standardlife\SlForm\Domain\Finishers;


use TYPO3\CMS\Extbase\Utility\DebuggerUtility;
use TYPO3\CMS\Form\Domain\Finishers\AbstractFinisher;

/**
 * Class NewsletterAboStorageFinisher
 * @package Standardlife\SlForm\Domain\Finishers
 */
class NewsletterAboStorageFinisher extends AbstractFinisher
{
    protected function executeInternal()
    {
        $formValues = $this->finisherContext->getFormValues();

        DebuggerUtility::var_dump($formValues);
        die('HIER');
    }

}