<?php

namespace Standardlife\SlForm\Domain\Finishers;


use Standardlife\Website\Utilities\EncryptionUtil;

use TYPO3\CMS\Form\Domain\Finishers\SaveToDatabaseFinisher;

/**
 * Class SaveToDatabaseSecureFinisher
 * @package Standardlife\SlForm\Domain\Finishers
 */
class SaveToDatabaseSecureFinisher extends SaveToDatabaseFinisher
{

    /**
     * @param array $databaseData
     * @param string $table
     * @param int $iterationCount
     */
    protected function saveToDatabase(array $databaseData, string $table, int $iterationCount)
    {
        foreach ($databaseData as $key => &$value) {
            $value = EncryptionUtil::encrypt($databaseData);
        }

        parent::saveToDatabase($databaseData, $table, $iterationCount);
    }
}