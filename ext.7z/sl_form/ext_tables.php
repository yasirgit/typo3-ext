<?php

if (!defined('TYPO3_MODE')) {
    die('Access denied.');
}


$extPath = \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extPath($_EXTKEY);

\HDNET\Autoloader\Loader::extTables('Standardlife', $_EXTKEY);