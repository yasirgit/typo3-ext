<?php

use HDNET\Autoloader\Utility\ArrayUtility;
use HDNET\Autoloader\Utility\ModelUtility;

// return (function () {

    $base = ModelUtility::getTcaInformation(\Standardlife\SlContent\Domain\Model\ImageSlide::class);

    // custom manipulation calls here
    $custom = [
        'columns' => [
            'pre_header' => [
                'config' => [
                    'type' => 'text',
                    'rows' => '2',
                    'wrap' => 'off',
                ],
            ],
            'link' => [
                'exclude' => 1,
                'config' => [
                    'type' => 'input',
                    'renderType' => 'inputLink',
                ],
            ],
        ],
    ];

    return ArrayUtility::mergeRecursiveDistinct($base, $custom);

// })();
