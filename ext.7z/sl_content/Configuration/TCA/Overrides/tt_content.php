<?php

use HDNET\Autoloader\Utility\ArrayUtility;
use HDNET\Autoloader\Utility\ModelUtility;

$GLOBALS['TCA']['tt_content'] = ModelUtility::getTcaOverrideInformation('sl_content', 'tt_content');

// custom manipulation calls here
$custom = [
    'columns' => [

        'tx_title' => [
            'config' => [
                'type' => 'text',
                'rows' => '2',
                'wrap' => 'off',
            ],
        ],
        'tx_slider_type' => [
             'config' => [
                 'type' => 'select',
                 'items' => [
                     ['Slider', 'slider'],
                     ['Single slide teaser', 'singleSlideTeaser'],
                 ]
             ],
        ],
        'tx_image_slides' => [
            'config' => [
                'type' => 'inline',
                'foreign_table' => 'tx_slcontent_domain_model_imageslide',
                'foreign_field' => 'content_uid',
                'foreign_sortby' => 'sorting',
                'foreign_label' => 'title',
                'appearance' => [
                    'collapseAll' => 1,
                    'expandSingle' => 1,
                    'levelLinksPosition' => 'top',
                    'showSynchronizationLink' => 1,
                    'showPossibleLocalizationRecords' => 1,
                    'showAllLocalizationLink' => 1,
                    'useSortable' => 1,
                    'createNewRelationLinkTitle' => 'Add slide'
                ],
            ],
        ],

        'tx_content_image_slides' => [
            'config' => [
                'type' => 'inline',
                'foreign_table' => 'tx_slcontent_domain_model_contentimageslide',
                'foreign_field' => 'content_uid',
                'foreign_sortby' => 'sorting',
                'foreign_label' => 'title',
                'appearance' => [
                    'collapseAll' => 1,
                    'expandSingle' => 1,
                    'levelLinksPosition' => 'top',
                    'showSynchronizationLink' => 1,
                    'showPossibleLocalizationRecords' => 1,
                    'showAllLocalizationLink' => 1,
                    'useSortable' => 1,
                    'createNewRelationLinkTitle' => 'Add slide'
                ],
            ],
        ],

        'tx_categories' => [
            'config' => [
                'type' => 'select',
                'renderType' => 'selectTree',
                'size' => 10,
                //'minItems' => 1,
                //'maxItems' => 1,
                'foreign_table' => 'sys_category',
                'foreign_table_where' => ' ORDER BY sys_category.title ASC',
                'treeConfig' => [
                    'parentField' => 'parent',
                    'appearance' => [
                        'expandAll' => true,
                        'showHeader' => true,
                    ],
                ],
            ],
        ],
    ],
];

$GLOBALS['TCA']['tt_content'] = ArrayUtility::mergeRecursiveDistinct($GLOBALS['TCA']['tt_content'], $custom);
