<?php

namespace Standardlife\SlContent\ViewHelpers;


use TYPO3\CMS\Core\Resource\FileReference;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Object\ObjectManager;
use TYPO3\CMS\Extbase\Utility\DebuggerUtility;
use TYPO3\CMS\Fluid\Core\ViewHelper\AbstractViewHelper;

/**
 * Class VimeoViewHelper
 * @package Standardlife\SlContent\ViewHelpers
 */
class VimeoViewHelper extends AbstractViewHelper
{

    /** @var ObjectManager */
    protected $objectManager;

    /**
     * @var boolean
     */
    protected $escapeChildren = false;

    /**
     * @var boolean
     */
    protected $escapeOutput = false;

    /**
     * ImageViewHelper constructor.
     */
    public function __construct()
    {
        $this->objectManager = GeneralUtility::makeInstance(ObjectManager::class);
    }


    /**
     * Initialize arguments
     */
    public function initializeArguments()
    {
        parent::initializeArguments();

        $this->registerArgument('file', 'object', 'File', true);
        $this->registerArgument('idOnly', 'boolean', 'only video id', false, false);
    }

    /**
     * @return string
     */
    public function render()
    {
        $file = $this->arguments['file'];
        return $this->renderVideo($file);
    }


    /**
     * @param $file
     */
    protected function renderVideo($fileRef)
    {
        $fileRef = $fileRef->getOriginalResource();
        $resourceFactory = \TYPO3\CMS\Core\Resource\ResourceFactory::getInstance();

        if ($fileRef instanceof FileReference) {
            $orgFile = $fileRef->getOriginalFile();
        } else {
            $orgFile = $fileRef;
        }

        if ($orgFile->getProperty('mime_type') === 'video/vimeo') {
            $videoId = $orgFile->getContents();
        }

        if ((bool)$this->arguments['idOnly']) {
            return $videoId;
        }

        $url = '//www.vimeo.com/api/v2/video/'.$videoId.'.xml';

        return $url;
    }

}