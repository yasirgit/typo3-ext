<?php

namespace Standardlife\SlContent\Domain\Model\Content;


use TYPO3\CMS\Extbase\DomainObject\AbstractEntity;

/**
 * Class TeaserContent
 * @package Standardlife\SlContent\Domain\Model\Content
 * @db tt_content
 * @wizardTab common
 */
class TeaserContent extends AbstractEntity
{

    /**
     * @var string
     * @db
     */
    protected $txTitle;

    /**
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\TYPO3\CMS\Extbase\Domain\Model\FileReference>
     */
    protected $image;

    /**
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Standardlife\Website\Domain\Model\SysCategory>
     * @db
     */
    protected $txCategories;

    /**
     * @var string
     * @enableRichText
     */
    protected $bodytext;

    /**
     * @var string
     */
    protected $headerLink;

    /**
     * @return string
     */
    public function getTxTitle()
    {
        return $this->txTitle;
    }

    /**
     * @param string $txTitle
     */
    public function setTxTitle($txTitle)
    {
        $this->txTitle = $txTitle;
    }

    /**
     * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage
     */
    public function getImage()
    {
        return $this->image;
    }

    /**
     * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage $image
     */
    public function setImage($image)
    {
        $this->image = $image;
    }

    /**
     * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage
     */
    public function getTxCategories()
    {
        return $this->txCategories;
    }

    /**
     * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage $txCategories
     */
    public function setTxCategories($txCategories)
    {
        $this->txCategories = $txCategories;
    }

    /**
     * @return string
     */
    public function getBodytext()
    {
        return $this->bodytext;
    }

    /**
     * @param string $bodytext
     */
    public function setBodytext($bodytext)
    {
        $this->bodytext = $bodytext;
    }

    /**
     * @return string
     */
    public function getHeaderLink()
    {
        return $this->headerLink;
    }

    /**
     * @param string $headerLink
     */
    public function setHeaderLink($headerLink)
    {
        $this->headerLink = $headerLink;
    }

}