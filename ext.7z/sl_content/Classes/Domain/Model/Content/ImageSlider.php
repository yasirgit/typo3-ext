<?php

namespace Standardlife\SlContent\Domain\Model\Content;


use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\DomainObject\AbstractEntity;
use TYPO3\CMS\Extbase\Utility\DebuggerUtility;

/**
 * Class ImageSlider
 * @package Standardlife\SlContent\Domain\Model\Content
 * @db tt_content
 * @wizardTab common
 */
class ImageSlider extends AbstractEntity
{

    /**
     * @var string
     */
    protected $header;

    /**
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Standardlife\SlContent\Domain\Model\ImageSlide>
     * @db
     */
    protected $txImageSlides;

    /**
     * @var string
     * @db
     */
    protected $txSliderType;


    /**
     * @return string
     */
    public function getHeader()
    {
        return $this->header;
    }


    /**
     * @param string $header
     */
    public function setHeader($header)
    {
        $this->header = $header;
    }



    /**
     * @return string
     */
    public function getTxSliderType()
    {
        return $this->txSliderType;
    }

    /**
     * @param string $txSliderType
     */
    public function setTxSliderType($txSliderType)
    {
        $this->txSliderType = $txSliderType;
    }

    /**
     * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage
     */
    public function getTxImageSlides()
    {
        return $this->txImageSlides;
    }

    /**
     * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage $txImageSlides
     */
    public function setTxImageSlides($txImageSlides)
    {
        $this->txImageSlides = $txImageSlides;
    }

}