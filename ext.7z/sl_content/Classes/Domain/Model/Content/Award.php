<?php

namespace Standardlife\SlContent\Domain\Model\Content;


use TYPO3\CMS\Extbase\DomainObject\AbstractEntity;

/**
 * Class Award
 * @package Standardlife\SlContent\Domain\Model\Content
 * @db tt_content
 * @wizardTab common
 */
class Award extends AbstractEntity
{

    /**
     * @var string
     */
    protected $header;

    /**
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\TYPO3\CMS\Extbase\Domain\Model\FileReference>
     */
    protected $image;

    /**
     * @return string
     */
    public function getHeader()
    {
        return $this->header;
    }

    /**
     * @param string $header
     */
    public function setHeader($header)
    {
        $this->header = $header;
    }

    /**
     * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage
     */
    public function getImage()
    {
        return $this->image;
    }

    /**
     * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage $image
     */
    public function setImage($image)
    {
        $this->image = $image;
    }

}