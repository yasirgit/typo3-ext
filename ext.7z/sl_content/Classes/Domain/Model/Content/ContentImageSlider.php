<?php

namespace Standardlife\SlContent\Domain\Model\Content;


use TYPO3\CMS\Extbase\DomainObject\AbstractEntity;

/**
 * Class ContentImageSlider
 * @package Standardlife\SlContent\Domain\Model\Content
 * @db tt_content
 * @wizardTab common
 */
class ContentImageSlider extends AbstractEntity
{

    /**
     * @var string
     */
    protected $header;

    /**
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Standardlife\SlContent\Domain\Model\ContentImageSlide>
     * @db
     */
    protected $txContentImageSlides;

    /**
     * @return string
     */
    public function getHeader()
    {
        return $this->header;
    }

    /**
     * @param string $header
     */
    public function setHeader($header)
    {
        $this->header = $header;
    }

    /**
     * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage
     */
    public function getTxContentImageSlides()
    {
        return $this->txContentImageSlides;
    }

    /**
     * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage $txContentImageSlides
     */
    public function setTxContentImageSlides($txContentImageSlides)
    {
        $this->txContentImageSlides = $txContentImageSlides;
    }

}