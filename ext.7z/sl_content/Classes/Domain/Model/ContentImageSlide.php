<?php

namespace Standardlife\SlContent\Domain\Model;

use TYPO3\CMS\Extbase\DomainObject\AbstractEntity;

/**
 * Class ImageSlide
 * @package Standardlife\SlContent\Domain\Model
 * @db
 */
class ContentImageSlide extends AbstractEntity
{

    /**
     * @var string
     * @db
     */
    protected $title;

    /**
     * @var string
     * @db
     */
    protected $icon;

    /**
     * @var string
     * @enableRichText
     * @db
     */
    protected $text;

    /**
     * @var \TYPO3\CMS\Extbase\Domain\Model\FileReference
     * @db
     */
    protected $image;

    /**
     * @var int
     * @db
     */
    protected $contentUid;

    /**
     * @return string
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * @param string $title
     */
    public function setTitle($title)
    {
        $this->title = $title;
    }

    /**
     * @return string
     */
    public function getIcon()
    {
        return $this->icon;
    }

    /**
     * @param string $icon
     */
    public function setIcon($icon)
    {
        $this->icon = $icon;
    }

    /**
     * @return string
     */
    public function getText()
    {
        return $this->text;
    }

    /**
     * @param string $text
     */
    public function setText($text)
    {
        $this->text = $text;
    }

    /**
     * @return \TYPO3\CMS\Extbase\Domain\Model\FileReference
     */
    public function getImage()
    {
        return $this->image;
    }

    /**
     * @param \TYPO3\CMS\Extbase\Domain\Model\FileReference $image
     */
    public function setImage($image)
    {
        $this->image = $image;
    }

    /**
     * @return int
     */
    public function getContentUid()
    {
        return $this->contentUid;
    }

    /**
     * @param int $contentUid
     */
    public function setContentUid($contentUid)
    {
        $this->contentUid = $contentUid;
    }

}