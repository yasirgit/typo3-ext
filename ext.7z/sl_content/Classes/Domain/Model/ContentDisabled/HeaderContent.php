<?php

namespace Standardlife\SlContent\Domain\Model\ContentDisabled;


use TYPO3\CMS\Extbase\DomainObject\AbstractEntity;

/**
 * Class HeaderContent
 * @package Standardlife\SlContent\Domain\Model\Content
 * @db tt_content
 * @wizardTab common
 */
class HeaderContent extends AbstractEntity
{

    /**
     * @var string
     * @db
     */
    protected $txTitle;

    /**
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\TYPO3\CMS\Extbase\Domain\Model\FileReference>
     */
    protected $image;

    /**
     * @var string
     * @enableRichText
     */
    protected $bodytext;

    /**
     * @return string
     */
    public function getTxTitle()
    {
        return $this->txTitle;
    }

    /**
     * @param string $txTitle
     */
    public function setTxTitle($txTitle)
    {
        $this->txTitle = $txTitle;
    }

    /**
     * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage
     */
    public function getImage()
    {
        return $this->image;
    }

    /**
     * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage $image
     */
    public function setImage($image)
    {
        $this->image = $image;
    }


    /**
     * @return string
     */
    public function getBodytext()
    {
        return $this->bodytext;
    }

    /**
     * @param string $bodytext
     */
    public function setBodytext($bodytext)
    {
        $this->bodytext = $bodytext;
    }


}