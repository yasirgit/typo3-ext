<?php

namespace Standardlife\SlContent\Domain\Model;

use TYPO3\CMS\Extbase\DomainObject\AbstractEntity;

/**
 * Class ImageSlide
 * @package Standardlife\SlContent\Domain\Model
 * @db
 */
class ImageSlide extends AbstractEntity
{

    /**
     * @var string
     * @db
     */
    protected $title;

    /**
     * @var string
     * @db
     */
    protected $subTitle1;

    /**
     * @var string
     * @db
     */
    protected $subTitle2;

    /**
     * @var string
     * @db
     */
    protected $preHeader;

    /**
     * @var string
     * @db
     */
    protected $link;

    /**
     * @var \TYPO3\CMS\Extbase\Domain\Model\FileReference
     * @db
     */
    protected $image;

    /**
     * @var int
     * @db
     */
    protected $contentUid;

    /**
     * @return string
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * @param string $title
     */
    public function setTitle($title)
    {
        $this->title = $title;
    }

    /**
     * @return string
     */
    public function getSubTitle1()
    {
        return $this->subTitle1;
    }

    /**
     * @param string $subTitle1
     */
    public function setSubTitle1($subTitle1)
    {
        $this->subTitle1 = $subTitle1;
    }

    /**
     * @return string
     */
    public function getSubTitle2()
    {
        return $this->subTitle2;
    }

    /**
     * @param string $subTitle2
     */
    public function setSubTitle2($subTitle2)
    {
        $this->subTitle2 = $subTitle2;
    }

    /**
     * @return string
     */
    public function getPreHeader()
    {
        return $this->preHeader;
    }

    /**
     * @param string $preHeader
     */
    public function setPreHeader($preHeader)
    {
        $this->preHeader = $preHeader;
    }

    /**
     * @return string
     */
    public function getLink()
    {
        return $this->link;
    }

    /**
     * @param string $link
     */
    public function setLink($link)
    {
        $this->link = $link;
    }

    /**
     * @return \TYPO3\CMS\Extbase\Domain\Model\FileReference
     */
    public function getImage()
    {
        return $this->image;
    }

    /**
     * @param \TYPO3\CMS\Extbase\Domain\Model\FileReference $image
     */
    public function setImage($image)
    {
        $this->image = $image;
    }

    /**
     * @return int
     */
    public function getContentUid()
    {
        return $this->contentUid;
    }

    /**
     * @param int $contentUid
     */
    public function setContentUid($contentUid)
    {
        $this->contentUid = $contentUid;
    }

}