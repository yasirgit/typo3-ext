<?php

if (!defined('TYPO3_MODE')) {
    die('Access denied.');
}

// Allow usage of a table on standard page
\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::allowTableOnStandardPages('tx_slcontent_domain_model_imageslide');
\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::allowTableOnStandardPages('tx_slcontent_domain_model_contentimageslide');

\HDNET\Autoloader\Loader::extTables('Standardlife', $_EXTKEY);