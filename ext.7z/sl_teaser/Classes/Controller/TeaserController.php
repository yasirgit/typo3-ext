<?php

namespace Standardlife\SlTeaser\Controller;

use OH\Ohmex\Renderer\FluidTemplateRenderer;
use Standardlife\SlTeaser\Domain\Model\Teaser;
use TYPO3\CMS\Extbase\Mvc\Controller\ActionController;

/**
 * Class TeaserController
 * @package Standardlife\SlTeaser\Controller
 */
class TeaserController extends ActionController
{

    protected $contentObj;
    protected $data;

    protected $fluidTemplateRenderer;

    /**
     * @var \Standardlife\SlTeaser\Domain\Repository\TeaserRepository
     * @inject
     */
    protected $teaserRepository;

    public function initializeAction()
    {
        $this->contentObj = $this->configurationManager->getContentObject();
        $this->data = $this->contentObj->data;
    }

    /**
     * Display selected teaser
     * @plugin Teaser!
     * @return string
     */
    public function indexAction()
    {
        $contentObj = $this->contentObj->data;

        $html = '';
        if ($contentObj['pi_flexform'] !== null) {
            $dom = new \DOMDocument();
            $dom->loadXML($contentObj['pi_flexform']);
            $xpath = new \DOMXPath($dom);
            $id = $xpath->evaluate("number(//T3FlexForms/data/sheet/language/field[@index='settings.teaser']/value)");
            if ($id === false) {
                return '';
            }

            /** @var Teaser $teaser */
            $teaser = $this->teaserRepository->findByUid($id);
            if ($teaser !== null) {
                $html = $this->getFluidTemplateRenderer()->render('Type/' . ucfirst($teaser->getType()), [
                    'teaser' => $teaser,
                ]);
            }
        }
        return $html;
    }

    /**
     * @return FluidTemplateRenderer
     */
    protected function getFluidTemplateRenderer()
    {
        if (!isset($this->fluidTemplateRenderer)) {
            $this->fluidTemplateRenderer = new FluidTemplateRenderer(
                __DIR__ . '/../../Resources/Private/Templates/Teaser/',
                __DIR__ . '/../../Resources/Private/Partials/',
                __DIR__ . '/../../Resources/Private/Layout/'
            );
        }

        return $this->fluidTemplateRenderer;
    }

}