<?php

namespace Standardlife\SlTeaser\Domain\Repository;

use TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings;
use TYPO3\CMS\Extbase\Persistence\Repository;

/**
 * Class TeaserRepository
 * @package Standardlife\SlTeaser\Domain\Repository
 */
class TeaserRepository extends Repository
{

    public function initializeObject()
    {
        /** @var $defaultQuerySettings Typo3QuerySettings */
        $defaultQuerySettings = $this->objectManager->get(Typo3QuerySettings::class);
        // add sys_language_uid constraint 8
        $defaultQuerySettings->setRespectSysLanguage(true);
        $defaultQuerySettings->setRespectStoragePage(false);
        $this->setDefaultQuerySettings($defaultQuerySettings);
    }

}