<?php

namespace Standardlife\SlTeaser\Domain\Model;

use TYPO3\CMS\Extbase\DomainObject\AbstractEntity;

/**
 * Class Teaser
 * @package Standardlife\SlTeaser\Domain\Model
 * @db
 */
class Teaser extends AbstractEntity
{
    /**
     * @var string
     * @db
     */
    protected $title;

    /**
     * @var string
     * @db
     */
    protected $type;

    /**
     * @var \Standardlife\Website\Domain\Model\SysCategory
     * @db
     */
    protected $category;

    /**
     * @var string
     * @enableRichText
     * @db
     */
    protected $text;

    /**
     * @var string
     * @db
     */
    protected $hoverTitle;

    /**
     * @var string
     * @enableRichText
     * @db
     */
    protected $hoverText;

    /**
     * @var string
     * @db
     */
    protected $link;

    /**
     * @var \TYPO3\CMS\Extbase\Domain\Model\FileReference
     * @db
     */
    protected $image;

    /**
     * @var string
     * @db
     */
    protected $icon;

    /**
     * @var \Standardlife\SlCrd\Domain\Model\Crd
     * @db
     */
    protected $crd;

    /**
     * @return string
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * @param string $title
     */
    public function setTitle($title)
    {
        $this->title = $title;
    }

    /**
     * @return string
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     * @param string $type
     */
    public function setType($type)
    {
        $this->type = $type;
    }

    /**
     * @return \Standardlife\Website\Domain\Model\SysCategory
     */
    public function getCategory()
    {
        return $this->category;
    }

    /**
     * @param \Standardlife\Website\Domain\Model\SysCategory $category
     */
    public function setCategory($category)
    {
        $this->category = $category;
    }

    /**
     * @return string
     */
    public function getText()
    {
        return $this->text;
    }

    /**
     * @param string $text
     */
    public function setText($text)
    {
        $this->text = $text;
    }

    /**
     * @return string
     */
    public function getHoverTitle()
    {
        return $this->hoverTitle;
    }

    /**
     * @param string $hoverTitle
     */
    public function setHoverTitle($hoverTitle)
    {
        $this->hoverTitle = $hoverTitle;
    }

    /**
     * @return string
     */
    public function getHoverText()
    {
        return $this->hoverText;
    }

    /**
     * @param string $hoverText
     */
    public function setHoverText($hoverText)
    {
        $this->hoverText = $hoverText;
    }

    /**
     * @return string
     */
    public function getLink()
    {
        return $this->link;
    }

    /**
     * @param string $link
     */
    public function setLink($link)
    {
        $this->link = $link;
    }

    /**
     * @return \TYPO3\CMS\Extbase\Domain\Model\FileReference
     */
    public function getImage()
    {
        return $this->image;
    }

    /**
     * @param \TYPO3\CMS\Extbase\Domain\Model\FileReference $image
     */
    public function setImage($image)
    {
        $this->image = $image;
    }

    /**
     * @return string
     */
    public function getIcon()
    {
        return $this->icon;
    }

    /**
     * @param string $icon
     */
    public function setIcon($icon)
    {
        $this->icon = $icon;
    }

    /**
     * @return \Standardlife\SlCrd\Domain\Model\Crd
     */
    public function getCrd()
    {
        return $this->crd;
    }

    /**
     * @param \Standardlife\SlCrd\Domain\Model\Crd $crd
     */
    public function setCrd($crd)
    {
        $this->crd = $crd;
    }

}