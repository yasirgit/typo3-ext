<?php

namespace Standardlife\SlTeaser\Hooks;


use OH\Ohmex\Renderer\FluidTemplateRenderer;
use Standardlife\SlTeaser\Domain\Model\Teaser;
use Standardlife\SlTeaser\Domain\Repository\TeaserRepository;
use TYPO3\CMS\Backend\View\PageLayoutView;
use TYPO3\CMS\Backend\View\PageLayoutViewDrawItemHookInterface;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Object\ObjectManager;

/**
 * Class TeaserBackendPreview
 * @package Standardlife\SlTeaser\Hooks
 * @hook TYPO3_CONF_VARS|SC_OPTIONS|cms/layout/class.tx_cms_layout.php|tt_content_drawItem
 */
class TeaserBackendPreview implements PageLayoutViewDrawItemHookInterface
{

    protected $extensionKey = 'sl_teaser';

    protected $listType = 'slteaser_teaser';

    protected $backendTemplate = 'Teaser/TeaserBackend';

    protected $fileSuffix = '.html';

    protected $modelClass = Teaser::class;

    protected $templatePath = __DIR__ . '/../../Resources/Private/Templates/';

    protected $partialPath = __DIR__ . '/../../Resources/Private/Templates/Teaser/Type/';

    protected $typeName = 'Plugin: Teaser';

    /**
     * @param PageLayoutView $parentObject
     * @param bool $drawItem
     * @param string $headerContent
     * @param string $itemContent
     * @param array $row
     */
    public function preProcess(PageLayoutView &$parentObject, &$drawItem, &$headerContent, &$itemContent, array &$row)
    {
        if ($row['CType'] == 'list' && $row['list_type'] == $this->listType) {
            $backendPreview = $this->getBackendPreview($row);

            if ($backendPreview !== null) {
                $itemContent = $backendPreview;
                $drawItem = false;
            }
        }
    }

    /**
     * @param $row
     * @return null|string
     */
    protected function getBackendPreview($row)
    {
        $path = $this->templatePath . $this->backendTemplate . $this->fileSuffix;

        if (!file_exists($path)) {
            return null;
        }

        $model = $this->getTeaser($row);
        if ($model === null) {
            return null;
        }

        $fluidTemplateRenderer = new FluidTemplateRenderer(
            realpath($this->templatePath) . '/',
            realpath($this->partialPath) . '/'
        );

        $html = $fluidTemplateRenderer->render($this->backendTemplate, [
            'data' => $row,
            'object' => $model,
        ]);

        return $this->getTypeHtml($model) . $html;
    }

    /**
     * @param Teaser $model
     * @return string
     */
    protected function getTypeHtml(Teaser $model)
    {
        return '<strong>' . $this->typeName . ' (Type: ' . $model->getType() . ')</strong><br />';
    }

    /**
     * @param $row
     * @return null|Teaser
     */
    protected function getTeaser($row)
    {
        $teaser = null;
        if ($row['pi_flexform'] !== null) {
            $dom = new \DOMDocument();
            $dom->loadXML($row['pi_flexform']);
            $xpath = new \DOMXPath($dom);
            $id = $xpath->evaluate("number(//T3FlexForms/data/sheet/language/field[@index='settings.teaser']/value)");
            if ($id === false) {
                return null;
            }

            /** @var TeaserRepository $teaserRepository */
            $teaserRepository = GeneralUtility::makeInstance(ObjectManager::class)->get(TeaserRepository::class);
            /** @var Teaser $teaser */
            $teaser = $teaserRepository->findByUid($id);
        }

        return $teaser;
    }

}