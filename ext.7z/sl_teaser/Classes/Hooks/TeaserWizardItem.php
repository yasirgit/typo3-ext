<?php

namespace Standardlife\SlTeaser\Hooks;


use TYPO3\CMS\Core\Utility\ExtensionManagementUtility;

/**
 * Class TeaserWizardItem
 * @package Standardlife\SlTeaser\Hooks
 */
class TeaserWizardItem {

    const KEY = 'slteaser_teaser';

    /**
     * Processing the wizard items array
     *
     * @param array $wizardItems The wizard items
     * @return array array with wizard items
     */
    public function proc($wizardItems) {
        $wizardItems['plugins_tx_' . self::KEY] = array(
            'icon'			=> ExtensionManagementUtility::extPath('sl_teaser' /*self::KEY*/) . 'Resources/Public/Icons/ce_wiz.gif',
            'title'			=> 'Teaser', //$GLOBALS['LANG']->sL('LLL:EXT:news/Resources/Private/Language/locallang_be.xlf:pi1_title'),
            'description'	=> 'Display a selected teaser', //$GLOBALS['LANG']->sL('LLL:EXT:news/Resources/Private/Language/locallang_be.xlf:pi1_plus_wiz_description'),
            'params'		=> '&defVals[tt_content][CType]=list&defVals[tt_content][list_type]=' . self::KEY // . '_pi1'
        );

        return $wizardItems;
    }

} 