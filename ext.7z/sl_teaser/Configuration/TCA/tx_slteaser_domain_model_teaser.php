<?php

use HDNET\Autoloader\Utility\ArrayUtility;
use HDNET\Autoloader\Utility\ModelUtility;

// return (function () {

    $base = ModelUtility::getTcaInformation(\Standardlife\SlTeaser\Domain\Model\Teaser::class);

    // custom manipulation calls here
    $custom = [
        'columns' => [
            'title' => [
                'config' => [
                    'type' => 'text',
                    'rows' => '2',
                    'wrap' => 'off',
                ],
            ],
            'text' => [
                'config' => [
                    'type' => 'text',
                ],
            ],
            'link' => [
                'exclude' => 1,
                'config' => [
                    'type' => 'input',
                    'renderType' => 'inputLink',
                ],
            ],
            'type' => [
                'config' => [
                    'type' => 'select',
                    'items' => [
                        ['With image', 'imaged'],
                        ['With icon', 'imageless'],
                        ['Text only', 'text'],
                        ['Image with headline only', 'centeredHeadlineWrapper'],
                    ]
                ],
            ],
            'category' => [
                'config' => [
                    'type' => 'select',
                    'renderType' => 'selectTree',
                    'size' => 10,
                    //'minItems' => 1,
                    //'maxItems' => 1,
                    'foreign_table' => 'sys_category',
                    'foreign_table_where' => ' ORDER BY sys_category.title ASC',
                    'treeConfig' => array(
                        'parentField' => 'parent',
                        'appearance' => array(
                            'expandAll' => true,
                            'showHeader' => true,
                        ),
                    ),
                ],
            ],

        ],
    ];

    $tca = ArrayUtility::mergeRecursiveDistinct($base, $custom);

    if (\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::isLoaded('sl_crd')) {
        $tca = \Standardlife\SlCrd\Utilities\CrdUtil::addTca($tca);
    }

    return $tca;

// })();
